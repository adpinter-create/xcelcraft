Attribute VB_Name = "modFormatCycles"
'==============================================================================
' SPDX-License-Identifier: MIT
' XcelCraft - modFormatCycles
' Format cycle tools: cycle engine, number/color/border/font/
' alignment cycles, cell-type coloring, paintbrush, row/column cycles.
' Original implementation.
'
' Cycle behaviour: a cycle always starts at its first
' format; each repeated press on the SAME selection applies the next one and
' wraps around. Changing the selection or running another tool resets it.
' Every cycle is customizable: see XC_CustomizeCycle.
'==============================================================================
Option Explicit

Private mLastCycle As String
Private mLastSel As String
Private mIdx As Long

Private Const BLUE As Long = 16711680      ' RGB(0,0,255)
Private Const SEP As String = "|"

'------------------------------------------------------------------------------
' Cycle engine
'------------------------------------------------------------------------------
Private Function SelKey() As String
    On Error Resume Next
    SelKey = ActiveWorkbook.Name & "!" & ActiveSheet.Name & "!" & Selection.Address
End Function

' Returns the 0-based index to apply for this press of the given cycle.
Public Function NextCycleIndex(ByVal cycleName As String, ByVal itemCount As Long) As Long
    Dim k As String
    k = SelKey()
    If itemCount <= 0 Then NextCycleIndex = 0: Exit Function
    If cycleName = mLastCycle And k = mLastSel Then
        mIdx = (mIdx + 1) Mod itemCount
    Else
        mIdx = 0
    End If
    mLastCycle = cycleName
    mLastSel = k
    NextCycleIndex = mIdx
End Function

Public Sub ResetCycle()
    mLastCycle = ""
    mLastSel = ""
End Sub

' Cycle definitions are stored as SEP-separated strings in the registry/plist
' so the user can customize them without touching code.
Public Function CycleItems(ByVal cycleName As String) As Variant
    Dim s As String
    s = GetSetting(REG_APP, "Cycles", cycleName, "")
    If Len(s) = 0 Then s = DefaultCycle(cycleName)
    CycleItems = Split(s, SEP)
End Function

Public Function DefaultCycle(ByVal cycleName As String) As String
    Dim e As String, p As String, y As String
    e = ChrW(8364): p = ChrW(163): y = ChrW(165)
    Select Case cycleName
        ' ---- number formats
        Case "NumGeneral":  DefaultCycle = "#,##0_);(#,##0)|#,##0.0_);(#,##0.0)|#,##0.00_);(#,##0.00)|0|General"
        Case "NumMultiple": DefaultCycle = "0.0""x""|0.00""x""|0""x"""
        Case "NumCurrency": DefaultCycle = "$#,##0_);($#,##0)|$#,##0.0_);($#,##0.0)|$#,##0.00_);($#,##0.00)"
        Case "NumForeign":  DefaultCycle = e & "#,##0.0_);(" & e & "#,##0.0)|" & p & "#,##0.0_);(" & p & "#,##0.0)|" & y & "#,##0_);(" & y & "#,##0)"
        Case "NumDate":     DefaultCycle = "m/d/yyyy|yyyy-mm-dd|mmm d, yyyy|mmm-yy|mmmm yyyy|yyyy"
        Case "NumBinary":   DefaultCycle = """Yes"";""Yes"";""No""|""Y"";""Y"";""N""|""On"";""On"";""Off""|""TRUE"";""TRUE"";""FALSE"""
        Case "NumPercent":  DefaultCycle = "0.0%_);(0.0%)|0%_);(0%)|0.00%_);(0.00%)|+0.0%;-0.0%;0.0%"
        Case "NumRatio":    DefaultCycle = "0.00"":1""|0.0"":1""|0""/10"""
        ' ---- colors (RGB long values)
        Case "FontColor":   DefaultCycle = "0|16711680|32768|255|8388736|42495|8421504"            ' black, blue, green, red, purple, orange, gray
        Case "FillColor":   DefaultCycle = "-1|13434879|14277081|16247773|14348258|14083324|13431551" ' none, lt yellow, lt gray, lt blue, lt green, lt orange, lt pink
        Case "BorderColor": DefaultCycle = "0|8421504|16711680|255|12611584"
        Case "cell-type coloring":   DefaultCycle = "16711680|0|32768|255|8388736"   ' inputs, formulas, sheet links, external links, partial inputs
        ' ---- misc
        Case "FontSize":    DefaultCycle = "8|9|10|11|12|14|16"
        Case "RowHeight":   DefaultCycle = "12.75|15|18|21|24|30"
        Case "ColWidth":    DefaultCycle = "8.43|10|12|15|20|25"
        Case "Indent":      DefaultCycle = "0|1|2|3"
        Case "ListPrefix":  DefaultCycle = "- |" & ChrW(8226) & " |1. |a. |A. |i. |I. "
        Case Else:          DefaultCycle = ""
    End Select
End Function

'------------------------------------------------------------------------------
' Number format cycles
'------------------------------------------------------------------------------
Private Sub ApplyNumberCycle(ByVal cycleName As String)
    On Error GoTo eh
    Dim items As Variant, i As Long, rng As Range
    If TypeName(Selection) <> "Range" Then Exit Sub
    Set rng = Selection
    items = CycleItems(cycleName)
    i = NextCycleIndex(cycleName, UBound(items) + 1)
    rng.NumberFormat = items(i)
    If cycleName = "NumPercent" And GetSetting(REG_APP, "Options", "ItalicPercent", "0") = "1" Then rng.Font.Italic = True
    If GetSetting(REG_APP, "Options", "AlignNumbersRight", "0") = "1" Then rng.HorizontalAlignment = xlRight
    Exit Sub
eh:
    If Err.Number = 1004 Then
        MsgBox "Excel rejected this number format: " & items(i) & vbCrLf & "Check the cycle definition (XcelCraft > Format: Fonts & Alignment > Customize a Cycle).", vbExclamation, APP_NAME
    Else
        ReportError cycleName
    End If
End Sub

Public Sub XC_NumGeneralCycle():  ApplyNumberCycle "NumGeneral":  End Sub
Public Sub XC_NumMultipleCycle(): ApplyNumberCycle "NumMultiple": End Sub
Public Sub XC_NumCurrencyCycle(): ApplyNumberCycle "NumCurrency": End Sub
Public Sub XC_NumForeignCycle():  ApplyNumberCycle "NumForeign":  End Sub
Public Sub XC_NumDateCycle():     ApplyNumberCycle "NumDate":     End Sub
Public Sub XC_NumBinaryCycle():   ApplyNumberCycle "NumBinary":   End Sub
Public Sub XC_NumPercentCycle():  ApplyNumberCycle "NumPercent":  End Sub
Public Sub XC_NumRatioCycle():    ApplyNumberCycle "NumRatio":    End Sub

'--- Increase / decrease decimals (edits the existing format string) --------
Public Sub XC_IncreaseDecimals(): AdjustDecimalsSel 1: End Sub
Public Sub XC_DecreaseDecimals(): AdjustDecimalsSel -1: End Sub

Private Sub AdjustDecimalsSel(ByVal delta As Long)
    On Error GoTo eh
    Dim c As Range, rng As Range
    If TypeName(Selection) <> "Range" Then Exit Sub
    Set rng = SelRange(False, True)
    If rng Is Nothing Then Exit Sub
    ResetCycle
    SafeStart
    For Each c In rng.Cells
        If IsNumeric(c.Value) And Not IsEmpty(c.Value) And VarType(c.Value) <> vbString Then
            c.NumberFormat = AdjustDecimalsFormat(c.NumberFormat, delta)
        End If
    Next c
    SafeEnd
    Exit Sub
eh:
    ReportError "Increase/Decrease Decimals"
End Sub

' Adds/removes one decimal "0" in every section of a number format.
Public Function AdjustDecimalsFormat(ByVal fmt As String, ByVal delta As Long) As String
    Dim secs() As String, i As Long
    If fmt = "General" Then
        If delta > 0 Then AdjustDecimalsFormat = "0.0" Else AdjustDecimalsFormat = "0"
        Exit Function
    End If
    If InStr(fmt, "@") > 0 Then AdjustDecimalsFormat = fmt: Exit Function
    secs = Split(fmt, ";")
    For i = LBound(secs) To UBound(secs)
        secs(i) = AdjustOneSection(secs(i), delta)
    Next i
    AdjustDecimalsFormat = Join(secs, ";")
End Function

Private Function AdjustOneSection(ByVal s As String, ByVal delta As Long) As String
    Dim p As Long, q As Long, inQuote As Boolean, i As Long, ch As String, digitsEnd As Long
    ' find the decimal point that is outside quotes/brackets
    For i = 1 To Len(s)
        ch = Mid$(s, i, 1)
        If ch = """" Then inQuote = Not inQuote
        If ch = "." And Not inQuote Then p = i: Exit For
    Next i
    If p = 0 Then
        ' no decimals yet: insert after the last 0 or # of the integer part
        If delta <= 0 Then AdjustOneSection = s: Exit Function
        q = 0
        For i = 1 To Len(s)
            ch = Mid$(s, i, 1)
            If ch = """" Then inQuote = Not inQuote
            If (ch = "0" Or ch = "#") And Not inQuote Then q = i
        Next i
        If q = 0 Then AdjustOneSection = s: Exit Function
        AdjustOneSection = Left$(s, q) & ".0" & Mid$(s, q + 1)
        Exit Function
    End If
    ' decimals exist: count the 0/# run right after the point
    digitsEnd = p
    Do While digitsEnd < Len(s)
        ch = Mid$(s, digitsEnd + 1, 1)
        If ch = "0" Or ch = "#" Then digitsEnd = digitsEnd + 1 Else Exit Do
    Loop
    If delta > 0 Then
        AdjustOneSection = Left$(s, digitsEnd) & "0" & Mid$(s, digitsEnd + 1)
    Else
        If digitsEnd - p <= 1 Then
            AdjustOneSection = Left$(s, p - 1) & Mid$(s, digitsEnd + 1)   ' remove ".0"
        Else
            AdjustOneSection = Left$(s, digitsEnd - 1) & Mid$(s, digitsEnd + 1)
        End If
    End If
End Function

'--- Shift decimal: divide / multiply numeric INPUTS by 10 (formulas untouched)
Public Sub XC_ShiftDecimalLeft(): ShiftDecimal 0.1: End Sub
Public Sub XC_ShiftDecimalRight(): ShiftDecimal 10: End Sub

Private Sub ShiftDecimal(ByVal factor As Double)
    On Error GoTo eh
    Dim rng As Range, c As Range
    Set rng = SelRange(False, True)
    If rng Is Nothing Then Exit Sub
    ResetCycle
    SnapshotRange rng, "Shift Decimal"
    SafeStart
    For Each c In rng.Cells
        If Not c.HasFormula And IsNumeric(c.Value) And Not IsEmpty(c.Value) And VarType(c.Value) <> vbString And VarType(c.Value) <> vbBoolean Then
            c.Value = c.Value * factor
        End If
    Next c
    SafeEnd
    Exit Sub
eh:
    ReportError "Shift Decimal"
End Sub

'------------------------------------------------------------------------------
' Color cycles
'------------------------------------------------------------------------------
Public Sub XC_FontColorCycle()
    On Error GoTo eh
    Dim items As Variant, i As Long
    If TypeName(Selection) <> "Range" Then Exit Sub
    items = CycleItems("FontColor")
    i = NextCycleIndex("FontColor", UBound(items) + 1)
    Selection.Font.Color = CLng(items(i))
    Exit Sub
eh:
    ReportError "Font Color Cycle"
End Sub

Public Sub XC_InputColorToggle()
    On Error GoTo eh
    Dim defaultColor As Long
    If TypeName(Selection) <> "Range" Then Exit Sub
    ResetCycle
    defaultColor = CLng(GetSetting(REG_APP, "Options", "DefaultFontColor", "0"))
    If Selection.Cells(1).Font.Color = BLUE Then
        Selection.Font.Color = defaultColor
    Else
        Selection.Font.Color = BLUE
    End If
    Exit Sub
eh:
    ReportError "Input Color Toggle"
End Sub

Public Sub XC_FillColorCycle()
    On Error GoTo eh
    Dim items As Variant, i As Long
    If TypeName(Selection) <> "Range" Then Exit Sub
    items = CycleItems("FillColor")
    i = NextCycleIndex("FillColor", UBound(items) + 1)
    If CLng(items(i)) = -1 Then
        Selection.Interior.ColorIndex = xlColorIndexNone
    Else
        Selection.Interior.Color = CLng(items(i))
    End If
    Exit Sub
eh:
    ReportError "Fill Color Cycle"
End Sub

' Changes the color of EXISTING borders only.
Public Sub XC_BorderColorCycle()
    On Error GoTo eh
    Dim items As Variant, i As Long, c As Range, e As Variant, rng As Range
    Set rng = SelRange(False, True)
    If rng Is Nothing Then Exit Sub
    items = CycleItems("BorderColor")
    i = NextCycleIndex("BorderColor", UBound(items) + 1)
    SafeStart
    For Each c In rng.Cells
        For Each e In Array(xlEdgeLeft, xlEdgeTop, xlEdgeBottom, xlEdgeRight)
            If c.Borders(e).LineStyle <> xlNone Then c.Borders(e).Color = CLng(items(i))
        Next e
    Next c
    SafeEnd
    Exit Sub
eh:
    ReportError "Border Color Cycle"
End Sub

'------------------------------------------------------------------------------
' cell-type coloring
'------------------------------------------------------------------------------
' Scheme indices: 0 inputs, 1 formulas, 2 same-workbook other-sheet links,
'                 3 external workbook links, 4 partial inputs (hardcodes in formulas)
Public Sub XC_TypeColorSelection()
    Dim rng As Range
    Set rng = SelRange(False, True)
    If rng Is Nothing Then Exit Sub
    TypeColorRange rng, "Color by cell type"
End Sub

Public Sub XC_TypeColorSheet()
    TypeColorRange ActiveSheet.UsedRange, "Color sheet by cell type"
End Sub

Public Sub XC_TypeColorWorkbook()
    On Error GoTo eh
    Dim ws As Worksheet, n As Long
    SafeStart "cell-type coloring workbook"
    For Each ws In ActiveWorkbook.Worksheets
        n = n + TypeColorCore(ws.UsedRange)
    Next ws
    SafeEnd
    Done "Color workbook by cell type: " & Plural(n, "cell") & " colored."
    Exit Sub
eh:
    ReportError "Color workbook by cell type"
End Sub

Private Sub TypeColorRange(ByVal rng As Range, ByVal nm As String)
    On Error GoTo eh
    Dim n As Long
    ResetCycle
    SafeStart nm
    n = TypeColorCore(rng)
    SafeEnd
    Done nm & ": " & Plural(n, "cell") & " colored."
    Exit Sub
eh:
    ReportError nm
End Sub

Public Function TypeColorCore(ByVal rng As Range) As Long
    Dim scheme As Variant, c As Range, f As String, n As Long, cat As Long, skipColors As String, v As Variant
    scheme = CycleItems("cell-type coloring")
    skipColors = "|" & GetSetting(REG_APP, "Options", "NoTypeColor", "255") & "|"   ' red is skipped by default
    If rng Is Nothing Then Exit Function
    For Each c In rng.Cells
        If Not IsEmpty(c.Value) Then
            If InStr(skipColors, "|" & c.Font.Color & "|") > 0 Then GoTo nextCell
            cat = -1
            If c.HasFormula Then
                f = c.Formula
                If InStr(f, "[") > 0 And InStr(f, "]") > 0 Then
                    cat = 3
                ElseIf InStr(f, "!") > 0 Then
                    cat = 2
                ElseIf HasHardcode(f) Then
                    cat = 4
                Else
                    cat = 1
                End If
            Else
                v = c.Value
                If IsNumeric(v) And VarType(v) <> vbString And VarType(v) <> vbBoolean Then cat = 0
                If VarType(v) = vbDate Then cat = 0
            End If
            If cat >= 0 And cat <= UBound(scheme) Then
                If c.Font.Color <> CLng(scheme(cat)) Then c.Font.Color = CLng(scheme(cat)): n = n + 1
            End If
        End If
nextCell:
    Next c
    TypeColorCore = n
End Function

' True if a formula contains a numeric literal other than 0, 1, 100, 1000, 1000000.
Public Function HasHardcode(ByVal f As String) As Boolean
    Dim i As Long, ch As String, inQ As Boolean, tok As String, prev As String, ignore As String
    ignore = "|0|1|100|1000|1000000|"
    f = Mid$(f, 2) ' drop "="
    For i = 1 To Len(f) + 1
        If i <= Len(f) Then ch = Mid$(f, i, 1) Else ch = " "
        If ch = """" Then inQ = Not inQ: tok = "": prev = ch: GoTo nxt
        If inQ Then GoTo nxt
        If ch = "'" Then
            ' skip quoted sheet names
            Dim j As Long: j = InStr(i + 1, f, "'")
            If j > 0 Then i = j: prev = "'": tok = "": GoTo nxt
        End If
        If IsDigitChar(ch) Or (ch = "." And Len(tok) > 0) Then
            If Len(tok) = 0 Then
                ' a digit run that starts right after a letter, $ or . is part of a reference/name
                If IsLetter(prev) Or prev = "$" Or prev = "." Or prev = "_" Then
                    tok = "": prev = "X"   ' mark as inside a reference
                    GoTo nxt
                End If
            End If
            tok = tok & ch
        Else
            If Len(tok) > 0 Then
                If IsLetter(ch) Or ch = ":" Then
                    ' e.g. 1:1 row refs or 1E5 - treat as reference, ignore
                Else
                    If InStr(ignore, "|" & tok & "|") = 0 Then HasHardcode = True: Exit Function
                End If
            End If
            tok = ""
            prev = ch
            GoTo nxt
        End If
        prev = ch
nxt:
    Next i
End Function

Public Sub XC_TypeColorCycle()
    On Error GoTo eh
    Dim items As Variant, i As Long
    If TypeName(Selection) <> "Range" Then Exit Sub
    items = CycleItems("cell-type coloring")
    i = NextCycleIndex("TypeColorCycle", UBound(items) + 1)
    Selection.Font.Color = CLng(items(i))
    Exit Sub
eh:
    ReportError "Cell-type color cycle"
End Sub

'--- Alternate row / column shading (conditional formatting) ---------------
Public Sub XC_AlternateRowShading(): AlternateShading True: End Sub
Public Sub XC_AlternateColumnShading(): AlternateShading False: End Sub

Private Sub AlternateShading(ByVal byRows As Boolean)
    On Error GoTo eh
    Dim rng As Range, fc As FormatCondition, color As Long, formulaS As String, i As Long
    Set rng = SelRangeOrRegion()
    If rng Is Nothing Then Exit Sub
    color = CLng(GetSetting(REG_APP, "Options", "ShadingColor", "15921906")) ' light gray
    formulaS = IIf(byRows, "=MOD(ROW(),2)=0", "=MOD(COLUMN(),2)=0")
    ' toggle: remove if already present
    For i = rng.FormatConditions.Count To 1 Step -1
        If rng.FormatConditions(i).Type = xlExpression Then
            If rng.FormatConditions(i).Formula1 = formulaS Then rng.FormatConditions(i).Delete: Exit Sub
        End If
    Next i
    Set fc = rng.FormatConditions.Add(Type:=xlExpression, Formula1:=formulaS)
    fc.Interior.Color = color
    fc.StopIfTrue = False
    Exit Sub
eh:
    ReportError "Alternate Shading"
End Sub

'------------------------------------------------------------------------------
' Border cycles
'------------------------------------------------------------------------------
Private Sub BorderStyleCycle(ByVal cycleName As String, ByVal edgeList As Variant)
    On Error GoTo eh
    Dim styles As Variant, weights As Variant, i As Long, e As Variant, defColor As Long
    If TypeName(Selection) <> "Range" Then Exit Sub
    styles = Array(xlNone, xlContinuous, xlContinuous, xlDouble, xlContinuous, xlDash)
    weights = Array(xlThin, xlThin, xlMedium, xlThick, xlThick, xlThin)
    i = NextCycleIndex(cycleName, 6)
    i = (i + 1) Mod 6  ' first press applies the thin line, last returns to none
    defColor = CLng(GetSetting(REG_APP, "Options", "DefaultBorderColor", "0"))
    For Each e In edgeList
        With Selection.Borders(e)
            If styles(i) = xlNone Then
                .LineStyle = xlNone
            Else
                .LineStyle = styles(i)
                .Weight = weights(i)
                .Color = defColor
            End If
        End With
    Next e
    Exit Sub
eh:
    ReportError cycleName
End Sub

Public Sub XC_BottomBorderCycle(): BorderStyleCycle "BorderBottom", Array(xlEdgeBottom): End Sub
Public Sub XC_TopBorderCycle(): BorderStyleCycle "BorderTop", Array(xlEdgeTop): End Sub
Public Sub XC_LeftBorderCycle(): BorderStyleCycle "BorderLeft", Array(xlEdgeLeft): End Sub
Public Sub XC_RightBorderCycle(): BorderStyleCycle "BorderRight", Array(xlEdgeRight): End Sub
Public Sub XC_OutsideBorderCycle(): BorderStyleCycle "BorderOutside", Array(xlEdgeLeft, xlEdgeTop, xlEdgeBottom, xlEdgeRight): End Sub

Public Sub XC_NoBorder()
    On Error Resume Next
    If TypeName(Selection) <> "Range" Then Exit Sub
    ResetCycle
    Selection.Borders.LineStyle = xlNone
    Selection.Borders(xlEdgeLeft).LineStyle = xlNone
    Selection.Borders(xlEdgeTop).LineStyle = xlNone
    Selection.Borders(xlEdgeBottom).LineStyle = xlNone
    Selection.Borders(xlEdgeRight).LineStyle = xlNone
End Sub

' Total line: a thin line across the top of the selected cells; repeat removes it.
Public Sub XC_TotalLine()
    On Error GoTo eh
    Dim defColor As Long
    If TypeName(Selection) <> "Range" Then Exit Sub
    ResetCycle
    defColor = CLng(GetSetting(REG_APP, "Options", "DefaultBorderColor", "0"))
    With Selection.Borders(xlEdgeTop)
        If .LineStyle = xlContinuous And .Weight = xlThin Then
            .LineStyle = xlNone
        Else
            .LineStyle = xlContinuous: .Weight = xlThin: .Color = defColor
        End If
    End With
    Exit Sub
eh:
    ReportError "Total Line"
End Sub

'------------------------------------------------------------------------------
' Font / underline / size
'------------------------------------------------------------------------------
Public Sub XC_UnderlineCycle()
    On Error GoTo eh
    Dim styles As Variant, i As Long
    If TypeName(Selection) <> "Range" Then Exit Sub
    styles = Array(xlUnderlineStyleSingle, xlUnderlineStyleSingleAccounting, xlUnderlineStyleDouble, xlUnderlineStyleDoubleAccounting, xlUnderlineStyleNone)
    i = NextCycleIndex("Underline", 5)
    Selection.Font.Underline = styles(i)
    Exit Sub
eh:
    ReportError "Underline Cycle"
End Sub

Public Sub XC_FontSizeCycle()
    On Error GoTo eh
    Dim items As Variant, i As Long
    If TypeName(Selection) <> "Range" Then Exit Sub
    items = CycleItems("FontSize")
    i = NextCycleIndex("FontSize", UBound(items) + 1)
    Selection.Font.Size = CDbl(items(i))
    Exit Sub
eh:
    ReportError "Font Size Cycle"
End Sub

Public Sub XC_IncreaseFont()
    On Error Resume Next
    If TypeName(Selection) <> "Range" Then Exit Sub
    ResetCycle
    Selection.Font.Size = Selection.Font.Size + 1
End Sub

Public Sub XC_DecreaseFont()
    On Error Resume Next
    If TypeName(Selection) <> "Range" Then Exit Sub
    ResetCycle
    If Selection.Font.Size > 1 Then Selection.Font.Size = Selection.Font.Size - 1
End Sub

'------------------------------------------------------------------------------
' Alignment
'------------------------------------------------------------------------------
Public Sub XC_HorizontalAlignCycle()
    On Error GoTo eh
    Dim styles As Variant, i As Long
    If TypeName(Selection) <> "Range" Then Exit Sub
    styles = Array(xlLeft, xlCenter, xlRight, xlCenterAcrossSelection, xlGeneral)
    i = NextCycleIndex("HAlign", 5)
    Selection.HorizontalAlignment = styles(i)
    Exit Sub
eh:
    ReportError "Horizontal Alignment Cycle"
End Sub

Public Sub XC_LeftIndentCycle()
    On Error GoTo eh
    Dim items As Variant, i As Long
    If TypeName(Selection) <> "Range" Then Exit Sub
    items = CycleItems("Indent")
    i = NextCycleIndex("Indent", UBound(items) + 1)
    Selection.HorizontalAlignment = xlLeft
    Selection.IndentLevel = CLng(items(i))
    Exit Sub
eh:
    ReportError "Left Indent Cycle"
End Sub

Public Sub XC_WrapTextToggle()
    On Error Resume Next
    If TypeName(Selection) <> "Range" Then Exit Sub
    ResetCycle
    Selection.WrapText = Not Selection.Cells(1).WrapText
End Sub

'------------------------------------------------------------------------------
' Other formatting: case cycle, dot leaders, list cycle, footnote
'------------------------------------------------------------------------------
Public Sub XC_CaseCycle()
    On Error GoTo eh
    Dim rng As Range, i As Long, modes As Variant, c As Range, orig As String
    Static origText As Variant, origKey As String
    Set rng = SelRange(False, True)
    If rng Is Nothing Then Exit Sub
    modes = Array("sentence", "title", "upper", "lower")
    i = NextCycleIndex("Case", 4)
    If i = 0 Then origText = RangeToArray(rng, True): origKey = SelKey()
    SafeStart
    ' always derive from the original text so the cycle is stable
    If origKey = SelKey() And IsArray(origText) Then rng.Formula = origText
    ForEachTextCell rng, modes(i), ""
    SafeEnd
    Exit Sub
eh:
    ReportError "Case Cycle"
End Sub

' Dot leaders via the repeat-fill number format "@*." (toggle).
Public Sub XC_DotLeaders()
    On Error GoTo eh
    Dim rng As Range
    Set rng = SelRange(False, True)
    If rng Is Nothing Then Exit Sub
    ResetCycle
    If rng.Cells(1).NumberFormat = "@*." Then
        rng.NumberFormat = "General"
    Else
        rng.NumberFormat = "@*."
    End If
    Exit Sub
eh:
    ReportError "Dot Leaders"
End Sub

Public Sub XC_ListCycle()
    On Error GoTo eh
    Dim rng As Range, items As Variant, i As Long, c As Range, s As String, j As Long, k As Long, pre As String, num As Long
    Set rng = SelRange(False, True)
    If rng Is Nothing Then Exit Sub
    items = CycleItems("ListPrefix")
    i = NextCycleIndex("List", UBound(items) + 2) ' extra step = no prefix
    SafeStart
    num = 0
    For Each c In rng.Cells
        If Not c.HasFormula And VarType(c.Value) = vbString Then
            s = StripListPrefix(c.Value)
            If i <= UBound(items) Then
                num = num + 1
                pre = items(i)
                Select Case pre
                    Case "1. ": pre = num & ". "
                    Case "a. ": pre = Chr$(96 + ((num - 1) Mod 26) + 1) & ". "
                    Case "A. ": pre = Chr$(64 + ((num - 1) Mod 26) + 1) & ". "
                    Case "i. ": pre = LCase$(RomanNumeral(num)) & ". "
                    Case "I. ": pre = RomanNumeral(num) & ". "
                End Select
                c.Value = pre & s
            Else
                c.Value = s
            End If
        End If
    Next c
    SafeEnd
    Exit Sub
eh:
    ReportError "List Cycle"
End Sub

Private Function StripListPrefix(ByVal s As String) As String
    Dim p As Long, head As String
    If Left$(s, 2) = "- " Or Left$(s, 2) = ChrW(8226) & " " Then StripListPrefix = Mid$(s, 3): Exit Function
    p = InStr(s, ". ")
    If p > 0 And p <= 6 Then
        head = Left$(s, p - 1)
        If IsNumeric(head) Or Len(head) = 1 Or IsRoman(head) Then StripListPrefix = Mid$(s, p + 2): Exit Function
    End If
    StripListPrefix = s
End Function

Private Function IsRoman(ByVal s As String) As Boolean
    Dim i As Long
    If Len(s) = 0 Then Exit Function
    For i = 1 To Len(s)
        If InStr("IVXLCDMivxlcdm", Mid$(s, i, 1)) = 0 Then Exit Function
    Next i
    IsRoman = True
End Function

Public Function RomanNumeral(ByVal n As Long) As String
    Dim vals As Variant, syms As Variant, i As Long, s As String
    vals = Array(1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1)
    syms = Array("M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I")
    For i = 0 To 12
        Do While n >= vals(i)
            s = s & syms(i): n = n - vals(i)
        Loop
    Next i
    RomanNumeral = s
End Function

' Footnote toggle: appends a superscript "(n)" marker to the cell text; repeat removes it.
Public Sub XC_FootnoteCycle()
    On Error GoTo eh
    Dim rng As Range, c As Range, i As Long, s As String, p As Long, mark As String
    Set rng = SelRange(False, True)
    If rng Is Nothing Then Exit Sub
    i = NextCycleIndex("Footnote", 10) ' (1)..(9) then none
    SafeStart
    For Each c In rng.Cells
        If Not c.HasFormula And VarType(c.Value) = vbString Then
            s = c.Value
            p = InStrRev(s, " (")
            If p > 0 And Right$(s, 1) = ")" And Len(s) - p <= 4 Then s = Left$(s, p - 1)
            If i < 9 Then
                mark = " (" & (i + 1) & ")"
                c.Value = s & mark
                c.Characters(Len(s) + 1, Len(mark)).Font.Superscript = True
            Else
                c.Value = s
            End If
        End If
    Next c
    SafeEnd
    Exit Sub
eh:
    ReportError "Footnote Cycle"
End Sub

'------------------------------------------------------------------------------
' Row height / column width cycles
'------------------------------------------------------------------------------
Public Sub XC_RowHeightCycle()
    On Error GoTo eh
    Dim items As Variant, i As Long
    If TypeName(Selection) <> "Range" Then Exit Sub
    items = CycleItems("RowHeight")
    i = NextCycleIndex("RowHeight", UBound(items) + 1)
    Selection.RowHeight = CDbl(items(i))
    Exit Sub
eh:
    ReportError "Row Height Cycle"
End Sub

Public Sub XC_ColumnWidthCycle()
    On Error GoTo eh
    Dim items As Variant, i As Long
    If TypeName(Selection) <> "Range" Then Exit Sub
    items = CycleItems("ColWidth")
    i = NextCycleIndex("ColWidth", UBound(items) + 1)
    Selection.ColumnWidth = CDbl(items(i))
    Exit Sub
eh:
    ReportError "Column Width Cycle"
End Sub

'------------------------------------------------------------------------------
' Paintbrush: capture a cell's formatting, apply it elsewhere
'------------------------------------------------------------------------------
Private Function BrushCell() As Range
    Set BrushCell = ThisWorkbook.Worksheets(1).Range("A1")
End Function

Public Sub XC_CapturePaintbrush()
    On Error GoTo eh
    If TypeName(Selection) <> "Range" Then Exit Sub
    ResetCycle
    ActiveCell.Copy
    BrushCell.PasteSpecial xlPasteFormats
    Application.CutCopyMode = False
    Application.StatusBar = APP_NAME & ": formatting of " & ActiveCell.Address(False, False) & " captured. Use 'Apply Paintbrush Style' to paint it."
    Exit Sub
eh:
    ReportError "Capture Paintbrush Style"
End Sub

Public Sub XC_ApplyPaintbrush()
    On Error GoTo eh
    If TypeName(Selection) <> "Range" Then Exit Sub
    ResetCycle
    BrushCell.Copy
    Selection.PasteSpecial xlPasteFormats
    Application.CutCopyMode = False
    Exit Sub
eh:
    ReportError "Apply Paintbrush Style"
End Sub

'------------------------------------------------------------------------------
' Customize cycles and options
'------------------------------------------------------------------------------
Public Sub XC_CustomizeCycle()
    Dim names As Variant, i As Long, cur As String, nv As String
    names = Array("NumGeneral", "NumMultiple", "NumCurrency", "NumForeign", "NumDate", "NumBinary", "NumPercent", "NumRatio", _
                  "FontColor", "FillColor", "BorderColor", "cell-type coloring", "FontSize", "RowHeight", "ColWidth", "Indent", "ListPrefix")
    i = AskChoice("Which cycle do you want to customize?", names)
    If i = 0 Then Exit Sub
    cur = Join(CycleItems(names(i - 1)), SEP)
    nv = AskText("Items for the '" & names(i - 1) & "' cycle, separated by | (pipe)." & vbCrLf & _
                 "Colors are RGB long values (e.g. 16711680 = blue). -1 = no fill." & vbCrLf & _
                 "Leave empty to restore the default.", cur, "Customize Cycle")
    If StrPtr(nv) = 0 Then Exit Sub   ' cancelled
    If Len(nv) = 0 Then
        DeleteSettingSafe "Cycles", names(i - 1)
        MsgBox "Default restored for " & names(i - 1) & ".", vbInformation, APP_NAME
    Else
        SaveSetting REG_APP, "Cycles", names(i - 1), nv
        MsgBox "Cycle updated.", vbInformation, APP_NAME
    End If
End Sub

Public Sub XC_FormatOptions()
    Dim c As Long, v As String
    c = AskChoice("Format options:", Array( _
        "Toggle 'Align numbers right' (" & IIf(GetSetting(REG_APP, "Options", "AlignNumbersRight", "0") = "1", "ON", "OFF") & ")", _
        "Toggle 'Italicize percentages' (" & IIf(GetSetting(REG_APP, "Options", "ItalicPercent", "0") = "1", "ON", "OFF") & ")", _
        "Set default font color (RGB long, current " & GetSetting(REG_APP, "Options", "DefaultFontColor", "0") & ")", _
        "Set default border color (RGB long, current " & GetSetting(REG_APP, "Options", "DefaultBorderColor", "0") & ")", _
        "Set alternate shading color (RGB long, current " & GetSetting(REG_APP, "Options", "ShadingColor", "15921906") & ")", _
        "Set font colors cell-type coloring must skip (RGB longs separated by |, current " & GetSetting(REG_APP, "Options", "NoTypeColor", "255") & ")"))
    Select Case c
        Case 1: SaveSetting REG_APP, "Options", "AlignNumbersRight", IIf(GetSetting(REG_APP, "Options", "AlignNumbersRight", "0") = "1", "0", "1")
        Case 2: SaveSetting REG_APP, "Options", "ItalicPercent", IIf(GetSetting(REG_APP, "Options", "ItalicPercent", "0") = "1", "0", "1")
        Case 3: v = AskText("Default font color (RGB long):", GetSetting(REG_APP, "Options", "DefaultFontColor", "0")): If IsNumeric(v) Then SaveSetting REG_APP, "Options", "DefaultFontColor", v
        Case 4: v = AskText("Default border color (RGB long):", GetSetting(REG_APP, "Options", "DefaultBorderColor", "0")): If IsNumeric(v) Then SaveSetting REG_APP, "Options", "DefaultBorderColor", v
        Case 5: v = AskText("Shading color (RGB long):", GetSetting(REG_APP, "Options", "ShadingColor", "15921906")): If IsNumeric(v) Then SaveSetting REG_APP, "Options", "ShadingColor", v
        Case 6: v = AskText("Colors cell-type coloring skips (RGB longs separated by |):", GetSetting(REG_APP, "Options", "NoTypeColor", "255")): If Len(v) > 0 Then SaveSetting REG_APP, "Options", "NoTypeColor", v
    End Select
End Sub

Private Sub DeleteSettingSafe(ByVal section As String, ByVal key As String)
    On Error Resume Next
    DeleteSetting REG_APP, section, key
End Sub
