Attribute VB_Name = "modShortcuts"
'==============================================================================
' SPDX-License-Identifier: MIT
' XcelCraft - modShortcuts
' Keyboard shortcut manager (Application.OnKey based).
'
' Key syntax is Excel's OnKey syntax:  ^ = Ctrl   + = Shift   % = Alt
'   "^+r" = Ctrl+Shift+R      "%{F2}" = Alt+F2     "^!" = Ctrl+Shift+1 (US layout)
' Ctrl+Shift+<digit> must be written as the SHIFTED character on your layout
' (US: 1 ! 2 @ 3 # 4 $ 5 % 6 ^ 7 & 8 * 9 ( 0 ) ), because OnKey "^+1" is not
' reliable. "%" and "^" must be written as "{%}" and "{^}" when literal.
'
' Defaults are chosen to match common financial-modeling conventions where OnKey can express them.
' Users can override any shortcut; overrides live in the registry/plist.
'==============================================================================
Option Explicit

Private Type KeyRec
    Proc As String
    Caption As String
    DefaultKey As String
End Type

Private mKeys() As KeyRec
Private mKeyCount As Long

Private Sub K(ByVal proc As String, ByVal caption As String, ByVal defaultKey As String)
    mKeyCount = mKeyCount + 1
    ReDim Preserve mKeys(1 To mKeyCount)
    mKeys(mKeyCount).Proc = proc
    mKeys(mKeyCount).Caption = caption
    mKeys(mKeyCount).DefaultKey = defaultKey
End Sub

Private Sub RegisterKeys()
    mKeyCount = 0
    Erase mKeys
    ' ---- Numbers (Ctrl+Shift+1/8/4/2/5, Ctrl+Alt+Shift+4, Ctrl+Shift+Y, Alt+Shift+;)
    K "XC_NumGeneralCycle", "Cycle number formats", "^!"
    K "XC_NumMultipleCycle", "Cycle multiple (x) formats", "^*"
    K "XC_NumCurrencyCycle", "Cycle currency formats", "^$"
    K "XC_NumForeignCycle", "Cycle foreign currency formats", "^%$"
    K "XC_NumDateCycle", "Cycle date formats", "^@"
    K "XC_NumBinaryCycle", "Cycle yes/no formats", "^+y"
    K "XC_NumPercentCycle", "Cycle percent formats", "^{%}"
    K "XC_NumRatioCycle", "Cycle ratio formats", "%+;"
    K "XC_IncreaseDecimals", "One more decimal", "^,"
    K "XC_DecreaseDecimals", "One fewer decimal", "^."
    K "XC_ShiftDecimalLeft", "Divide inputs by 10", "%+,"
    K "XC_ShiftDecimalRight", "Multiply inputs by 10", "%+."
    ' ---- Colors
    K "XC_InputColorToggle", "Toggle input blue / default font color", "^+b"
    K "XC_FontColorCycle", "Cycle font color", "^+f"
    K "XC_FillColorCycle", "Cycle fill color", "^+k"
    K "XC_BorderColorCycle", "Cycle the color of existing borders", "^%+k"
    K "XC_TypeColorSelection", "Color selection by cell type (inputs, formulas, links)", "^%+a"
    K "XC_TypeColorCycle", "Cycle through the cell-type colors", "^%a"
    ' ---- Borders
    K "XC_BottomBorderCycle", "Cycle bottom border style", "^%b"
    K "XC_TopBorderCycle", "Cycle top border style", "^%u"
    K "XC_LeftBorderCycle", "Cycle left border style", "^%{LEFT}"
    K "XC_RightBorderCycle", "Cycle right border style", "^%{RIGHT}"
    K "XC_OutsideBorderCycle", "Cycle outline border style", "^+o"
    K "XC_NoBorder", "Remove borders", "^%n"
    K "XC_TotalLine", "Line above totals (toggle)", "^%="
    ' ---- Fonts / other formatting
    K "XC_UnderlineCycle", "Cycle underline style", "^+u"
    K "XC_FontSizeCycle", "Cycle font size", "^+s"
    K "XC_IncreaseFont", "Larger font", "^%+{UP}"
    K "XC_DecreaseFont", "Smaller font", "^%+{DOWN}"
    K "XC_HorizontalAlignCycle", "Cycle horizontal alignment", "^+h"
    K "XC_LeftIndentCycle", "Cycle indent", "^+i"
    K "XC_WrapTextToggle", "Wrap text (toggle)", "^+w"
    K "XC_CaseCycle", "Cycle text case", "^+c"
    K "XC_DotLeaders", "Dot leaders after text (toggle)", "^+l"
    K "XC_ListCycle", "Cycle list bullets and numbering", "^%+l"
    K "XC_FootnoteCycle", "Cycle footnote marker (1)-(9)", "^%+n"
    K "XC_RowHeightCycle", "Cycle row height", "^%+r"
    K "XC_ColumnWidthCycle", "Cycle column width", "^%+c"
    K "XC_CapturePaintbrush", "Capture this cell's style", "^%+p"
    K "XC_ApplyPaintbrush", "Apply the captured style", "^%p"
    ' ---- Modeling: formulas & paste
    K "XC_SmartFillRight", "Fill right as far as the neighbours go", "^+r"
    K "XC_SmartFillDown", "Fill down as far as the neighbours go", "^+d"
    K "XC_ErrorGuardQuick", "Guard formulas with IFERROR, saved fallback (toggle)", "^+e"
    K "XC_CleanCells", "Tidy formulas: drop stray spaces and this-sheet prefixes", "^%+x"
    K "XC_AnchorFormula", "Cycle reference anchoring (A1 > $A$1 > A$1 > $A1)", "^{F2}"
    K "XC_CommentCells", "Show formulas as text (apostrophe toggle)", "^%'"
    K "XC_FlipSign", "Negate numbers; wrap formulas in -( )", "^+n"
    K "XC_WrapParentheses", "Wrap the formula in parentheses", "^%9"
    K "XC_HardcodeSelection", "Replace formulas with values and recolor", "^#"
    K "XC_CopySource", "Mark source range for the paste tools", "^%c"
    K "XC_PasteVerbatim", "Paste formulas verbatim", "^%e"
    K "XC_PasteNumberFormats", "Paste number formats only", "^%f"
    K "XC_PasteTranspose", "Paste transposed (links / verbatim / values)...", "^%t"
    K "XC_PasteKeepInternalLinks", "Paste keeping links within the block", "^%d"
    K "XC_PasteLinks", "Paste as links to the source", "^%l"
    K "XC_CopyRowColInfo", "Capture row heights / column widths / outline", "^%j"
    K "XC_PasteRowColInfo", "Apply captured row / column sizing", "^%k"
    K "XC_ResolveLookups", "Resolve lookups to direct references", "^%+v"
    K "XC_EvaluateTranspose", "Turn a TRANSPOSE array into direct links", "^%+t"
    K "XC_GoToMin", "Jump to the smallest value", "^%+,"
    K "XC_GoToMax", "Jump to the largest value", "^%+."
    K "XC_ToggleGridlines", "Gridlines on/off", "^%g"
    ' ---- Auditing / financial / utilities
    K "XC_PrecedentsList", "Precedents: list and jump...", "^["
    K "XC_DependentsList", "Dependents: list and jump...", "^]"
    K "XC_TraceIn", "Step into a precedent", "^%+{LEFT}"
    K "XC_TraceOut", "Step back out", "^%+{RIGHT}"
    K "XC_ShowAllPrecedents", "Arrows to precedents (toggle)", "^+{F2}"
    K "XC_ShowAllDependents", "Arrows to dependents (toggle)", "^+{F3}"
    K "XC_ClearArrows", "Remove audit arrows", "^+{F4}"
    K "XC_QuickCagr", "Insert a growth-rate (CAGR) formula", "^%+g"
    K "XC_SummaryStatistics", "Add min / max / mean / median rows", "^%+s"
    K "XC_QuickSave", "Save", "^%s"
    K "XC_SaveNextVersion", "Save as the next version number...", "^%+{F12}"
    K "XC_ChartColorCycle", "Cycle color of the selected chart element", "^%+h"
    K "XC_SelectCellsByCriteria", "Select cells that pass a test...", "^%+q"
    ' ---- XcelCraft system
    K "XC_FindAndRunTool", "Search for a tool...", "^%+f"
    K "XC_RunLastTool", "Run the last tool again", "^%+z"
    K "XC_UndoLastTool", "Undo the last tool", "^%+u"
End Sub

Public Function ShortcutFor(ByVal proc As String) As String
    Dim i As Long
    If mKeyCount = 0 Then RegisterKeys
    For i = 1 To mKeyCount
        If mKeys(i).Proc = proc Then
            ShortcutFor = GetSetting(REG_APP, "Shortcuts", proc, mKeys(i).DefaultKey)
            Exit Function
        End If
    Next i
End Function

Public Sub InstallShortcuts()
    Dim i As Long, k As String
    If mKeyCount = 0 Then RegisterKeys
    If GetSetting(REG_APP, "Options", "ShortcutsEnabled", "1") <> "1" Then Exit Sub
    On Error Resume Next
    For i = 1 To mKeyCount
        k = GetSetting(REG_APP, "Shortcuts", mKeys(i).Proc, mKeys(i).DefaultKey)
        If Len(k) > 0 And k <> "-" Then
            Application.OnKey k, "'" & ThisWorkbook.Name & "'!" & mKeys(i).Proc
        End If
    Next i
    On Error GoTo 0
End Sub

Public Sub RemoveShortcuts()
    Dim i As Long, k As String
    If mKeyCount = 0 Then RegisterKeys
    On Error Resume Next
    For i = 1 To mKeyCount
        k = GetSetting(REG_APP, "Shortcuts", mKeys(i).Proc, mKeys(i).DefaultKey)
        If Len(k) > 0 And k <> "-" Then Application.OnKey k   ' restore Excel default
    Next i
    On Error GoTo 0
End Sub

Public Sub XC_ToggleShortcuts()
    If GetSetting(REG_APP, "Options", "ShortcutsEnabled", "1") = "1" Then
        SaveSetting REG_APP, "Options", "ShortcutsEnabled", "0"
        RemoveShortcuts
        MsgBox "Keyboard shortcuts are now OFF.", vbInformation, APP_NAME
    Else
        SaveSetting REG_APP, "Options", "ShortcutsEnabled", "1"
        InstallShortcuts
        MsgBox "Keyboard shortcuts are now ON.", vbInformation, APP_NAME
    End If
End Sub

' Lists all shortcuts and lets the user change one.
Public Sub XC_ShortcutManager()
    Dim i As Long, s As String, pick As Variant, cur As String, nv As String, page As Long, perPage As Long, lo As Long, hi As Long
    If mKeyCount = 0 Then RegisterKeys
    perPage = 25
    page = 0
    Do
        lo = page * perPage + 1: hi = Min2(lo + perPage - 1, mKeyCount)
        s = "Shortcuts " & lo & "-" & hi & " of " & mKeyCount & ". Enter a number to change it, 0 for the next page:" & vbCrLf & vbCrLf
        For i = lo To hi
            cur = GetSetting(REG_APP, "Shortcuts", mKeys(i).Proc, mKeys(i).DefaultKey)
            s = s & i & ". " & mKeys(i).Caption & "   [" & IIf(cur = "-", "none", cur) & "]" & vbCrLf
        Next i
        pick = Application.InputBox(s, "Shortcut Manager", 0, Type:=1)
        If VarType(pick) = vbBoolean Then Exit Sub
        If pick = 0 Then
            page = page + 1
            If page * perPage >= mKeyCount Then page = 0
        ElseIf pick >= 1 And pick <= mKeyCount Then
            i = CLng(pick)
            cur = GetSetting(REG_APP, "Shortcuts", mKeys(i).Proc, mKeys(i).DefaultKey)
            nv = AskText("New shortcut for '" & mKeys(i).Caption & "' in OnKey syntax (^=Ctrl +=Shift %=Alt)." & vbCrLf & _
                         "Enter - to disable, leave empty to restore the default (" & mKeys(i).DefaultKey & ").", cur, "Shortcut Manager")
            If StrPtr(nv) <> 0 Then
                On Error Resume Next
                If cur <> "-" And Len(cur) > 0 Then Application.OnKey cur
                If Len(nv) = 0 Then
                    DeleteSetting REG_APP, "Shortcuts", mKeys(i).Proc
                Else
                    SaveSetting REG_APP, "Shortcuts", mKeys(i).Proc, nv
                End If
                On Error GoTo 0
                InstallShortcuts
            End If
            Exit Sub
        End If
    Loop
End Sub

Public Sub XC_ListShortcuts()
    Dim ws As Worksheet, i As Long
    If mKeyCount = 0 Then RegisterKeys
    Set ws = NewReportSheet("Shortcuts")
    ws.Range("A1:C1").Value = Array("Tool", "Shortcut (OnKey syntax)", "Procedure")
    ws.Range("A1:C1").Font.Bold = True
    For i = 1 To mKeyCount
        ws.Cells(i + 1, 1).Value = mKeys(i).Caption
        ws.Cells(i + 1, 2).Value = GetSetting(REG_APP, "Shortcuts", mKeys(i).Proc, mKeys(i).DefaultKey)
        ws.Cells(i + 1, 3).Value = mKeys(i).Proc
    Next i
    ws.Columns("A:C").AutoFit
End Sub

Public Function ShortcutCount() As Long
    If mKeyCount = 0 Then RegisterKeys
    ShortcutCount = mKeyCount
End Function
