Attribute VB_Name = "modFormatLayout"
'==============================================================================
' SPDX-License-Identifier: MIT
' XcelCraft - modFormatLayout
' Format & Layout category (the entries not already covered elsewhere).
'==============================================================================
Option Explicit

Public Sub XC_ClearHeadersFooters()
    On Error GoTo eh
    Dim sh As Object, n As Long
    If Not AskYesNo("Clear all headers and footers on the " & ActiveWindow.SelectedSheets.Count & " selected sheet(s)?") Then Exit Sub
    SafeStart
    Application.PrintCommunication = False
    For Each sh In ActiveWindow.SelectedSheets
        With sh.PageSetup
            .LeftHeader = "": .CenterHeader = "": .RightHeader = ""
            .LeftFooter = "": .CenterFooter = "": .RightFooter = ""
        End With
        n = n + 1
    Next sh
    Application.PrintCommunication = True
    SafeEnd
    Done "Headers and footers cleared on " & Plural(n, "sheet") & "."
    Exit Sub
eh:
    Application.PrintCommunication = True
    ReportError "Clear All Headers and Footers"
End Sub

Public Sub XC_WrapText()
    On Error Resume Next
    If TypeName(Selection) <> "Range" Then Exit Sub
    Selection.WrapText = True
End Sub

Public Sub XC_UnwrapText()
    On Error Resume Next
    If TypeName(Selection) <> "Range" Then Exit Sub
    Selection.WrapText = False
End Sub

' Draws a border around the data on each printed page (uses the sheet's page breaks).
Public Sub XC_BorderAroundPrintedPages()
    On Error GoTo eh
    Dim ws As Worksheet, pa As Range, hpb As HPageBreak, vpb As VPageBreak, rowsB As Collection, colsB As Collection
    Dim r0 As Long, c0 As Long, r As Variant, c As Variant, lastR As Long, lastC As Long, n As Long, blk As Range, prevR As Long, prevC As Long
    Set ws = ActiveSheet
    If Len(ws.PageSetup.PrintArea) > 0 Then Set pa = ws.Range(ws.PageSetup.PrintArea) Else Set pa = ws.UsedRange
    SafeStart "Adding page borders"
    ws.DisplayPageBreaks = True
    Set rowsB = New Collection: Set colsB = New Collection
    For Each hpb In ws.HPageBreaks
        If hpb.Location.Row > pa.Row And hpb.Location.Row <= pa.Row + pa.Rows.Count - 1 Then rowsB.Add hpb.Location.Row
    Next hpb
    rowsB.Add pa.Row + pa.Rows.Count
    For Each vpb In ws.VPageBreaks
        If vpb.Location.Column > pa.Column And vpb.Location.Column <= pa.Column + pa.Columns.Count - 1 Then colsB.Add vpb.Location.Column
    Next vpb
    colsB.Add pa.Column + pa.Columns.Count
    prevR = pa.Row
    For Each r In rowsB
        prevC = pa.Column
        For Each c In colsB
            Set blk = ws.Range(ws.Cells(prevR, prevC), ws.Cells(CLng(r) - 1, CLng(c) - 1))
            blk.BorderAround LineStyle:=xlContinuous, Weight:=xlMedium
            n = n + 1
            prevC = CLng(c)
        Next c
        prevR = CLng(r)
    Next r
    SafeEnd
    Done "Border added around " & Plural(n, "printed page") & "."
    Exit Sub
eh:
    ReportError "Add a Border Around the Data on Each Printed Page"
End Sub

Public Sub XC_RemoveInsideBorders()
    On Error Resume Next
    Dim a As Range
    If TypeName(Selection) <> "Range" Then Exit Sub
    For Each a In Selection.Areas
        a.Borders(xlInsideHorizontal).LineStyle = xlNone
        a.Borders(xlInsideVertical).LineStyle = xlNone
    Next a
End Sub

Public Sub XC_UnmergeCells()
    On Error GoTo eh
    Dim rng As Range, c As Range, n As Long, ma As Range, v As Variant, fillAll As Boolean
    Set rng = SelRange()
    If rng Is Nothing Then Exit Sub
    fillAll = AskYesNo("After unmerging, copy the value into every cell of each former merged area?" & vbCrLf & "(No = value stays in the top-left cell only)", False)
    SafeStart "Unmerging"
    For Each c In rng.Cells
        If c.MergeCells Then
            Set ma = c.MergeArea
            If ma.Cells(1).Address = c.Address Then
                v = c.Value
                ma.UnMerge
                If fillAll Then ma.Value = v
                n = n + 1
            End If
        End If
    Next c
    SafeEnd
    Done "Unmerge: " & Plural(n, "merged area") & " unmerged."
    Exit Sub
eh:
    ReportError "Unmerge Selected Cells"
End Sub

Public Sub XC_CenterAcrossSelection()
    On Error GoTo eh
    Dim rng As Range, a As Range, r As Long
    Set rng = SelRange()
    If rng Is Nothing Then Exit Sub
    SafeStart
    For Each a In rng.Areas
        If a.MergeCells Then a.UnMerge
        For r = 1 To a.Rows.Count
            a.Rows(r).HorizontalAlignment = xlCenterAcrossSelection
        Next r
    Next a
    SafeEnd
    Exit Sub
eh:
    ReportError "Center Horizontally Across Selection Without Merging"
End Sub

Public Sub XC_RemoveDataValidation()
    On Error GoTo eh
    Dim rng As Range
    Set rng = SelRange()
    If rng Is Nothing Then Exit Sub
    rng.Validation.Delete
    Done "Data validation removed from " & rng.Address(False, False) & "."
    Exit Sub
eh:
    ReportError "Remove All Data Validation"
End Sub

Public Sub XC_RemoveConditionalFormatting()
    On Error GoTo eh
    Dim rng As Range
    Set rng = SelRange()
    If rng Is Nothing Then Exit Sub
    rng.FormatConditions.Delete
    Done "Conditional formatting removed from " & rng.Address(False, False) & "."
    Exit Sub
eh:
    ReportError "Remove All Conditional Formatting"
End Sub

' Copies only chosen formatting aspects from the active cell to a target range.
Public Sub XC_CopyCertainFormatting()
    On Error GoTo eh
    Dim src As Range, tgt As Range, opts As String, c As Range, e As Variant
    If TypeName(Selection) <> "Range" Then Exit Sub
    Set src = ActiveCell
    opts = AskText("Copy from " & src.Address(False, False) & ". Enter the numbers of the settings to copy, separated by commas:" & vbCrLf & vbCrLf & _
                   "1. Number format" & vbCrLf & "2. Font name and size" & vbCrLf & "3. Font color" & vbCrLf & "4. Bold / italic / underline" & vbCrLf & _
                   "5. Fill color" & vbCrLf & "6. Borders" & vbCrLf & "7. Alignment (horizontal, vertical, wrap, indent)" & vbCrLf & _
                   "8. Column width" & vbCrLf & "9. Row height" & vbCrLf & "10. Protection (locked/hidden)", "1,3,5", "Copy Certain Formatting")
    If Len(opts) = 0 Then Exit Sub
    Set tgt = AskRange("Select the target range:")
    If tgt Is Nothing Then Exit Sub
    opts = "," & Replace(opts, " ", "") & ","
    SafeStart "Applying formatting"
    If InStr(opts, ",1,") > 0 Then tgt.NumberFormat = src.NumberFormat
    If InStr(opts, ",2,") > 0 Then tgt.Font.Name = src.Font.Name: tgt.Font.Size = src.Font.Size
    If InStr(opts, ",3,") > 0 Then tgt.Font.Color = src.Font.Color
    If InStr(opts, ",4,") > 0 Then tgt.Font.Bold = src.Font.Bold: tgt.Font.Italic = src.Font.Italic: tgt.Font.Underline = src.Font.Underline
    If InStr(opts, ",5,") > 0 Then
        If src.Interior.ColorIndex = xlColorIndexNone Then tgt.Interior.ColorIndex = xlColorIndexNone Else tgt.Interior.Color = src.Interior.Color
    End If
    If InStr(opts, ",6,") > 0 Then
        For Each c In tgt.Cells
            For Each e In Array(xlEdgeLeft, xlEdgeTop, xlEdgeBottom, xlEdgeRight)
                If src.Borders(e).LineStyle = xlNone Then
                    c.Borders(e).LineStyle = xlNone
                Else
                    c.Borders(e).LineStyle = src.Borders(e).LineStyle: c.Borders(e).Weight = src.Borders(e).Weight: c.Borders(e).Color = src.Borders(e).Color
                End If
            Next e
        Next c
    End If
    If InStr(opts, ",7,") > 0 Then
        tgt.HorizontalAlignment = src.HorizontalAlignment: tgt.VerticalAlignment = src.VerticalAlignment
        tgt.WrapText = src.WrapText: tgt.IndentLevel = src.IndentLevel
    End If
    If InStr(opts, ",8,") > 0 Then tgt.ColumnWidth = src.ColumnWidth
    If InStr(opts, ",9,") > 0 Then tgt.RowHeight = src.RowHeight
    If InStr(opts, ",10,") > 0 Then tgt.Locked = src.Locked: tgt.FormulaHidden = src.FormulaHidden
    SafeEnd
    Exit Sub
eh:
    ReportError "Copy and Apply Certain Cell Formatting Settings"
End Sub

Public Sub XC_ResetToNormalStyle()
    On Error GoTo eh
    Dim rng As Range
    Set rng = SelRange()
    If rng Is Nothing Then Exit Sub
    SnapshotRange rng, "Reset Formatting", True
    SafeStart
    rng.ClearFormats
    rng.Style = "Normal"
    SafeEnd
    Exit Sub
eh:
    ReportError "Reset Formatting to Normal Style"
End Sub
