Attribute VB_Name = "modFile"
'==============================================================================
' SPDX-License-Identifier: MIT
' XcelCraft - modFile
' File & System category, Start (launch helpers), quick-save tools and
' file optimization. Original implementation.
'==============================================================================
Option Explicit

Private Function Sep() As String
    Sep = Application.PathSeparator
End Function

Private Function BaseName(ByVal fullName As String) As String
    Dim p As Long
    p = InStrRev(fullName, Sep())
    BaseName = Mid$(fullName, p + 1)
End Function

Private Function StripExt(ByVal nm As String) As String
    Dim p As Long
    p = InStrRev(nm, ".")
    If p > 0 Then StripExt = Left$(nm, p - 1) Else StripExt = nm
End Function

Private Function ExtOf(ByVal nm As String) As String
    Dim p As Long
    p = InStrRev(nm, ".")
    If p > 0 Then ExtOf = Mid$(nm, p) Else ExtOf = ""
End Function

Private Function FileExists(ByVal p As String) As Boolean
    On Error Resume Next
    FileExists = (Len(Dir(p)) > 0)
End Function

'--- Save / rename / reopen -----------------------------------------------------------
Public Sub XC_SaveWithBackup()
    On Error GoTo eh
    Dim wb As Workbook, bak As String, folder As String
    Set wb = ActiveWorkbook
    If Len(wb.Path) = 0 Then MsgBox "Save the workbook once first (it has no file name yet).", vbInformation, APP_NAME: Exit Sub
    folder = GetSetting(REG_APP, "File", "BackupFolder", "")
    If Len(folder) = 0 Then folder = wb.Path
    bak = folder & Sep() & StripExt(wb.Name) & "_" & Format$(Now, "yyyy-mm-dd_hhnnss") & ExtOf(wb.Name)
    SafeStart "Saving"
    wb.Save
    wb.SaveCopyAs bak
    SafeEnd
    Done "Saved. Backup copy: " & bak
    Exit Sub
eh:
    ReportError "Save File and Create Backup Copy"
End Sub

Public Sub XC_SetBackupFolder()
    Dim f As String
    f = modFill.PickFolder()
    If Len(f) > 0 Then SaveSetting REG_APP, "File", "BackupFolder", f: MsgBox "Backups will be saved to " & f, vbInformation, APP_NAME
End Sub

Public Sub XC_SaveAsFirstCellName()
    On Error GoTo eh
    Dim nm As String, f As Variant, bad As Variant, i As Long
    If TypeName(Selection) <> "Range" Then Exit Sub
    nm = Trim$(ActiveCell.Text)
    If Len(nm) = 0 Then nm = Trim$(ActiveSheet.Range("A1").Text)
    bad = Array("\", "/", ":", "*", "?", """", "<", ">", "|")
    For i = LBound(bad) To UBound(bad): nm = Replace(nm, bad(i), "_"): Next i
    If Len(nm) = 0 Then nm = StripExt(ActiveWorkbook.Name)
    f = Application.GetSaveAsFilename(InitialFileName:=nm & ".xlsx", FileFilter:="Excel Workbook (*.xlsx), *.xlsx, Macro-enabled (*.xlsm), *.xlsm")
    If VarType(f) = vbBoolean Then Exit Sub
    If LCase$(Right$(f, 5)) = ".xlsm" Then
        ActiveWorkbook.SaveAs f, xlOpenXMLWorkbookMacroEnabled
    Else
        ActiveWorkbook.SaveAs f, xlOpenXMLWorkbook
    End If
    Exit Sub
eh:
    ReportError "Save As with First Cell as File Name"
End Sub

Public Sub XC_RenameCurrentFile()
    On Error GoTo eh
    Dim wb As Workbook, nm As String, oldPath As String, newPath As String
    Set wb = ActiveWorkbook
    If Len(wb.Path) = 0 Then MsgBox "The workbook has not been saved yet.", vbInformation, APP_NAME: Exit Sub
    nm = AskText("New file name (without folder):", wb.Name, "Rename Current File")
    If Len(nm) = 0 Or nm = wb.Name Then Exit Sub
    If Len(ExtOf(nm)) = 0 Then nm = nm & ExtOf(wb.Name)
    oldPath = wb.FullName
    newPath = wb.Path & Sep() & nm
    If FileExists(newPath) Then MsgBox "A file with that name already exists.", vbExclamation, APP_NAME: Exit Sub
    SafeStart "Renaming"
    wb.SaveAs newPath, wb.FileFormat
    Kill oldPath
    SafeEnd
    Done "Renamed to " & nm & " (the old file was deleted)."
    Exit Sub
eh:
    ReportError "Rename Current File"
End Sub

Public Sub XC_ReopenWithoutSaving()
    On Error GoTo eh
    Dim p As String, wb As Workbook
    Set wb = ActiveWorkbook
    If Len(wb.Path) = 0 Then MsgBox "The workbook has not been saved yet.", vbInformation, APP_NAME: Exit Sub
    If Not AskYesNo("Discard all unsaved changes and reopen '" & wb.Name & "' from disk?", False) Then Exit Sub
    p = wb.FullName
    Application.DisplayAlerts = False
    wb.Close SaveChanges:=False
    Application.DisplayAlerts = True
    Workbooks.Open p
    Exit Sub
eh:
    ReportError "Reopen Current File Without Saving"
End Sub

Public Sub XC_ForceSave()
    On Error GoTo eh
    Application.EnableEvents = False
    ActiveWorkbook.Save
    Application.EnableEvents = True
    Done "Saved (Workbook_BeforeSave events were bypassed)."
    Exit Sub
eh:
    Application.EnableEvents = True
    ReportError "Force Save Workbook"
End Sub

'--- External references ----------------------------------------------------------
Public Sub XC_FindRemoveExternalRefs()
    On Error GoTo eh
    Dim wb As Workbook, links As Variant, i As Long, s As String, mode As Long, ws As Worksheet, fr As Range, c As Range, n As Long, rpt As Worksheet, r As Long
    Set wb = ActiveWorkbook
    links = wb.LinkSources(xlExcelLinks)
    mode = AskChoice("External references (links to other workbooks):", Array( _
        "List linked workbooks", "List every formula that references another workbook (new workbook)", _
        "Break all links (formulas become values)", "Convert formulas with external references to values (selected sheets only)"))
    If mode = 0 Then Exit Sub
    Select Case mode
        Case 1
            If IsArray(links) Then
                For i = LBound(links) To UBound(links): s = s & links(i) & vbCrLf: Next i
                MsgBox "Linked workbooks:" & vbCrLf & vbCrLf & s, vbInformation, APP_NAME
            Else
                MsgBox "No links to other workbooks found (names and formulas).", vbInformation, APP_NAME
            End If
        Case 2
            SafeStart "Listing"
            Set rpt = NewReportSheet("External refs")
            rpt.Range("A1:C1").Value = Array("Sheet", "Cell", "Formula")
            rpt.Range("A1:C1").Font.Bold = True
            r = 2
            For Each ws In wb.Worksheets
                Set fr = Nothing
                On Error Resume Next
                Set fr = ws.UsedRange.SpecialCells(xlCellTypeFormulas)
                On Error GoTo eh
                If Not fr Is Nothing Then
                    For Each c In fr.Cells
                        If InStr(c.Formula, "[") > 0 And InStr(c.Formula, "]") > 0 Then
                            rpt.Cells(r, 1).Value = ws.Name: rpt.Cells(r, 2).Value = c.Address(False, False): rpt.Cells(r, 3).Value = "'" & c.Formula
                            r = r + 1
                        End If
                    Next c
                End If
            Next ws
            rpt.Columns("A:C").AutoFit
            SafeEnd
            Done Plural(r - 2, "external formula") & " listed."
        Case 3
            If Not IsArray(links) Then MsgBox "No links found.", vbInformation, APP_NAME: Exit Sub
            If Not AskYesNo("Break " & (UBound(links) - LBound(links) + 1) & " link(s)? Linked formulas become values. This cannot be undone.", False) Then Exit Sub
            SafeStart "Breaking links"
            For i = LBound(links) To UBound(links)
                wb.BreakLink Name:=links(i), Type:=xlExcelLinks
            Next i
            SafeEnd
            Done "Links broken."
        Case 4
            SafeStart "Converting"
            Dim sh As Object
            For Each sh In ActiveWindow.SelectedSheets
                If TypeName(sh) = "Worksheet" Then
                    Set fr = Nothing
                    On Error Resume Next
                    Set fr = sh.UsedRange.SpecialCells(xlCellTypeFormulas)
                    On Error GoTo eh
                    If Not fr Is Nothing Then
                        For Each c In fr.Cells
                            If InStr(c.Formula, "[") > 0 And InStr(c.Formula, "]") > 0 Then c.Value = c.Value: n = n + 1
                        Next c
                    End If
                End If
            Next sh
            SafeEnd
            Done Plural(n, "formula") & " converted to values."
    End Select
    Exit Sub
eh:
    ReportError "Find and Remove External References"
End Sub

'--- Default file location / title bar -------------------------------------------------
Public Sub XC_ChangeDefaultFileLocation()
    On Error GoTo eh
    Dim f As String
    f = modFill.PickFolder()
    If Len(f) = 0 Then Exit Sub
    Application.DefaultFilePath = f
    Done "Excel's default file location is now " & f & " (permanent setting)."
    Exit Sub
eh:
    ReportError "Change Excel's Default File Location"
End Sub

Public Sub XC_TempDefaultToCurrentFolder()
    On Error GoTo eh
    If Len(ActiveWorkbook.Path) = 0 Then MsgBox "The workbook has not been saved yet.", vbInformation, APP_NAME: Exit Sub
    ChDir ActiveWorkbook.Path
    #If Not Mac Then
        If Mid$(ActiveWorkbook.Path, 2, 1) = ":" Then ChDrive Left$(ActiveWorkbook.Path, 1)
    #End If
    Done "Open/Save dialogs now start in " & ActiveWorkbook.Path & " for this session."
    Exit Sub
eh:
    ReportError "Set Temporary Default File Location"
End Sub

Public Sub XC_ShowPathInTitleBar()
    On Error Resume Next
    ActiveWindow.Caption = ActiveWorkbook.FullName
End Sub

Public Sub XC_ShowNameInTitleBar()
    On Error Resume Next
    ActiveWindow.Caption = ActiveWorkbook.Name
End Sub

'--- Close tools -------------------------------------------------------------------------
Public Sub XC_CloseAndDelete()
    On Error GoTo eh
    Dim wb As Workbook, p As String
    Set wb = ActiveWorkbook
    If Len(wb.Path) = 0 Then MsgBox "The workbook has not been saved; just close it without saving.", vbInformation, APP_NAME: Exit Sub
    If Not AskYesNo("Close '" & wb.Name & "' and PERMANENTLY delete the file from disk?" & vbCrLf & wb.FullName, False) Then Exit Sub
    p = wb.FullName
    wb.ChangeFileAccess xlReadOnly
    Kill p
    wb.Close SaveChanges:=False
    Exit Sub
eh:
    ReportError "Close and Delete Current File"
End Sub

Public Sub XC_CloseUnchanged()
    On Error GoTo eh
    Dim i As Long, n As Long, wb As Workbook
    For i = Application.Workbooks.Count To 1 Step -1
        Set wb = Application.Workbooks(i)
        If wb.Saved And Not wb.IsAddin And wb.Name <> ThisWorkbook.Name Then wb.Close SaveChanges:=False: n = n + 1
    Next i
    Done "Close All Unchanged Files: " & Plural(n, "workbook") & " closed."
    Exit Sub
eh:
    ReportError "Close All Unchanged Files"
End Sub

Public Sub XC_CloseMultiple()
    On Error GoTo eh
    Dim i As Long, s As String, pick As String, parts() As String, p As Variant, names As Collection, nm As Variant, n As Long, saveMode As Long
    Set names = New Collection
    For i = 1 To Application.Workbooks.Count
        If Not Application.Workbooks(i).IsAddin Then
            names.Add Application.Workbooks(i).Name
            s = s & names.Count & ". " & Application.Workbooks(i).Name & IIf(Application.Workbooks(i).Saved, "", "  (unsaved changes)") & vbCrLf
        End If
    Next i
    pick = AskText("Enter the numbers of the workbooks to close, separated by commas, or * for all:" & vbCrLf & vbCrLf & s, "", "Close Multiple Files")
    If Len(pick) = 0 Then Exit Sub
    saveMode = AskChoice("Unsaved changes:", Array("Ask for each file", "Save all", "Discard all"))
    If saveMode = 0 Then Exit Sub
    parts = Split(Replace(pick, " ", ""), ",")
    For i = names.Count To 1 Step -1
        For Each p In parts
            If p = "*" Or Val(p) = i Then
                With Application.Workbooks(names(i))
                    If .Name <> ThisWorkbook.Name Then
                        Select Case saveMode
                            Case 1: .Close
                            Case 2: .Close SaveChanges:=True
                            Case 3: .Close SaveChanges:=False
                        End Select
                        n = n + 1
                    End If
                End With
                Exit For
            End If
        Next p
    Next i
    Done "Close Multiple Files: " & Plural(n, "workbook") & " closed."
    Exit Sub
eh:
    ReportError "Close Multiple Files"
End Sub

Public Sub XC_CloseAllWithoutSaving()
    On Error GoTo eh
    Dim i As Long, n As Long
    If Not AskYesNo("Close ALL open workbooks WITHOUT saving changes?", False) Then Exit Sub
    For i = Application.Workbooks.Count To 1 Step -1
        If Not Application.Workbooks(i).IsAddin And Application.Workbooks(i).Name <> ThisWorkbook.Name Then
            Application.Workbooks(i).Close SaveChanges:=False: n = n + 1
        End If
    Next i
    Exit Sub
eh:
    ReportError "Close All Open Files Without Saving"
End Sub

'--- Recent files ------------------------------------------------------------------------
Public Sub XC_AddToRecentFiles()
    On Error GoTo eh
    If Len(ActiveWorkbook.Path) = 0 Then MsgBox "The workbook has not been saved yet.", vbInformation, APP_NAME: Exit Sub
    Application.RecentFiles.Add ActiveWorkbook.FullName
    Done "Added to the recent files list."
    Exit Sub
eh:
    ReportError "Add Current File to Recent Files List"
End Sub

Public Sub XC_ClearRecentFiles()
    On Error GoTo eh
    Dim i As Long, s As String, pick As String, parts() As String, p As Variant, n As Long, cnt As Long
    cnt = Application.RecentFiles.Count
    If cnt = 0 Then MsgBox "The recent files list is empty.", vbInformation, APP_NAME: Exit Sub
    For i = 1 To cnt
        s = s & i & ". " & Application.RecentFiles(i).Name & vbCrLf
        If i >= 40 Then s = s & "..." & vbCrLf: Exit For
    Next i
    pick = AskText("Enter the numbers of the entries to remove, separated by commas, or * for all:" & vbCrLf & vbCrLf & s, "", "Clear Recent Files")
    If Len(pick) = 0 Then Exit Sub
    parts = Split(Replace(pick, " ", ""), ",")
    For i = cnt To 1 Step -1
        For Each p In parts
            If p = "*" Or Val(p) = i Then Application.RecentFiles(i).Delete: n = n + 1: Exit For
        Next p
    Next i
    Done Plural(n, "entry", "entries") & " removed from the recent files list."
    Exit Sub
eh:
    ReportError "Clear Multiple Files from Recent Files List"
End Sub

'--- Macros ----------------------------------------------------------------------------------
' Saves a macro-free copy (.xlsx) next to the workbook; the most reliable way without VBE access.
Public Sub XC_RemoveAllMacros()
    On Error GoTo eh
    Dim wb As Workbook, p As String, tmp As String, wb2 As Workbook
    Set wb = ActiveWorkbook
    If Len(wb.Path) = 0 Then MsgBox "Save the workbook first.", vbInformation, APP_NAME: Exit Sub
    p = wb.Path & Sep() & StripExt(wb.Name) & " (no macros).xlsx"
    If Not AskYesNo("Save a macro-free copy as:" & vbCrLf & p & vbCrLf & vbCrLf & "The current file is left unchanged. Continue?") Then Exit Sub
    SafeStart "Saving"
    tmp = wb.Path & Sep() & "~xlu_tmp_" & Format$(Now, "hhnnss") & ExtOf(wb.Name)
    wb.SaveCopyAs tmp
    Application.DisplayAlerts = False
    Set wb2 = Workbooks.Open(tmp)
    wb2.SaveAs p, xlOpenXMLWorkbook
    wb2.Close SaveChanges:=False
    Application.DisplayAlerts = True
    Kill tmp
    SafeEnd
    Done "Macro-free copy saved: " & p
    Exit Sub
eh:
    Application.DisplayAlerts = True
    ReportError "Remove All Macros"
End Sub

'--- Explorer / Finder, window ----------------------------------------------------------------
Public Sub XC_OpenFileLocation()
    On Error GoTo eh
    If Len(ActiveWorkbook.Path) = 0 Then MsgBox "The workbook has not been saved yet.", vbInformation, APP_NAME: Exit Sub
    #If Mac Then
        MacScript "tell application ""Finder"" to reveal POSIX file """ & ActiveWorkbook.FullName & """" & vbLf & "tell application ""Finder"" to activate"
    #Else
        Shell "explorer.exe /select,""" & ActiveWorkbook.FullName & """", vbNormalFocus
    #End If
    Exit Sub
eh:
    ReportError "Open Workbook's File Location"
End Sub

Public Sub XC_ResizeExcelWindow()
    On Error GoTo eh
    Dim c As Long, sizes As Variant
    sizes = Array("1024 x 768", "1280 x 720", "1280 x 800", "1366 x 768", "1440 x 900", "1600 x 900", "1920 x 1080", "Maximize")
    c = AskChoice("Resize the Excel window to (pixels):", sizes)
    If c = 0 Then Exit Sub
    If c = 8 Then Application.WindowState = xlMaximized: Exit Sub
    Application.WindowState = xlNormal
    Application.Width = Val(Split(sizes(c - 1), " x ")(0)) * 0.75
    Application.Height = Val(Split(sizes(c - 1), " x ")(1)) * 0.75
    Application.Left = 0: Application.Top = 0
    Exit Sub
eh:
    ReportError "Resize Excel Window"
End Sub

Public Sub XC_ReloadAddins()
    On Error GoTo eh
    Dim ai As AddIn, n As Long
    SafeStart "Reloading add-ins"
    For Each ai In Application.AddIns
        If ai.Installed And ai.Name <> ThisWorkbook.Name Then
            ai.Installed = False
            ai.Installed = True
            n = n + 1
        End If
    Next ai
    SafeEnd
    BuildMenu
    Done "Reloaded " & Plural(n, "add-in") & "."
    Exit Sub
eh:
    ReportError "Reload Installed Excel Add-ins"
End Sub

Public Sub XC_CreateFolderStructure()
    On Error GoTo eh
    Dim rng As Range, c As Range, root As String, p As String, n As Long, parts() As String, i As Long, cur As String
    Set rng = SelRange()
    If rng Is Nothing Then Exit Sub
    root = modFill.PickFolder()
    If Len(root) = 0 Then Exit Sub
    If Right$(root, 1) <> Sep() Then root = root & Sep()
    SafeStart "Creating folders"
    For Each c In rng.Cells
        p = Trim$(c.Text)
        If Len(p) > 0 Then
            p = Replace(Replace(p, "/", Sep()), "\", Sep())
            parts = Split(p, Sep())
            cur = root
            For i = LBound(parts) To UBound(parts)
                If Len(parts(i)) > 0 Then
                    cur = cur & parts(i) & Sep()
                    If Len(Dir(cur, vbDirectory)) = 0 Then MkDir cur: n = n + 1
                End If
            Next i
        End If
    Next c
    SafeEnd
    Done "Create Folder Structure: " & Plural(n, "folder") & " created under " & root
    Exit Sub
eh:
    ReportError "Create Folder Structure from Cell Values"
End Sub

Public Sub XC_UnloadAddin()
    On Error Resume Next
    Dim ai As AddIn
    If Not AskYesNo("Unload " & APP_NAME & " from Excel? (Re-enable it via File > Options > Add-ins.)", False) Then Exit Sub
    RemoveShortcuts
    RemoveMenu
    For Each ai In Application.AddIns
        If ai.Name = ThisWorkbook.Name Then ai.Installed = False
    Next ai
    ThisWorkbook.Close SaveChanges:=False
End Sub

'--- Start: launch helpers ---------------------------------------------------------------------
Private Sub LaunchApp(ByVal winCmd As String, ByVal macApp As String, ByVal nm As String)
    On Error GoTo eh
    #If Mac Then
        If Len(macApp) = 0 Then MsgBox nm & " is not available on Mac.", vbInformation, APP_NAME: Exit Sub
        MacScript "tell application """ & macApp & """ to activate"
    #Else
        Shell winCmd, vbNormalFocus
    #End If
    Exit Sub
eh:
    MsgBox "Could not start " & nm & ": " & Err.Description, vbExclamation, APP_NAME
End Sub

Public Sub XC_OpenCharMap(): LaunchApp "charmap.exe", "", "Character Map": End Sub
Public Sub XC_OpenCalculator(): LaunchApp "calc.exe", "Calculator", "Calculator": End Sub
Public Sub XC_OpenExplorer(): LaunchApp "explorer.exe", "Finder", "File Explorer": End Sub
Public Sub XC_OpenNotepad(): LaunchApp "notepad.exe", "TextEdit", "Notepad": End Sub

'--- Quick save variants ------------------------------------------------------------------------
Public Sub XC_QuickSave()
    On Error GoTo eh
    If Len(ActiveWorkbook.Path) = 0 Then
        Application.Dialogs(xlDialogSaveAs).Show
    Else
        ActiveWorkbook.Save
    End If
    Exit Sub
eh:
    ReportError "Quick Save"
End Sub

Public Sub XC_QuickSaveAs()
    On Error Resume Next
    Application.Dialogs(xlDialogSaveAs).Show
End Sub

Public Sub XC_QuickSaveAll()
    On Error GoTo eh
    Dim wb As Workbook, n As Long
    For Each wb In Application.Workbooks
        If Not wb.Saved And Not wb.IsAddin And Len(wb.Path) > 0 Then wb.Save: n = n + 1
    Next wb
    Done Plural(n, "workbook") & " saved."
    Exit Sub
eh:
    ReportError "Quick Save All"
End Sub

' Save Next Version: saves as a new version, e.g. Model v3.xlsx -> Model v4.xlsx (adds " v2" if none).
Public Sub XC_SaveNextVersion()
    On Error GoTo eh
    Dim wb As Workbook, baseNm As String, ext As String, i As Long, digits As String, ver As Long, newName As String, p As Long
    Set wb = ActiveWorkbook
    If Len(wb.Path) = 0 Then Application.Dialogs(xlDialogSaveAs).Show: Exit Sub
    baseNm = StripExt(wb.Name): ext = ExtOf(wb.Name)
    ' trailing digits
    i = Len(baseNm)
    Do While i > 0 And IsDigitChar(Mid$(baseNm, i, 1))
        i = i - 1
    Loop
    digits = Mid$(baseNm, i + 1)
    If Len(digits) > 0 Then
        ver = CLng(digits) + 1
        newName = Left$(baseNm, i) & Format$(ver, String$(Len(digits), "0"))
    Else
        newName = baseNm & " v2"
    End If
    newName = AskText("Save a new version as:", newName & ext, "Save Next Version")
    If Len(newName) = 0 Then Exit Sub
    wb.SaveAs wb.Path & Sep() & newName, wb.FileFormat
    Done "Saved as " & newName
    Exit Sub
eh:
    ReportError "Save Next Version"
End Sub

Public Sub XC_DeleteCommentsNotes()
    On Error GoTo eh
    Dim rng As Range, scope As Long, ws As Worksheet, n As Long
    scope = AskChoice("Delete comments and notes in:", Array("The selection", "The active sheet", "The whole workbook"))
    If scope = 0 Then Exit Sub
    SafeStart
    Select Case scope
        Case 1
            Set rng = SelRange()
            If Not rng Is Nothing Then
                Dim c As Range
                For Each c In rng.Cells: If Not c.Comment Is Nothing Then n = n + 1
                Next c
                rng.ClearComments
            End If
        Case 2: n = ActiveSheet.Comments.Count: ActiveSheet.Cells.ClearComments
        Case 3: For Each ws In ActiveWorkbook.Worksheets: n = n + ws.Comments.Count: ws.Cells.ClearComments: Next ws
    End Select
    SafeEnd
    Done Plural(n, "comment") & " deleted."
    Exit Sub
eh:
    ReportError "Delete Comments & Notes"
End Sub

' File optimization: resets used ranges, removes unused styles and broken names, reports size.
Public Sub XC_OptimizeFile()
    On Error GoTo eh
    Dim wb As Workbook, ws As Worksheet, before As Double, after As Double, opts As String, n As Long
    Set wb = ActiveWorkbook
    opts = AskText("File optimization. Enter the numbers to run, separated by commas:" & vbCrLf & vbCrLf & _
                   "1. Reset the used range of every sheet (delete empty ending rows/columns)" & vbCrLf & _
                   "2. Remove unused custom styles" & vbCrLf & _
                   "3. Delete names with #REF!" & vbCrLf & _
                   "4. Remove all conditional formatting from empty cells beyond the data" & vbCrLf & _
                   "5. Save and report the file size before/after", "1,2,3,5", "Optimize File")
    If Len(opts) = 0 Then Exit Sub
    opts = "," & Replace(opts, " ", "") & ","
    On Error Resume Next
    If Len(wb.Path) > 0 Then before = FileLen(wb.FullName)
    On Error GoTo eh
    SafeStart "Optimizing"
    If InStr(opts, ",1,") > 0 Then
        For Each ws In wb.Worksheets
            modSheets.ResetLastCellSilent ws
        Next ws
    End If
    If InStr(opts, ",2,") > 0 Then modSheets.RemoveUnusedStylesSilent
    If InStr(opts, ",3,") > 0 Then
        Dim i As Long
        For i = wb.Names.Count To 1 Step -1
            If InStr(wb.Names(i).RefersTo, "#REF") > 0 Then wb.Names(i).Delete
        Next i
    End If
    If InStr(opts, ",4,") > 0 Then
        For Each ws In wb.Worksheets
            Dim last As Range
            Set last = modSheets.RealLastCell(ws)
            If last.Row < ws.Rows.Count Then ws.Range(ws.Rows(last.Row + 1), ws.Rows(ws.Rows.Count)).FormatConditions.Delete
            If last.Column < ws.Columns.Count Then ws.Range(ws.Columns(last.Column + 1), ws.Columns(ws.Columns.Count)).FormatConditions.Delete
        Next ws
    End If
    If InStr(opts, ",5,") > 0 And Len(wb.Path) > 0 Then
        wb.Save
        after = FileLen(wb.FullName)
    End If
    SafeEnd
    If after > 0 Then
        Done "Optimize File: " & Format$(before / 1024, "#,##0") & " KB -> " & Format$(after / 1024, "#,##0") & " KB."
    Else
        Done "Optimize File: done (save the workbook to see the size change)."
    End If
    Exit Sub
eh:
    ReportError "Optimize File"
End Sub
