Attribute VB_Name = "modColsRows"
'==============================================================================
' SPDX-License-Identifier: MIT
' XcelCraft - modColsRows
' Columns & Rows category. Original implementation.
'==============================================================================
Option Explicit

'--- Select / hide / delete rows or columns by criteria ---------------------
Public Sub XC_RowsColsByCriteria()
    On Error GoTo eh
    Dim rng As Range, what As Long, cond As Long, crit As String, act As Long, i As Long, hit As Boolean
    Dim keyIdx As Variant, result As Range, ln As Range, cellV As String, n As Long, ws As Worksheet, cmp As Double
    Set rng = SelRangeOrRegion()
    If rng Is Nothing Then Exit Sub
    If rng.Areas.Count > 1 Then MsgBox "Please select one rectangular range.", vbExclamation, APP_NAME: Exit Sub
    Set ws = rng.Worksheet
    what = AskChoice("Work on:", Array("Rows (criteria tested in one column of the selection)", "Columns (criteria tested in one row of the selection)"))
    If what = 0 Then Exit Sub
    keyIdx = AskNumber(IIf(what = 1, "Which column of the selection holds the value to test? (1 = first)", "Which row of the selection holds the value to test? (1 = first)"), 1, "Rows/Columns by Criteria", 1, IIf(what = 1, rng.Columns.Count, rng.Rows.Count))
    If IsEmpty(keyIdx) Then Exit Sub
    cond = AskChoice("Condition:", Array("Equals", "Does not equal", "Contains", "Does not contain", "Starts with", "Ends with", "Is empty", "Is not empty", "Greater than (number)", "Less than (number)", "Is an error"))
    If cond = 0 Then Exit Sub
    If cond <= 6 Or cond = 9 Or cond = 10 Then
        crit = AskText("Value:", "", "Rows/Columns by Criteria")
        If StrPtr(crit) = 0 Then Exit Sub
    End If
    act = AskChoice("Action for the matching " & IIf(what = 1, "rows", "columns") & ":", Array("Select", "Hide", "Delete", "Color (light yellow)"))
    If act = 0 Then Exit Sub
    SafeStart "Applying criteria"
    For i = 1 To IIf(what = 1, rng.Rows.Count, rng.Columns.Count)
        If what = 1 Then Set ln = rng.Rows(i) Else Set ln = rng.Columns(i)
        If what = 1 Then cellV = CStr(rng.Cells(i, keyIdx).Text) Else cellV = CStr(rng.Cells(keyIdx, i).Text)
        hit = False
        Select Case cond
            Case 1: hit = (StrComp(cellV, crit, vbTextCompare) = 0)
            Case 2: hit = (StrComp(cellV, crit, vbTextCompare) <> 0)
            Case 3: hit = (InStr(1, cellV, crit, vbTextCompare) > 0)
            Case 4: hit = (InStr(1, cellV, crit, vbTextCompare) = 0)
            Case 5: hit = (StrComp(Left$(cellV, Len(crit)), crit, vbTextCompare) = 0)
            Case 6: hit = (StrComp(Right$(cellV, Len(crit)), crit, vbTextCompare) = 0)
            Case 7: hit = (Len(Trim$(cellV)) = 0)
            Case 8: hit = (Len(Trim$(cellV)) > 0)
            Case 9: If IsNumeric(cellV) And IsNumeric(crit) Then hit = (CDbl(cellV) > CDbl(crit))
            Case 10: If IsNumeric(cellV) And IsNumeric(crit) Then hit = (CDbl(cellV) < CDbl(crit))
            Case 11: hit = IsError(IIf(what = 1, rng.Cells(i, keyIdx).Value, rng.Cells(keyIdx, i).Value))
        End Select
        If hit Then
            If result Is Nothing Then Set result = ln Else Set result = Union(result, ln)
            n = n + 1
        End If
    Next i
    If Not result Is Nothing Then
        Select Case act
            Case 1: result.Select
            Case 2: If what = 1 Then result.EntireRow.Hidden = True Else result.EntireColumn.Hidden = True
            Case 3
                If what = 1 Then result.EntireRow.Delete Else result.EntireColumn.Delete
            Case 4: result.Interior.Color = RGB(255, 255, 204)
        End Select
    End If
    SafeEnd
    Done "Rows/Columns by Criteria: " & n & IIf(what = 1, " rows", " columns") & " matched."
    Exit Sub
eh:
    ReportError "Select, Hide or Delete Rows/Columns by Criteria"
End Sub

'--- Color every nth row/column ---------------------------------------------
Public Sub XC_ColorNthRowCol()
    On Error GoTo eh
    Dim rng As Range, what As Long, nth As Variant, offs As Variant, i As Long, n As Long, colorL As Long, mode As Long
    Set rng = SelRangeOrRegion()
    If rng Is Nothing Then Exit Sub
    what = AskChoice("Color every nth:", Array("Row", "Column"))
    If what = 0 Then Exit Sub
    nth = AskNumber("Every how many " & IIf(what = 1, "rows", "columns") & "? (2 = every second)", 2, "Color Every nth", 1)
    If IsEmpty(nth) Then Exit Sub
    offs = AskNumber("Start with " & IIf(what = 1, "row", "column") & " number (1 = first of the selection):", IIf(nth = 1, 1, 2), "Color Every nth", 1)
    If IsEmpty(offs) Then Exit Sub
    mode = AskChoice("Color:", Array("Light gray", "Light blue", "Light yellow", "Light green", "Remove fill (no color)"))
    If mode = 0 Then Exit Sub
    colorL = Choose(mode, RGB(242, 242, 242), RGB(221, 235, 247), RGB(255, 255, 204), RGB(226, 239, 218), -1)
    SafeStart "Coloring"
    For i = offs To IIf(what = 1, rng.Rows.Count, rng.Columns.Count) Step nth
        If what = 1 Then
            If colorL = -1 Then rng.Rows(i).Interior.ColorIndex = xlColorIndexNone Else rng.Rows(i).Interior.Color = colorL
        Else
            If colorL = -1 Then rng.Columns(i).Interior.ColorIndex = xlColorIndexNone Else rng.Columns(i).Interior.Color = colorL
        End If
        n = n + 1
    Next i
    SafeEnd
    Done "Color Every nth: " & n & IIf(what = 1, " rows", " columns") & " colored."
    Exit Sub
eh:
    ReportError "Color Every nth Row or Column"
End Sub

'--- Visual breaks between groups --------------------------------------------
Public Sub XC_InsertVisualBreaks()
    On Error GoTo eh
    Dim rng As Range, mode As Long, r As Long, n As Long, prev As String, cur As String, ws As Worksheet, col As Long
    Set rng = SelRange()
    If rng Is Nothing Then Exit Sub
    If rng.Columns.Count > 1 Then Set rng = rng.Columns(1)
    Set ws = rng.Worksheet: col = rng.Column
    mode = AskChoice("Where the value in column " & Split(rng.Cells(1).Address(True, False), "$")(0) & " changes from one row to the next:", Array( _
        "Insert an empty row", "Draw a border line between the groups", "Color alternate groups light gray"))
    If mode = 0 Then Exit Sub
    SafeStart "Inserting breaks"
    Dim toggle As Boolean
    If mode = 1 Then
        For r = rng.Rows.Count To 2 Step -1
            If CStr(rng.Cells(r, 1).Text) <> CStr(rng.Cells(r - 1, 1).Text) Then
                rng.Cells(r, 1).EntireRow.Insert
                n = n + 1
            End If
        Next r
    Else
        For r = 1 To rng.Rows.Count
            cur = CStr(rng.Cells(r, 1).Text)
            If r > 1 Then
                If cur <> prev Then
                    If mode = 2 Then
                        With ws.Range(ws.Cells(rng.Row + r - 1, rng.CurrentRegion.Column), ws.Cells(rng.Row + r - 1, rng.CurrentRegion.Column + rng.CurrentRegion.Columns.Count - 1)).Borders(xlEdgeTop)
                            .LineStyle = xlContinuous: .Weight = xlThin
                        End With
                    End If
                    toggle = Not toggle
                    n = n + 1
                End If
            End If
            If mode = 3 And toggle Then
                ws.Range(ws.Cells(rng.Row + r - 1, rng.CurrentRegion.Column), ws.Cells(rng.Row + r - 1, rng.CurrentRegion.Column + rng.CurrentRegion.Columns.Count - 1)).Interior.Color = RGB(242, 242, 242)
            End If
            prev = cur
        Next r
    End If
    SafeEnd
    Done "Insert Visual Breaks: " & Plural(n, "break") & " inserted."
    Exit Sub
eh:
    ReportError "Insert Visual Breaks Between Groups"
End Sub

'--- Join values --------------------------------------------------------------
Private Sub JoinValues(ByVal horizontal As Boolean, ByVal delim As String, ByVal toolName As String)
    On Error GoTo eh
    Dim rng As Range, i As Long, j As Long, s As String, parts As Collection, n As Long, mode As Long, ln As Range, c As Range, outCell As Range
    Dim skipBlank As Boolean
    Set rng = SelRange(True)
    If rng Is Nothing Then Exit Sub
    If rng.Areas.Count > 1 Then MsgBox "Please select one rectangular range.", vbExclamation, APP_NAME: Exit Sub
    mode = AskChoice("Put the joined text:", Array( _
        IIf(horizontal, "In the first cell of each row and clear the other cells", "In the top cell of each column and clear the other cells"), _
        IIf(horizontal, "In the column to the RIGHT of the selection (selection unchanged)", "In the row BELOW the selection (selection unchanged)")))
    If mode = 0 Then Exit Sub
    skipBlank = AskYesNo("Skip empty cells (avoids repeated separators)?")
    SnapshotRange rng, toolName
    SafeStart toolName
    For i = 1 To IIf(horizontal, rng.Rows.Count, rng.Columns.Count)
        If horizontal Then Set ln = rng.Rows(i) Else Set ln = rng.Columns(i)
        s = ""
        For Each c In ln.Cells
            If Not (skipBlank And Len(c.Text) = 0) Then
                If Len(s) > 0 Or (Not skipBlank And c.Address <> ln.Cells(1).Address) Then s = s & delim
                s = s & c.Text
            End If
        Next c
        If mode = 1 Then
            ln.ClearContents
            Set outCell = ln.Cells(1)
        Else
            If horizontal Then Set outCell = ln.Cells(1).Offset(0, rng.Columns.Count) Else Set outCell = ln.Cells(1).Offset(rng.Rows.Count, 0)
        End If
        WriteText outCell, s
        If InStr(s, vbLf) > 0 Then outCell.WrapText = True
        n = n + 1
    Next i
    SafeEnd
    Done toolName & ": " & n & IIf(horizontal, " rows", " columns") & " joined."
    Exit Sub
eh:
    ReportError toolName
End Sub

Public Sub XC_JoinHorizontal()
    Dim d As String
    If SelRange(True) Is Nothing Then Exit Sub
    d = AskText("Separator to put between the values (e.g. a comma, a space, ; ...):", ", ", "Join Horizontally")
    If StrPtr(d) = 0 Then Exit Sub
    JoinValues True, d, "Join Values Horizontally"
End Sub

Public Sub XC_JoinVertical()
    Dim d As String
    If SelRange(True) Is Nothing Then Exit Sub
    d = AskText("Separator to put between the values:", ", ", "Join Vertically")
    If StrPtr(d) = 0 Then Exit Sub
    JoinValues False, d, "Join Values Vertically"
End Sub

Public Sub XC_JoinVerticalLineBreak()
    JoinValues False, vbLf, "Join Values Vertically with Line Breaks"
End Sub

'--- Insert rows / columns -----------------------------------------------------
Public Sub XC_InsertBlankBetween()
    On Error GoTo eh
    Dim rng As Range, what As Long, cnt As Variant, i As Long, n As Long, k As Long
    Set rng = SelRange(True)
    If rng Is Nothing Then Exit Sub
    If rng.Areas.Count > 1 Then MsgBox "Please select one rectangular range.", vbExclamation, APP_NAME: Exit Sub
    what = AskChoice("Insert blank:", Array("Rows between every row of the selection", "Columns between every column of the selection"))
    If what = 0 Then Exit Sub
    cnt = AskNumber("How many blank " & IIf(what = 1, "rows", "columns") & " between each?", 1, "Insert Blank Rows/Columns", 1, 100)
    If IsEmpty(cnt) Then Exit Sub
    SafeStart "Inserting"
    If what = 1 Then
        For i = rng.Rows.Count To 2 Step -1
            For k = 1 To cnt: rng.Rows(i).EntireRow.Insert: n = n + 1: Next k
        Next i
    Else
        For i = rng.Columns.Count To 2 Step -1
            For k = 1 To cnt: rng.Columns(i).EntireColumn.Insert: n = n + 1: Next k
        Next i
    End If
    SafeEnd
    Done "Insert Blank Rows/Columns: " & n & " inserted."
    Exit Sub
eh:
    ReportError "Insert Blank Rows or Columns Between"
End Sub

Public Sub XC_InsertNRows()
    On Error GoTo eh
    Dim cnt As Variant, what As Long
    If TypeName(Selection) <> "Range" Then Exit Sub
    what = AskChoice("Insert:", Array("Rows above the active cell", "Columns to the left of the active cell"))
    If what = 0 Then Exit Sub
    cnt = AskNumber("How many?", 10, "Insert Rows/Columns", 1, 100000)
    If IsEmpty(cnt) Then Exit Sub
    SafeStart "Inserting"
    If what = 1 Then
        ActiveCell.EntireRow.Resize(CLng(cnt)).Insert Shift:=xlDown
    Else
        ActiveCell.EntireColumn.Resize(, CLng(cnt)).Insert Shift:=xlToRight
    End If
    SafeEnd
    Exit Sub
eh:
    ReportError "Insert a Specified Number of Rows"
End Sub

'--- Hidden rows / columns ---------------------------------------------------
Public Sub XC_UnhideRowsCols()
    On Error GoTo eh
    Dim scope As Long, what As Long, rng As Range, i As Long, s As String, n As Long, hiddenList As Collection, v As Variant, pick As String, parts() As String, p As Variant
    scope = AskChoice("Unhide in:", Array("The selection", "The whole sheet"))
    If scope = 0 Then Exit Sub
    what = AskChoice("Unhide:", Array("All hidden rows", "All hidden columns", "Both", "Choose from a list of hidden rows/columns"))
    If what = 0 Then Exit Sub
    If scope = 1 Then Set rng = SelRange(): If rng Is Nothing Then Exit Sub
    If scope = 2 Then Set rng = ActiveSheet.UsedRange
    SafeStart "Unhiding"
    If what = 4 Then
        Set hiddenList = New Collection
        For i = rng.Row To rng.Row + rng.Rows.Count - 1
            If ActiveSheet.Rows(i).Hidden Then hiddenList.Add "R" & i
        Next i
        For i = rng.Column To rng.Column + rng.Columns.Count - 1
            If ActiveSheet.Columns(i).Hidden Then hiddenList.Add "C" & Split(ActiveSheet.Columns(i).Address(True, False), ":")(0)
        Next i
        SafeEnd
        If hiddenList.Count = 0 Then MsgBox "No hidden rows or columns found.", vbInformation, APP_NAME: Exit Sub
        For Each v In hiddenList: s = s & v & "  ": Next v
        pick = AskText("Hidden (R=row, C=column): " & vbCrLf & s & vbCrLf & vbCrLf & "Enter the ones to unhide separated by commas (e.g. R5,C3), or * for all:", "*", "Unhide Rows/Columns")
        If Len(pick) = 0 Then Exit Sub
        SafeStart "Unhiding"
        parts = Split(Replace(pick, " ", ""), ",")
        For Each v In hiddenList
            For Each p In parts
                If p = "*" Or StrComp(p, v, vbTextCompare) = 0 Then
                    If Left$(v, 1) = "R" Then ActiveSheet.Rows(CLng(Mid$(v, 2))).Hidden = False Else ActiveSheet.Columns(Mid$(v, 2)).Hidden = False
                    n = n + 1
                    Exit For
                End If
            Next p
        Next v
    Else
        If what = 1 Or what = 3 Then
            For i = rng.Row To rng.Row + rng.Rows.Count - 1
                If ActiveSheet.Rows(i).Hidden Then ActiveSheet.Rows(i).Hidden = False: n = n + 1
            Next i
        End If
        If what = 2 Or what = 3 Then
            For i = rng.Column To rng.Column + rng.Columns.Count - 1
                If ActiveSheet.Columns(i).Hidden Then ActiveSheet.Columns(i).Hidden = False: n = n + 1
            Next i
        End If
    End If
    SafeEnd
    Done "Unhide: " & n & " rows/columns unhidden."
    Exit Sub
eh:
    ReportError "Choose and Unhide Hidden Rows and Columns"
End Sub

Public Sub XC_DeleteHiddenRowsCols()
    On Error GoTo eh
    Dim what As Long, ws As Worksheet, i As Long, n As Long, last As Range
    what = AskChoice("Delete on the active sheet:", Array("All hidden rows", "All hidden columns", "Both"))
    If what = 0 Then Exit Sub
    If Not AskYesNo("Hidden rows/columns and their contents will be permanently deleted. Continue?", False) Then Exit Sub
    Set ws = ActiveSheet
    Set last = modSheets.RealLastCell(ws)
    SafeStart "Deleting hidden rows/columns"
    If what = 1 Or what = 3 Then
        For i = last.Row To 1 Step -1
            If ws.Rows(i).Hidden Then ws.Rows(i).Delete: n = n + 1
        Next i
    End If
    If what = 2 Or what = 3 Then
        For i = last.Column To 1 Step -1
            If ws.Columns(i).Hidden Then ws.Columns(i).Delete: n = n + 1
        Next i
    End If
    SafeEnd
    Done "Delete Hidden Rows/Columns: " & n & " deleted."
    Exit Sub
eh:
    ReportError "Delete All Hidden Rows, Columns, or Both"
End Sub

'--- Empty rows / columns ----------------------------------------------------
Public Sub XC_DeleteEmptyRows()
    On Error GoTo eh
    Dim rng As Range, scope As Long, i As Long, n As Long, del As Range, ln As Range
    scope = AskChoice("Delete empty rows in:", Array("The selection (rows that are empty within the selected columns)", "The whole sheet (entirely empty rows within the used range)"))
    If scope = 0 Then Exit Sub
    If scope = 1 Then Set rng = SelRange(): If rng Is Nothing Then Exit Sub
    If scope = 2 Then Set rng = ActiveSheet.UsedRange
    If rng.Areas.Count > 1 Then Set rng = BoundingBox(rng)
    SafeStart "Deleting empty rows"
    For i = rng.Rows.Count To 1 Step -1
        If scope = 1 Then Set ln = rng.Rows(i) Else Set ln = rng.Rows(i).EntireRow
        If Application.WorksheetFunction.CountA(ln) = 0 Then
            If del Is Nothing Then Set del = ln.EntireRow Else Set del = Union(del, ln.EntireRow)
            n = n + 1
        End If
    Next i
    If Not del Is Nothing Then del.Delete
    SafeEnd
    Done "Delete All Empty Rows: " & Plural(n, "row") & " deleted."
    Exit Sub
eh:
    ReportError "Delete All Empty Rows"
End Sub

Public Sub XC_DeleteEmptyColumns()
    On Error GoTo eh
    Dim rng As Range, scope As Long, i As Long, n As Long, del As Range, ln As Range
    scope = AskChoice("Delete empty columns in:", Array("The selection (columns that are empty within the selected rows)", "The whole sheet (entirely empty columns within the used range)"))
    If scope = 0 Then Exit Sub
    If scope = 1 Then Set rng = SelRange(): If rng Is Nothing Then Exit Sub
    If scope = 2 Then Set rng = ActiveSheet.UsedRange
    If rng.Areas.Count > 1 Then Set rng = BoundingBox(rng)
    SafeStart "Deleting empty columns"
    For i = rng.Columns.Count To 1 Step -1
        If scope = 1 Then Set ln = rng.Columns(i) Else Set ln = rng.Columns(i).EntireColumn
        If Application.WorksheetFunction.CountA(ln) = 0 Then
            If del Is Nothing Then Set del = ln.EntireColumn Else Set del = Union(del, ln.EntireColumn)
            n = n + 1
        End If
    Next i
    If Not del Is Nothing Then del.Delete
    SafeEnd
    Done "Delete All Empty Columns: " & Plural(n, "column") & " deleted."
    Exit Sub
eh:
    ReportError "Delete All Empty Columns"
End Sub

'--- Autofit with merged cells ---------------------------------------------------
' Excel's AutoFit ignores merged cells. For each merged area in the selection we
' measure the text in a temporary cell as wide as the merged area and apply that height.
Public Sub XC_FixAutofitMerged()
    On Error GoTo eh
    Dim rng As Range, c As Range, ma As Range, ws As Worksheet, tmp As Range, w As Double, i As Long, h As Double, n As Long, doneRows As Collection
    Set rng = SelRangeOrRegion()
    If rng Is Nothing Then Exit Sub
    Set ws = rng.Worksheet
    SafeStart "Fitting row heights"
    rng.Rows.AutoFit
    Set tmp = ws.Cells(ws.Rows.Count, ws.Columns.Count)   ' far corner as scratch cell
    Set doneRows = New Collection
    For Each c In rng.Cells
        If c.MergeCells Then
            Set ma = c.MergeArea
            If ma.Cells(1).Address = c.Address And ma.Rows.Count = 1 And Len(c.Text) > 0 Then
                w = 0
                For i = 1 To ma.Columns.Count
                    If Not ma.Columns(i).Hidden Then w = w + ma.Columns(i).ColumnWidth
                Next i
                If w > 0 Then
                    tmp.ColumnWidth = w
                    tmp.WrapText = True
                    tmp.Font.Name = c.Font.Name: tmp.Font.Size = c.Font.Size: tmp.Font.Bold = c.Font.Bold
                    tmp.Value = c.Value
                    tmp.EntireRow.AutoFit
                    h = tmp.RowHeight
                    If h > ma.RowHeight Then ma.RowHeight = h
                    n = n + 1
                End If
            End If
        End If
    Next c
    tmp.ClearContents: tmp.ClearFormats
    ws.Rows(ws.Rows.Count).RowHeight = ws.StandardHeight
    ws.Columns(ws.Columns.Count).ColumnWidth = ws.StandardWidth
    SafeEnd
    Done "Fix Autofit with Merged Cells: " & Plural(n, "merged cell") & " adjusted."
    Exit Sub
eh:
    ReportError "Fix Autofit Row Height with Merged Cells"
End Sub

'--- Cell size in cm / inch / pixels ------------------------------------------
Public Sub XC_SetCellSize()
    On Error GoTo eh
    Dim rng As Range, unit As Long, w As Variant, h As Variant, ptW As Double, ptH As Double, factor As Double, ratio As Double
    Set rng = SelRange(False, True)
    If rng Is Nothing Then Exit Sub
    unit = AskChoice("Unit:", Array("Centimeters", "Inches", "Pixels (96 dpi)", "Points"))
    If unit = 0 Then Exit Sub
    factor = Choose(unit, 28.3465, 72, 0.75, 1)
    w = AskNumber("Column width (0 = leave unchanged):", 0, "Set Cell Size")
    If IsEmpty(w) Then Exit Sub
    h = AskNumber("Row height (0 = leave unchanged):", 0, "Set Cell Size")
    If IsEmpty(h) Then Exit Sub
    SafeStart "Resizing"
    If h > 0 Then rng.RowHeight = h * factor
    If w > 0 Then
        ptW = w * factor
        ' ColumnWidth is in characters; convert via the current points-per-character ratio
        ratio = rng.Cells(1).Width / rng.Cells(1).ColumnWidth
        If ratio <= 0 Then ratio = 5.4
        rng.ColumnWidth = ptW / ratio
        ' second pass corrects the padding offset
        ratio = rng.Cells(1).Width
        If ratio > 0 Then rng.ColumnWidth = rng.ColumnWidth * ptW / ratio
    End If
    SafeEnd
    Exit Sub
eh:
    ReportError "Set Cell Size"
End Sub

'--- Reshape single column into table ------------------------------------------
Public Sub XC_ReshapeColumnToTable()
    On Error GoTo eh
    Dim rng As Range, cols As Variant, order As Long, arr As Variant, out As Variant, n As Long, r As Long, c As Long, i As Long, tgt As Range, rowsOut As Long
    Set rng = SelRange()
    If rng Is Nothing Then Exit Sub
    If rng.Columns.Count > 1 Then MsgBox "Select a single column of values.", vbExclamation, APP_NAME: Exit Sub
    cols = AskNumber("Number of columns in the new table:", 3, "Reshape Column", 1, 16000)
    If IsEmpty(cols) Then Exit Sub
    order = AskChoice("Fill the table:", Array("Across then down (A B C / D E F)", "Down then across (A C E / B D F)"))
    If order = 0 Then Exit Sub
    Set tgt = AskRange("Select the top-left cell for the new table:")
    If tgt Is Nothing Then Exit Sub
    SafeStart "Reshaping"
    arr = RangeToArray(rng, True)
    n = UBound(arr, 1)
    rowsOut = -Int(-n / cols)
    ReDim out(1 To rowsOut, 1 To cols)
    For i = 1 To n
        If order = 1 Then
            r = (i - 1) \ cols + 1: c = (i - 1) Mod cols + 1
        Else
            c = (i - 1) \ rowsOut + 1: r = (i - 1) Mod rowsOut + 1
        End If
        out(r, c) = arr(i, 1)
    Next i
    tgt.Cells(1).Resize(rowsOut, cols).Formula = out
    SafeEnd
    Exit Sub
eh:
    ReportError "Reshape Single Column into Table"
End Sub

'--- Split long dataset for printing ------------------------------------------
' Puts blocks of N rows side by side on a new sheet so a long, narrow list prints on fewer pages.
Public Sub XC_SplitLongDataset()
    On Error GoTo eh
    Dim rng As Range, perBlock As Variant, hdr As Boolean, dst As Worksheet, r As Long, col As Long, firstRow As Long, blockRows As Long, gap As Long, n As Long
    Set rng = SelRangeOrRegion()
    If rng Is Nothing Then Exit Sub
    If rng.Areas.Count > 1 Then MsgBox "Please select one rectangular range.", vbExclamation, APP_NAME: Exit Sub
    hdr = AskYesNo("Does the first row contain headers (repeated above each block)?")
    perBlock = AskNumber("Rows per block (e.g. the number of rows that fit on one printed page):", 50, "Split Long Dataset", 1)
    If IsEmpty(perBlock) Then Exit Sub
    gap = 1
    firstRow = IIf(hdr, 2, 1)
    SafeStart "Splitting"
    Set dst = NewReportSheet(rng.Worksheet.Name & " print", False)
    col = 1: r = firstRow
    Do While r <= rng.Rows.Count
        blockRows = Min2(CLng(perBlock), rng.Rows.Count - r + 1)
        If hdr Then rng.Rows(1).Copy dst.Cells(1, col)
        rng.Rows(r).Resize(blockRows).Copy dst.Cells(IIf(hdr, 2, 1), col)
        col = col + rng.Columns.Count + gap
        r = r + blockRows
        n = n + 1
    Loop
    dst.Columns.AutoFit
    dst.Activate
    SafeEnd
    Done "Split Long Dataset: " & Plural(n, "block") & " placed side by side on '" & dst.Name & "'."
    Exit Sub
eh:
    ReportError "Split Long Dataset for Printing"
End Sub
