Attribute VB_Name = "modWebData"
'==============================================================================
' SPDX-License-Identifier: MIT
' XcelCraft - modWebData
' Web Data category. Original implementation.
'==============================================================================
Option Explicit

Public Sub XC_RemoveHtmlTags()
    On Error GoTo eh
    Dim rng As Range, n As Long, decodeToo As Boolean, c As Range, s As String, nv As String
    Set rng = SelRange()
    If rng Is Nothing Then Exit Sub
    decodeToo = AskYesNo("Also decode HTML entities (&amp; &lt; &nbsp; &#39; ...)?")
    SnapshotRange rng, "Remove HTML Tags"
    SafeStart "Removing HTML tags"
    For Each c In rng.Cells
        If Not c.HasFormula And VarType(c.Value) = vbString Then
            s = c.Value
            nv = modText.StripHtml(Replace(Replace(s, "<br>", vbLf, , , vbTextCompare), "<br/>", vbLf, , , vbTextCompare))
            If decodeToo Then nv = HtmlDecode(nv)
            If nv <> s Then WriteText c, nv: n = n + 1
        End If
    Next c
    SafeEnd
    Done "Remove HTML Tags: " & Plural(n, "cell") & " changed."
    Exit Sub
eh:
    ReportError "Remove All HTML Tags"
End Sub

Public Function HtmlDecode(ByVal s As String) As String
    Dim p As Long, q As Long, ent As String, code As Long, repl As String
    s = Replace(s, "&nbsp;", " ", , , vbTextCompare)
    s = Replace(s, "&lt;", "<", , , vbTextCompare)
    s = Replace(s, "&gt;", ">", , , vbTextCompare)
    s = Replace(s, "&quot;", """", , , vbTextCompare)
    s = Replace(s, "&apos;", "'", , , vbTextCompare)
    s = Replace(s, "&copy;", ChrW(169), , , vbTextCompare)
    s = Replace(s, "&reg;", ChrW(174), , , vbTextCompare)
    s = Replace(s, "&euro;", ChrW(8364), , , vbTextCompare)
    s = Replace(s, "&pound;", ChrW(163), , , vbTextCompare)
    s = Replace(s, "&yen;", ChrW(165), , , vbTextCompare)
    s = Replace(s, "&mdash;", ChrW(8212), , , vbTextCompare)
    s = Replace(s, "&ndash;", ChrW(8211), , , vbTextCompare)
    s = Replace(s, "&hellip;", ChrW(8230), , , vbTextCompare)
    ' numeric entities &#NNN; and &#xHH;
    p = InStr(s, "&#")
    Do While p > 0
        q = InStr(p, s, ";")
        If q = 0 Then Exit Do
        ent = Mid$(s, p + 2, q - p - 2)
        code = -1
        On Error Resume Next
        If LCase$(Left$(ent, 1)) = "x" Then code = CLng("&H" & Mid$(ent, 2)) Else code = CLng(ent)
        On Error GoTo 0
        If code >= 0 And code < 65536 Then
            repl = ChrW(code)
            s = Left$(s, p - 1) & repl & Mid$(s, q + 1)
            p = InStr(p + Len(repl), s, "&#")
        Else
            p = InStr(q, s, "&#")
        End If
    Loop
    s = Replace(s, "&amp;", "&", , , vbTextCompare)
    HtmlDecode = s
End Function

Public Function UrlDecode(ByVal s As String) As String
    Dim i As Long, ch As String, out As String, hx As String, bytes() As Byte, nb As Long
    s = Replace(s, "+", " ")
    i = 1
    Do While i <= Len(s)
        ch = Mid$(s, i, 1)
        If ch = "%" And i + 2 <= Len(s) Then
            hx = Mid$(s, i + 1, 2)
            If IsHex(hx) Then
                ' collect consecutive %XX bytes to decode UTF-8 sequences
                ReDim bytes(0 To 0): nb = 0
                Do While Mid$(s, i, 1) = "%" And i + 2 <= Len(s) And IsHex(Mid$(s, i + 1, 2))
                    ReDim Preserve bytes(0 To nb)
                    bytes(nb) = CByte("&H" & Mid$(s, i + 1, 2))
                    nb = nb + 1
                    i = i + 3
                Loop
                out = out & Utf8BytesToString(bytes, nb)
            Else
                out = out & ch: i = i + 1
            End If
        Else
            out = out & ch: i = i + 1
        End If
    Loop
    UrlDecode = out
End Function

Private Function IsHex(ByVal s As String) As Boolean
    Dim i As Long, ch As String
    If Len(s) = 0 Then Exit Function
    For i = 1 To Len(s)
        ch = UCase$(Mid$(s, i, 1))
        If Not ((ch >= "0" And ch <= "9") Or (ch >= "A" And ch <= "F")) Then Exit Function
    Next i
    IsHex = True
End Function

Private Function Utf8BytesToString(ByRef b() As Byte, ByVal n As Long) As String
    Dim i As Long, cp As Long, out As String, extra As Long
    i = 0
    Do While i < n
        If b(i) < 128 Then
            cp = b(i): extra = 0
        ElseIf (b(i) And &HE0) = &HC0 Then
            cp = b(i) And &H1F: extra = 1
        ElseIf (b(i) And &HF0) = &HE0 Then
            cp = b(i) And &HF: extra = 2
        ElseIf (b(i) And &HF8) = &HF0 Then
            cp = b(i) And &H7: extra = 3
        Else
            cp = b(i): extra = 0
        End If
        i = i + 1
        Do While extra > 0 And i < n
            cp = cp * 64 + (b(i) And &H3F)
            i = i + 1: extra = extra - 1
        Loop
        If cp < 65536 Then out = out & ChrW(cp) Else out = out & "?"
    Loop
    Utf8BytesToString = out
End Function

Public Sub XC_DecodeUrlHtml()
    On Error GoTo eh
    Dim rng As Range, c As Range, n As Long, s As String, nv As String, mode As Long
    Set rng = SelRange()
    If rng Is Nothing Then Exit Sub
    mode = AskChoice("Decode:", Array("URL encoding (%20, + ...)", "HTML entities (&amp; &#233; ...)", "Both"))
    If mode = 0 Then Exit Sub
    SnapshotRange rng, "Decode URL/HTML"
    SafeStart "Decoding"
    For Each c In rng.Cells
        If Not c.HasFormula And VarType(c.Value) = vbString Then
            s = c.Value: nv = s
            If mode = 1 Or mode = 3 Then nv = UrlDecode(nv)
            If mode = 2 Or mode = 3 Then nv = HtmlDecode(nv)
            If nv <> s Then WriteText c, nv: n = n + 1
        End If
    Next c
    SafeEnd
    Done "Decode URL/HTML: " & Plural(n, "cell") & " changed."
    Exit Sub
eh:
    ReportError "Decode URL and HTML Encoded Text"
End Sub

'--- Hyperlinks -------------------------------------------------------------------
Public Sub XC_ExtractHyperlinkAddresses()
    On Error GoTo eh
    Dim rng As Range, c As Range, n As Long, mode As Long, hl As Hyperlink, shp As Shape, rpt As Worksheet, r As Long, addr As String
    Set rng = SelRange()
    If rng Is Nothing Then Exit Sub
    mode = AskChoice("Extract hyperlink addresses from the selected cells:", Array( _
        "Write the address in the column to the RIGHT of each cell", "Replace the cell content with the address", "List all hyperlinks (cells and shapes) of the sheet in a new workbook"))
    If mode = 0 Then Exit Sub
    SafeStart "Extracting"
    If mode = 3 Then
        Set rpt = NewReportSheet("Hyperlinks")
        rpt.Range("A1:D1").Value = Array("Sheet", "Location", "Text", "Address")
        rpt.Range("A1:D1").Font.Bold = True
        r = 2
        For Each hl In rng.Worksheet.Hyperlinks
            rpt.Cells(r, 1).Value = rng.Worksheet.Name
            On Error Resume Next
            rpt.Cells(r, 2).Value = hl.Range.Address(False, False)
            If Err.Number <> 0 Then rpt.Cells(r, 2).Value = "Shape: " & hl.Shape.Name
            Err.Clear
            On Error GoTo eh
            rpt.Cells(r, 3).Value = hl.TextToDisplay
            rpt.Cells(r, 4).Value = IIf(Len(hl.Address) > 0, hl.Address, "#" & hl.SubAddress)
            r = r + 1: n = n + 1
        Next hl
        rpt.Columns("A:D").AutoFit
    Else
        For Each c In rng.Cells
            addr = ""
            If c.Hyperlinks.Count > 0 Then
                addr = c.Hyperlinks(1).Address
                If Len(addr) = 0 Then addr = "#" & c.Hyperlinks(1).SubAddress
            ElseIf c.HasFormula Then
                If InStr(1, c.Formula, "HYPERLINK(", vbTextCompare) > 0 Then addr = HyperlinkFormulaTarget(c)
            End If
            If Len(addr) > 0 Then
                If mode = 1 Then c.Offset(0, 1).Value = addr Else c.Hyperlinks.Delete: c.Value = addr
                n = n + 1
            End If
        Next c
    End If
    SafeEnd
    Done "Extract Hyperlink Addresses: " & Plural(n, "hyperlink") & " found."
    Exit Sub
eh:
    ReportError "Extract Hyperlink Addresses"
End Sub

' Evaluates the first argument of a =HYPERLINK(link, text) formula.
Private Function HyperlinkFormulaTarget(ByVal c As Range) As String
    Dim f As String, p As Long, q As Long, inner As String, depth As Long, i As Long, ch As String, inQ As Boolean, arg As String
    f = c.Formula
    p = InStr(1, UCase$(f), "HYPERLINK(")
    If p = 0 Then Exit Function
    q = modModeling.MatchingParen(f, p + 9)
    If q = 0 Then Exit Function
    inner = Mid$(f, p + 10, q - p - 10)
    For i = 1 To Len(inner)
        ch = Mid$(inner, i, 1)
        If ch = """" Then inQ = Not inQ
        If Not inQ Then
            If ch = "(" Then depth = depth + 1
            If ch = ")" Then depth = depth - 1
            If ch = "," And depth = 0 Then Exit For
        End If
    Next i
    arg = Left$(inner, i - 1)
    On Error Resume Next
    HyperlinkFormulaTarget = CStr(c.Worksheet.Evaluate(arg))
End Function

Public Sub XC_CreateHyperlinks()
    On Error GoTo eh
    Dim rng As Range, c As Range, n As Long, s As String, mode As Long, addr As String
    Set rng = SelRange()
    If rng Is Nothing Then Exit Sub
    mode = AskChoice("Create hyperlinks from the cell values. The values are:", Array( _
        "Web addresses or e-mail addresses (http://, www., name@domain)", "File or folder paths", "Sheet names in this workbook (link to that sheet)"))
    If mode = 0 Then Exit Sub
    SafeStart "Creating hyperlinks"
    For Each c In rng.Cells
        s = Trim$(CStr(c.Text))
        If Len(s) > 0 And c.Hyperlinks.Count = 0 Then
            Select Case mode
                Case 1
                    addr = s
                    If InStr(s, "@") > 0 And InStr(s, ":") = 0 Then
                        addr = "mailto:" & s
                    ElseIf LCase$(Left$(s, 4)) = "www." Then
                        addr = "http://" & s
                    End If
                    If InStr(addr, ":") > 0 Then rng.Worksheet.Hyperlinks.Add Anchor:=c, Address:=addr, TextToDisplay:=s: n = n + 1
                Case 2
                    rng.Worksheet.Hyperlinks.Add Anchor:=c, Address:=s, TextToDisplay:=s: n = n + 1
                Case 3
                    If SheetExists(s) Then rng.Worksheet.Hyperlinks.Add Anchor:=c, Address:="", SubAddress:="'" & s & "'!A1", TextToDisplay:=s: n = n + 1
            End Select
        End If
    Next c
    SafeEnd
    Done "Create Hyperlinks: " & Plural(n, "hyperlink") & " created."
    Exit Sub
eh:
    ReportError "Create Hyperlinks from Cell Values"
End Sub

Public Sub XC_HyperlinksToFormulas()
    On Error GoTo eh
    Dim sh As Object, hl As Hyperlink, n As Long, i As Long, c As Range, addr As String, txt As String
    SafeStart "Converting hyperlinks"
    For Each sh In ActiveWindow.SelectedSheets
        If TypeName(sh) = "Worksheet" Then
            For i = sh.Hyperlinks.Count To 1 Step -1
                Set hl = sh.Hyperlinks(i)
                Set c = Nothing
                On Error Resume Next
                Set c = hl.Range
                On Error GoTo eh
                If Not c Is Nothing Then
                    addr = hl.Address
                    If Len(addr) = 0 Then addr = "#" & hl.SubAddress
                    txt = c.Text
                    hl.Delete
                    c.Formula = "=HYPERLINK(""" & Replace(addr, """", """""") & """,""" & Replace(txt, """", """""") & """)"
                    n = n + 1
                End If
            Next i
        End If
    Next sh
    SafeEnd
    Done "Convert Hyperlinks to =HYPERLINK(): " & Plural(n, "hyperlink") & " converted."
    Exit Sub
eh:
    ReportError "Convert Hyperlinks to =HYPERLINK() Formulas"
End Sub

Public Sub XC_RemoveHyperlinks()
    On Error GoTo eh
    Dim rng As Range, n As Long, keepFormat As Boolean, c As Range
    Set rng = SelRange()
    If rng Is Nothing Then Exit Sub
    n = 0
    For Each c In rng.Cells
        n = n + c.Hyperlinks.Count
    Next c
    If n = 0 Then MsgBox "The selection contains no hyperlinks.", vbInformation, APP_NAME: Exit Sub
    keepFormat = AskYesNo("Keep the cells' current formatting (blue underline)?" & vbCrLf & "No = reset the font to the default look", False)
    SafeStart
    If keepFormat Then
        rng.Hyperlinks.Delete
    Else
        rng.ClearHyperlinks
    End If
    SafeEnd
    Done "Remove Hyperlinks: " & Plural(n, "hyperlink") & " removed."
    Exit Sub
eh:
    ReportError "Remove All Hyperlinks"
End Sub

'--- HTML table -------------------------------------------------------------------
Public Sub XC_CopyAsHtmlTable()
    On Error GoTo eh
    Dim rng As Range, r As Long, c As Long, s As String, hdr As Boolean, tag As String, cell As Range, mode As Long, v As String
    Set rng = SelRange()
    If rng Is Nothing Then Exit Sub
    If rng.Areas.Count > 1 Then Set rng = rng.Areas(1)
    hdr = AskYesNo("Treat the first row as a header row (<th>)?")
    mode = AskChoice("Put the HTML:", Array("On the clipboard", "In a new worksheet (cell A1)", "Both"))
    If mode = 0 Then Exit Sub
    SafeStart "Building HTML"
    s = "<table border=""1"" cellspacing=""0"" cellpadding=""3"">" & vbCrLf
    For r = 1 To rng.Rows.Count
        s = s & "  <tr>"
        For c = 1 To rng.Columns.Count
            Set cell = rng.Cells(r, c)
            tag = IIf(hdr And r = 1, "th", "td")
            v = HtmlEncode(cell.Text)
            If IsNumeric(cell.Value) And VarType(cell.Value) <> vbString And Not (hdr And r = 1) Then
                s = s & "<" & tag & " align=""right"">" & v & "</" & tag & ">"
            Else
                s = s & "<" & tag & ">" & v & "</" & tag & ">"
            End If
        Next c
        s = s & "</tr>" & vbCrLf
    Next r
    s = s & "</table>"
    If mode = 1 Or mode = 3 Then SetClipboardText s
    If mode = 2 Or mode = 3 Then
        Dim ws As Worksheet
        Set ws = NewReportSheet("HTML", False)
        ws.Range("A1").Value = s
        ws.Range("A1").WrapText = False
    End If
    SafeEnd
    Done "Copy Selection as HTML Table: " & Len(s) & " characters generated."
    Exit Sub
eh:
    ReportError "Copy Selection as HTML Table"
End Sub

Public Function HtmlEncode(ByVal s As String) As String
    s = Replace(s, "&", "&amp;")
    s = Replace(s, "<", "&lt;")
    s = Replace(s, ">", "&gt;")
    s = Replace(s, """", "&quot;")
    s = Replace(s, vbLf, "<br>")
    HtmlEncode = s
End Function
