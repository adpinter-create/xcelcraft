Attribute VB_Name = "modSheets"
'==============================================================================
' SPDX-License-Identifier: MIT
' XcelCraft - modSheets
' Sheets category. Original implementation.
'==============================================================================
Option Explicit

Private Function SelectedSheetsCount() As Long
    SelectedSheetsCount = ActiveWindow.SelectedSheets.Count
End Function

'--- Insert / rename ---------------------------------------------------------
Public Sub XC_InsertNamedSheet()
    On Error GoTo eh
    Dim nm As String, ws As Worksheet, pos As Long
    nm = AskText("Name of the new worksheet:", "", "Insert Named Worksheet")
    If Len(nm) = 0 Then Exit Sub
    If SheetExists(nm) Then MsgBox "A sheet named '" & nm & "' already exists.", vbExclamation, APP_NAME: Exit Sub
    pos = AskChoice("Position:", Array("After the active sheet", "Before the active sheet", "At the end of the workbook", "At the beginning of the workbook"))
    If pos = 0 Then Exit Sub
    Select Case pos
        Case 1: Set ws = ActiveWorkbook.Worksheets.Add(After:=ActiveSheet)
        Case 2: Set ws = ActiveWorkbook.Worksheets.Add(Before:=ActiveSheet)
        Case 3: Set ws = ActiveWorkbook.Worksheets.Add(After:=ActiveWorkbook.Sheets(ActiveWorkbook.Sheets.Count))
        Case 4: Set ws = ActiveWorkbook.Worksheets.Add(Before:=ActiveWorkbook.Sheets(1))
    End Select
    ws.Name = SafeSheetName(nm)
    Exit Sub
eh:
    ReportError "Insert Named Worksheet"
End Sub

Public Sub XC_InsertSheetsFromCells()
    On Error GoTo eh
    Dim rng As Range, c As Range, n As Long, nm As String, ws As Worksheet, last As Object, skipped As Long
    Set rng = SelRange()
    If rng Is Nothing Then Exit Sub
    If rng.Cells.CountLarge > 200 Then
        If Not AskYesNo(rng.Cells.CountLarge & " sheets will be created. Continue?", False) Then Exit Sub
    End If
    SafeStart "Inserting sheets"
    Set last = ActiveSheet
    For Each c In rng.Cells
        nm = SafeSheetName(CStr(c.Text))
        If Len(Trim$(CStr(c.Text))) > 0 Then
            If SheetExists(nm) Then
                skipped = skipped + 1
            Else
                Set ws = ActiveWorkbook.Worksheets.Add(After:=last)
                ws.Name = nm
                Set last = ws
                n = n + 1
            End If
        End If
    Next c
    rng.Worksheet.Activate
    SafeEnd
    Done "Insert Sheets from Cell Values: " & Plural(n, "sheet") & " created" & IIf(skipped > 0, ", " & skipped & " skipped (name already exists).", ".")
    Exit Sub
eh:
    ReportError "Insert Sheets from Cell Values"
End Sub

Public Sub XC_RenameActiveSheet()
    On Error GoTo eh
    Dim nm As String
    nm = AskText("New name for sheet '" & ActiveSheet.Name & "':", ActiveSheet.Name, "Rename Active Sheet")
    If Len(nm) = 0 Or nm = ActiveSheet.Name Then Exit Sub
    If SheetExists(nm) Then MsgBox "A sheet named '" & nm & "' already exists.", vbExclamation, APP_NAME: Exit Sub
    ActiveSheet.Name = SafeSheetName(nm)
    Exit Sub
eh:
    ReportError "Rename Active Sheet"
End Sub

Public Sub XC_RenameMultipleSheets()
    On Error GoTo eh
    Dim mode As Long, pre As String, suf As String, f As String, r As String, ws As Object, nm As String, n As Long, i As Long
    mode = AskChoice("Rename the " & SelectedSheetsCount() & " selected sheet(s):", Array( _
        "Add a prefix and/or suffix to each name", "Find and replace text in the names", "Rename each selected sheet one by one", _
        "Number the sheets (Name 1, Name 2, ...)", "Change case of names (UPPER / lower / Proper)"))
    If mode = 0 Then Exit Sub
    Select Case mode
        Case 1
            pre = AskText("Prefix (optional):", "", "Rename Sheets")
            suf = AskText("Suffix (optional):", "", "Rename Sheets")
            If Len(pre) = 0 And Len(suf) = 0 Then Exit Sub
        Case 2
            f = AskText("Find:", "", "Rename Sheets")
            If Len(f) = 0 Then Exit Sub
            r = AskText("Replace with:", "", "Rename Sheets")
        Case 4
            pre = AskText("Base name (a number is appended):", "Sheet", "Rename Sheets")
            If Len(pre) = 0 Then Exit Sub
        Case 5
            i = AskChoice("Case:", Array("UPPERCASE", "lowercase", "Proper Case"))
            If i = 0 Then Exit Sub
    End Select
    SafeStart "Renaming sheets"
    For Each ws In ActiveWindow.SelectedSheets
        Select Case mode
            Case 1: nm = pre & ws.Name & suf
            Case 2: nm = Replace(ws.Name, f, r, , , vbTextCompare)
            Case 3
                SafeEnd
                nm = AskText("New name for '" & ws.Name & "' (leave empty to skip):", ws.Name, "Rename Sheets")
                SafeStart "Renaming sheets"
                If Len(nm) = 0 Then nm = ws.Name
            Case 4: n = n + 1: nm = pre & " " & n
            Case 5: nm = Choose(i, UCase$(ws.Name), LCase$(ws.Name), StrConv(ws.Name, vbProperCase))
        End Select
        nm = SafeSheetName(nm)
        If nm <> ws.Name Then
            If SheetExists(nm) Then nm = UniqueSheetName(nm)
            ws.Name = nm
        End If
    Next ws
    SafeEnd
    Done "Rename Multiple Sheets: done."
    Exit Sub
eh:
    ReportError "Rename Multiple Sheets"
End Sub

Public Sub XC_RenameSheetsFromCell()
    On Error GoTo eh
    Dim addr As String, ws As Object, nm As String, n As Long
    If TypeName(Selection) <> "Range" Then Exit Sub
    addr = ActiveCell.Address(False, False)
    If Not AskYesNo("Rename each of the " & SelectedSheetsCount() & " selected sheet(s) using the value of its cell " & addr & "?") Then Exit Sub
    SafeStart "Renaming sheets"
    For Each ws In ActiveWindow.SelectedSheets
        If TypeName(ws) = "Worksheet" Then
            nm = SafeSheetName(CStr(ws.Range(addr).Text))
            If Len(Trim$(CStr(ws.Range(addr).Text))) > 0 And nm <> ws.Name Then
                If SheetExists(nm) Then nm = UniqueSheetName(nm)
                ws.Name = nm: n = n + 1
            End If
        End If
    Next ws
    SafeEnd
    Done "Rename Sheets Using a Cell's Value: " & Plural(n, "sheet") & " renamed."
    Exit Sub
eh:
    ReportError "Rename Sheets Using a Cell's Value"
End Sub

Public Sub XC_SwitchToPreviousSheet()
    On Error GoTo eh
    If Len(gPrevSheetName) = 0 Then
        MsgBox "No previous sheet recorded yet (the add-in tracks sheet changes after it loads).", vbInformation, APP_NAME
        Exit Sub
    End If
    Workbooks(gPrevSheetBook).Sheets(gPrevSheetName).Activate
    Exit Sub
eh:
    MsgBox "The previous sheet is no longer available.", vbInformation, APP_NAME
End Sub

'--- Sort / index ------------------------------------------------------------
Public Sub XC_SortSheets()
    On Error GoTo eh
    Dim mode As Long, i As Long, j As Long, n As Long, names() As String, t As String, swapIt As Boolean
    mode = AskChoice("Sort all sheets:", Array("Ascending (A-Z)", "Descending (Z-A)", "Ascending, numbers in names sorted numerically (Sheet2 before Sheet10)"))
    If mode = 0 Then Exit Sub
    n = ActiveWorkbook.Sheets.Count
    ReDim names(1 To n)
    For i = 1 To n: names(i) = ActiveWorkbook.Sheets(i).Name: Next i
    For i = 1 To n - 1
        For j = i + 1 To n
            Select Case mode
                Case 1: swapIt = StrComp(names(i), names(j), vbTextCompare) > 0
                Case 2: swapIt = StrComp(names(i), names(j), vbTextCompare) < 0
                Case 3: swapIt = NaturalCompare(names(i), names(j)) > 0
            End Select
            If swapIt Then t = names(i): names(i) = names(j): names(j) = t
        Next j
    Next i
    SafeStart "Sorting sheets"
    For i = 1 To n
        ActiveWorkbook.Sheets(names(i)).Move Before:=ActiveWorkbook.Sheets(i)
    Next i
    SafeEnd
    Exit Sub
eh:
    ReportError "Sort All Sheets"
End Sub

' Compare strings treating embedded digit runs as numbers.
Public Function NaturalCompare(ByVal a As String, ByVal b As String) As Long
    Dim ia As Long, ib As Long, ca As String, cb As String, na As String, nb As String
    ia = 1: ib = 1
    Do While ia <= Len(a) And ib <= Len(b)
        ca = Mid$(a, ia, 1): cb = Mid$(b, ib, 1)
        If IsDigitChar(ca) And IsDigitChar(cb) Then
            na = "": nb = ""
            Do While ia <= Len(a)
                If Not IsDigitChar(Mid$(a, ia, 1)) Then Exit Do
                na = na & Mid$(a, ia, 1): ia = ia + 1
            Loop
            Do While ib <= Len(b)
                If Not IsDigitChar(Mid$(b, ib, 1)) Then Exit Do
                nb = nb & Mid$(b, ib, 1): ib = ib + 1
            Loop
            If Val(na) <> Val(nb) Then NaturalCompare = IIf(Val(na) > Val(nb), 1, -1): Exit Function
        Else
            If LCase$(ca) <> LCase$(cb) Then NaturalCompare = IIf(LCase$(ca) > LCase$(cb), 1, -1): Exit Function
            ia = ia + 1: ib = ib + 1
        End If
    Loop
    NaturalCompare = Sgn((Len(a) - ia) - (Len(b) - ib))
End Function

Public Sub XC_CreateIndexSheet()
    On Error GoTo eh
    Dim ws As Worksheet, idx As Worksheet, r As Long, backLinks As Boolean, nm As String, sh As Object
    nm = "Index"
    If SheetExists(nm) Then
        If Not AskYesNo("A sheet named 'Index' already exists. Replace it?") Then Exit Sub
        Application.DisplayAlerts = False
        ActiveWorkbook.Sheets(nm).Delete
        Application.DisplayAlerts = True
    End If
    backLinks = AskYesNo("Also add a 'Back to Index' link in cell A1 of every sheet?" & vbCrLf & "(Overwrites A1 if not empty)", False)
    SafeStart "Creating index"
    Set idx = ActiveWorkbook.Worksheets.Add(Before:=ActiveWorkbook.Sheets(1))
    idx.Name = nm
    idx.Range("A1").Value = "Index": idx.Range("A1").Font.Bold = True: idx.Range("A1").Font.Size = 14
    idx.Range("A3:C3").Value = Array("#", "Sheet", "Type")
    idx.Range("A3:C3").Font.Bold = True
    r = 4
    For Each sh In ActiveWorkbook.Sheets
        If sh.Name <> nm Then
            idx.Cells(r, 1).Value = r - 3
            idx.Hyperlinks.Add Anchor:=idx.Cells(r, 2), Address:="", SubAddress:="'" & sh.Name & "'!A1", TextToDisplay:=sh.Name
            idx.Cells(r, 3).Value = TypeName(sh)
            If backLinks And TypeName(sh) = "Worksheet" Then
                sh.Hyperlinks.Add Anchor:=sh.Range("A1"), Address:="", SubAddress:="'" & nm & "'!A1", TextToDisplay:="Back to Index"
            End If
            r = r + 1
        End If
    Next sh
    idx.Columns("A:C").AutoFit
    idx.Activate
    SafeEnd
    Done "Index created with " & Plural(r - 4, "link") & "."
    Exit Sub
eh:
    ReportError "Create Index Page"
End Sub

'--- Split range into sheets -------------------------------------------------
Public Sub XC_SplitRangeToSheets()
    On Error GoTo eh
    Dim rng As Range, mode As Long, hdr As Boolean, col As Variant, perSheet As Variant, i As Long, r As Long
    Dim keys As Collection, k As Variant, ws As Worksheet, src As Worksheet, dataRows As Range, keyRange As Range, n As Long
    Dim firstRow As Long, lastRow As Long, blockRows As Long, cnt As Long, cell As Range, key As String
    Set rng = SelRangeOrRegion()
    If rng Is Nothing Then Exit Sub
    If rng.Areas.Count > 1 Then MsgBox "Please select a single rectangular range.", vbExclamation, APP_NAME: Exit Sub
    Set src = rng.Worksheet
    mode = AskChoice("Split the range " & rng.Address(False, False) & " into separate worksheets:", Array( _
        "By the values in a column (one sheet per unique value)", "By a fixed number of rows per sheet"))
    If mode = 0 Then Exit Sub
    hdr = AskYesNo("Does the first row contain headers (repeated on every new sheet)?")
    firstRow = IIf(hdr, 2, 1)
    If rng.Rows.Count < firstRow Then Exit Sub
    If mode = 1 Then
        col = AskNumber("Which column of the selection holds the values to split by? (1 = first column of the selection)", 1, "Split Range", 1, rng.Columns.Count)
        If IsEmpty(col) Then Exit Sub
        Set keys = New Collection
        For r = firstRow To rng.Rows.Count
            key = CStr(rng.Cells(r, col).Text)
            On Error Resume Next
            keys.Add key, "k" & key
            On Error GoTo eh
        Next r
        If keys.Count > 100 Then
            If Not AskYesNo(keys.Count & " unique values found: " & keys.Count & " sheets will be created. Continue?", False) Then Exit Sub
        End If
        SafeStart "Splitting"
        For Each k In keys
            Set ws = ActiveWorkbook.Worksheets.Add(After:=ActiveWorkbook.Sheets(ActiveWorkbook.Sheets.Count))
            ws.Name = UniqueSheetName(IIf(Len(k) = 0, "(blank)", CStr(k)))
            cnt = 0
            If hdr Then rng.Rows(1).Copy ws.Range("A1"): cnt = 1
            For r = firstRow To rng.Rows.Count
                If CStr(rng.Cells(r, col).Text) = CStr(k) Then
                    rng.Rows(r).Copy ws.Cells(cnt + 1, 1)
                    cnt = cnt + 1
                End If
            Next r
            ws.Columns.AutoFit
            n = n + 1
        Next k
    Else
        perSheet = AskNumber("Number of data rows per sheet:", 1000, "Split Range", 1)
        If IsEmpty(perSheet) Then Exit Sub
        SafeStart "Splitting"
        r = firstRow
        i = 0
        Do While r <= rng.Rows.Count
            i = i + 1
            blockRows = Min2(CLng(perSheet), rng.Rows.Count - r + 1)
            Set ws = ActiveWorkbook.Worksheets.Add(After:=ActiveWorkbook.Sheets(ActiveWorkbook.Sheets.Count))
            ws.Name = UniqueSheetName(src.Name & " " & i)
            cnt = 0
            If hdr Then rng.Rows(1).Copy ws.Range("A1"): cnt = 1
            rng.Rows(r).Resize(blockRows).Copy ws.Cells(cnt + 1, 1)
            ws.Columns.AutoFit
            r = r + blockRows
            n = n + 1
        Loop
    End If
    src.Activate
    SafeEnd
    Done "Split Range into Worksheets: " & Plural(n, "sheet") & " created."
    Exit Sub
eh:
    ReportError "Split Range into Worksheets"
End Sub

'--- Hide / unhide / delete ---------------------------------------------------
Public Sub XC_RemoveEmptySheets()
    On Error GoTo eh
    Dim ws As Worksheet, n As Long, i As Long, empty_ As Boolean
    If ActiveWorkbook.Worksheets.Count < 2 Then Exit Sub
    SafeStart "Removing empty sheets"
    Application.DisplayAlerts = False
    For i = ActiveWorkbook.Worksheets.Count To 1 Step -1
        Set ws = ActiveWorkbook.Worksheets(i)
        empty_ = (Application.WorksheetFunction.CountA(ws.Cells) = 0) And (ws.Shapes.Count = 0) And (ws.Comments.Count = 0)
        If empty_ And ActiveWorkbook.Worksheets.Count > 1 Then
            ws.Delete: n = n + 1
        End If
    Next i
    Application.DisplayAlerts = True
    SafeEnd
    Done "Remove All Empty Worksheets: " & Plural(n, "sheet") & " removed."
    Exit Sub
eh:
    ReportError "Remove All Empty Worksheets"
End Sub

Public Sub XC_UnhideAllSheets()
    On Error GoTo eh
    Dim sh As Object, n As Long
    SafeStart
    For Each sh In ActiveWorkbook.Sheets
        If sh.Visible <> xlSheetVisible Then sh.Visible = xlSheetVisible: n = n + 1
    Next sh
    SafeEnd
    Done "Unhide All Sheets: " & Plural(n, "sheet") & " unhidden."
    Exit Sub
eh:
    ReportError "Unhide All Sheets"
End Sub

Private Sub HideSelected(ByVal veryHidden As Boolean)
    On Error GoTo eh
    Dim sh As Object, n As Long, visibleCount As Long, names As Collection, nm As Variant
    For Each sh In ActiveWorkbook.Sheets
        If sh.Visible = xlSheetVisible Then visibleCount = visibleCount + 1
    Next sh
    If visibleCount <= SelectedSheetsCount() Then
        MsgBox "At least one sheet must remain visible.", vbExclamation, APP_NAME
        Exit Sub
    End If
    Set names = New Collection
    For Each sh In ActiveWindow.SelectedSheets: names.Add sh.Name: Next sh
    ActiveWorkbook.Sheets(names(1)).Select   ' drop the grouping first
    For Each nm In names
        ActiveWorkbook.Sheets(nm).Visible = IIf(veryHidden, xlSheetVeryHidden, xlSheetHidden)
        n = n + 1
    Next nm
    Done Plural(n, "sheet") & " hidden" & IIf(veryHidden, " (very hidden: only VBA can unhide them, or use Unhide All Sheets).", ".")
    Exit Sub
eh:
    ReportError "Hide Sheets"
End Sub

Public Sub XC_HideSelectedSheets(): HideSelected False: End Sub
Public Sub XC_HideSelectedVeryHidden(): HideSelected True: End Sub

'--- Protect / unprotect ------------------------------------------------------
Private Sub ProtectMany(ByVal protectIt As Boolean)
    On Error GoTo eh
    Dim scope As Long, pw As String, ws As Worksheet, n As Long, failed As Long, sh As Object
    scope = AskChoice(IIf(protectIt, "Protect", "Unprotect") & " which sheets?", Array("Selected sheets (" & SelectedSheetsCount() & ")", "All worksheets in the workbook"))
    If scope = 0 Then Exit Sub
    pw = AskText("Password (leave empty for none):", "", IIf(protectIt, "Protect Sheets", "Unprotect Sheets"))
    SafeStart
    If scope = 1 Then
        For Each sh In ActiveWindow.SelectedSheets
            If TypeName(sh) = "Worksheet" Then
                If ProtectOne(sh, protectIt, pw) Then n = n + 1 Else failed = failed + 1
            End If
        Next sh
    Else
        For Each ws In ActiveWorkbook.Worksheets
            If ProtectOne(ws, protectIt, pw) Then n = n + 1 Else failed = failed + 1
        Next ws
    End If
    SafeEnd
    Done Plural(n, "sheet") & IIf(protectIt, " protected", " unprotected") & IIf(failed > 0, ", " & failed & " failed (wrong password?).", ".")
    Exit Sub
eh:
    ReportError "Protect/Unprotect Sheets"
End Sub

Private Function ProtectOne(ByVal ws As Worksheet, ByVal protectIt As Boolean, ByVal pw As String) As Boolean
    On Error Resume Next
    If protectIt Then
        ws.Protect Password:=pw, DrawingObjects:=True, Contents:=True, Scenarios:=True, UserInterfaceOnly:=False
        ProtectOne = ws.ProtectContents
    Else
        ws.Unprotect Password:=pw
        ProtectOne = Not ws.ProtectContents
    End If
End Function

Public Sub XC_ProtectMultipleSheets(): ProtectMany True: End Sub
Public Sub XC_UnprotectMultipleSheets(): ProtectMany False: End Sub

'--- Printing / page setup ----------------------------------------------------
Public Sub XC_PrintMultipleSheets()
    On Error GoTo eh
    Dim c As Long, s As String, parts() As String, i As Long, names As Collection, sh As Object, p As Variant
    s = ""
    For i = 1 To ActiveWorkbook.Sheets.Count
        s = s & i & ". " & ActiveWorkbook.Sheets(i).Name & vbCrLf
    Next i
    s = AskText("Enter the numbers of the sheets to print, separated by commas (e.g. 1,3,5) or * for all:" & vbCrLf & vbCrLf & s, "*", "Print Multiple Sheets")
    If Len(s) = 0 Then Exit Sub
    Set names = New Collection
    If s = "*" Then
        For Each sh In ActiveWorkbook.Sheets: If sh.Visible = xlSheetVisible Then names.Add sh.Name
        Next sh
    Else
        parts = Split(s, ",")
        For Each p In parts
            If IsNumeric(Trim$(p)) Then
                i = CLng(Trim$(p))
                If i >= 1 And i <= ActiveWorkbook.Sheets.Count Then names.Add ActiveWorkbook.Sheets(i).Name
            End If
        Next p
    End If
    If names.Count = 0 Then Exit Sub
    c = AskChoice("Action:", Array("Print preview", "Print now"))
    If c = 0 Then Exit Sub
    Dim arr() As String
    ReDim arr(0 To names.Count - 1)
    For i = 1 To names.Count: arr(i - 1) = names(i): Next i
    If c = 1 Then ActiveWorkbook.Sheets(arr).PrintPreview Else ActiveWorkbook.Sheets(arr).PrintOut
    ActiveSheet.Select
    Exit Sub
eh:
    ReportError "Print Multiple Sheets"
End Sub

Public Sub XC_CopyPageSetup()
    On Error GoTo eh
    Dim src As Worksheet, ws As Object, n As Long, scope As Long
    Set src = ActiveSheet
    scope = AskChoice("Copy the page setup of '" & src.Name & "' to:", Array("The other selected sheets (" & (SelectedSheetsCount() - 1) & ")", "All other worksheets in the workbook"))
    If scope = 0 Then Exit Sub
    SafeStart "Copying page setup"
    Application.PrintCommunication = False
    If scope = 1 Then
        For Each ws In ActiveWindow.SelectedSheets
            If TypeName(ws) = "Worksheet" And ws.Name <> src.Name Then CopySetup src, ws: n = n + 1
        Next ws
    Else
        For Each ws In ActiveWorkbook.Worksheets
            If ws.Name <> src.Name Then CopySetup src, ws: n = n + 1
        Next ws
    End If
    Application.PrintCommunication = True
    src.Select
    SafeEnd
    Done "Copy Page Setup: applied to " & Plural(n, "sheet") & "."
    Exit Sub
eh:
    Application.PrintCommunication = True
    ReportError "Copy Page Setup"
End Sub

Private Sub CopySetup(ByVal src As Worksheet, ByVal dst As Worksheet)
    On Error Resume Next
    With dst.PageSetup
        .Orientation = src.PageSetup.Orientation
        .PaperSize = src.PageSetup.PaperSize
        .LeftMargin = src.PageSetup.LeftMargin: .RightMargin = src.PageSetup.RightMargin
        .TopMargin = src.PageSetup.TopMargin: .BottomMargin = src.PageSetup.BottomMargin
        .HeaderMargin = src.PageSetup.HeaderMargin: .FooterMargin = src.PageSetup.FooterMargin
        .LeftHeader = src.PageSetup.LeftHeader: .CenterHeader = src.PageSetup.CenterHeader: .RightHeader = src.PageSetup.RightHeader
        .LeftFooter = src.PageSetup.LeftFooter: .CenterFooter = src.PageSetup.CenterFooter: .RightFooter = src.PageSetup.RightFooter
        .PrintTitleRows = src.PageSetup.PrintTitleRows: .PrintTitleColumns = src.PageSetup.PrintTitleColumns
        .PrintArea = src.PageSetup.PrintArea
        .PrintGridlines = src.PageSetup.PrintGridlines: .PrintHeadings = src.PageSetup.PrintHeadings
        .CenterHorizontally = src.PageSetup.CenterHorizontally: .CenterVertically = src.PageSetup.CenterVertically
        .Order = src.PageSetup.Order: .BlackAndWhite = src.PageSetup.BlackAndWhite: .Draft = src.PageSetup.Draft
        .Zoom = src.PageSetup.Zoom
        If src.PageSetup.Zoom = False Then
            .FitToPagesWide = src.PageSetup.FitToPagesWide
            .FitToPagesTall = src.PageSetup.FitToPagesTall
        End If
        .FirstPageNumber = src.PageSetup.FirstPageNumber
        .PrintComments = src.PageSetup.PrintComments
        .PrintErrors = src.PageSetup.PrintErrors
    End With
End Sub

Public Sub XC_SetPrintAreaSelectedSheets()
    On Error GoTo eh
    Dim addr As String, ws As Object, n As Long
    If TypeName(Selection) <> "Range" Then Exit Sub
    addr = Selection.Address
    For Each ws In ActiveWindow.SelectedSheets
        If TypeName(ws) = "Worksheet" Then ws.PageSetup.PrintArea = addr: n = n + 1
    Next ws
    Done "Print area set to " & addr & " on " & Plural(n, "sheet") & "."
    Exit Sub
eh:
    ReportError "Set Print Area on Selected Sheets"
End Sub

Public Sub XC_ClearPrintAreaSelectedSheets()
    On Error GoTo eh
    Dim ws As Object, n As Long
    For Each ws In ActiveWindow.SelectedSheets
        If TypeName(ws) = "Worksheet" Then ws.PageSetup.PrintArea = "": n = n + 1
    Next ws
    Done "Print area cleared on " & Plural(n, "sheet") & "."
    Exit Sub
eh:
    ReportError "Clear Print Area on Selected Sheets"
End Sub

Public Sub XC_ResetPageBreaksSelectedSheets()
    On Error GoTo eh
    Dim ws As Object, n As Long
    For Each ws In ActiveWindow.SelectedSheets
        If TypeName(ws) = "Worksheet" Then ws.ResetAllPageBreaks: n = n + 1
    Next ws
    Done "Page breaks reset on " & Plural(n, "sheet") & "."
    Exit Sub
eh:
    ReportError "Reset All Page Breaks"
End Sub

'--- Freeze panes -------------------------------------------------------------
Public Sub XC_FreezePanesMultiple()
    On Error GoTo eh
    Dim r As Long, c As Long, names As Collection, sh As Object, nm As Variant, cur As String, n As Long
    If TypeName(Selection) <> "Range" Then Exit Sub
    r = ActiveCell.Row: c = ActiveCell.Column
    If r = 1 And c = 1 Then MsgBox "Select the cell below/right of where the panes should freeze first.", vbInformation, APP_NAME: Exit Sub
    Set names = New Collection
    For Each sh In ActiveWindow.SelectedSheets: If TypeName(sh) = "Worksheet" Then names.Add sh.Name
    Next sh
    cur = ActiveSheet.Name
    SafeStart "Freezing panes"
    For Each nm In names
        ActiveWorkbook.Sheets(nm).Select
        ActiveWindow.FreezePanes = False
        ActiveWindow.ScrollRow = 1: ActiveWindow.ScrollColumn = 1
        ActiveSheet.Cells(r, c).Select
        ActiveWindow.FreezePanes = True
        n = n + 1
    Next nm
    ActiveWorkbook.Sheets(cur).Select
    SafeEnd
    Done "Freeze Panes applied at " & Cells(r, c).Address(False, False) & " on " & Plural(n, "sheet") & "."
    Exit Sub
eh:
    ReportError "Freeze Panes on Multiple Sheets"
End Sub

Public Sub XC_UnfreezePanesMultiple()
    On Error GoTo eh
    Dim names As Collection, sh As Object, nm As Variant, cur As String, n As Long
    Set names = New Collection
    For Each sh In ActiveWindow.SelectedSheets: If TypeName(sh) = "Worksheet" Then names.Add sh.Name
    Next sh
    cur = ActiveSheet.Name
    SafeStart
    For Each nm In names
        ActiveWorkbook.Sheets(nm).Select
        ActiveWindow.FreezePanes = False
        n = n + 1
    Next nm
    ActiveWorkbook.Sheets(cur).Select
    SafeEnd
    Done "Panes unfrozen on " & Plural(n, "sheet") & "."
    Exit Sub
eh:
    ReportError "Unfreeze Panes on Multiple Sheets"
End Sub

'--- Copy and stack rows/columns from multiple sheets -------------------------
Public Sub XC_StackFromSheets()
    On Error GoTo eh
    Dim scope As Long, dirn As Long, hdrRows As Variant, ws As Worksheet, dst As Worksheet, sh As Object, srcR As Range
    Dim nextPos As Long, n As Long, first As Boolean, addSheetCol As Boolean, names As Collection, nm As Variant, startRow As Long, rowsCopied As Long
    scope = AskChoice("Copy data from:", Array("Selected sheets (" & SelectedSheetsCount() & ")", "All worksheets in the workbook"))
    If scope = 0 Then Exit Sub
    dirn = AskChoice("Stack the data:", Array("Vertically (rows under each other)", "Horizontally (columns next to each other)"))
    If dirn = 0 Then Exit Sub
    hdrRows = AskNumber("Number of header rows to copy only once (0 = none):", 1, "Copy and Stack", 0, 100)
    If IsEmpty(hdrRows) Then Exit Sub
    addSheetCol = (dirn = 1) And AskYesNo("Add a column with the source sheet name?")
    Set names = New Collection
    If scope = 1 Then
        For Each sh In ActiveWindow.SelectedSheets: If TypeName(sh) = "Worksheet" Then names.Add sh.Name
        Next sh
    Else
        For Each ws In ActiveWorkbook.Worksheets: names.Add ws.Name: Next ws
    End If
    SafeStart "Stacking"
    Set dst = NewReportSheet("Stacked", False)
    nextPos = 1: first = True
    For Each nm In names
        Set ws = ActiveWorkbook.Worksheets(nm)
        If ws.Name <> dst.Name Then
            Set srcR = ws.UsedRange
            If Application.WorksheetFunction.CountA(srcR) > 0 Then
                If first Or hdrRows = 0 Then
                    startRow = 1
                Else
                    startRow = hdrRows + 1
                End If
                If startRow <= srcR.Rows.Count Then
                    If dirn = 1 Then
                        rowsCopied = srcR.Rows.Count - startRow + 1
                        srcR.Rows(startRow).Resize(rowsCopied).Copy dst.Cells(nextPos, 1)
                        If addSheetCol Then
                            dst.Cells(nextPos, srcR.Columns.Count + 1).Resize(rowsCopied).Value = ws.Name
                            If first And hdrRows > 0 Then dst.Cells(1, srcR.Columns.Count + 1).Value = "Sheet"
                        End If
                        nextPos = nextPos + rowsCopied
                    Else
                        srcR.Copy dst.Cells(1, nextPos)
                        nextPos = nextPos + srcR.Columns.Count
                    End If
                    n = n + 1
                    first = False
                End If
            End If
        End If
    Next nm
    dst.Columns.AutoFit
    dst.Activate
    SafeEnd
    Done "Copy and Stack: data from " & Plural(n, "sheet") & " stacked on sheet '" & dst.Name & "'."
    Exit Sub
eh:
    ReportError "Copy and Stack Rows or Columns"
End Sub

'--- Styles / last cell ---------------------------------------------------------
Public Sub XC_RemoveUnusedStyles()
    On Error GoTo eh
    Dim n As Long, total As Long
    If Not AskYesNo("This scans every used cell to find which custom styles are in use, then deletes the unused custom styles (built-in styles are kept)." & vbCrLf & "Continue?") Then Exit Sub
    SafeStart "Scanning styles"
    total = ActiveWorkbook.Styles.Count
    n = RemoveUnusedStylesSilent()
    SafeEnd
    Done "Remove Unused Styles: " & Plural(n, "style") & " removed (" & total & " before)."
    Exit Sub
eh:
    ReportError "Remove Unused Styles"
End Sub

Public Function RemoveUnusedStylesSilent() As Long
    Dim st As Style, used As Collection, ws As Worksheet, c As Range, n As Long, i As Long
    Set used = New Collection
    On Error Resume Next
    For Each ws In ActiveWorkbook.Worksheets
        For Each c In ws.UsedRange.Cells
            used.Add 1, "s" & c.Style.Name
        Next c
    Next ws
    For i = ActiveWorkbook.Styles.Count To 1 Step -1
        Set st = ActiveWorkbook.Styles(i)
        If Not st.BuiltIn Then
            If Not InCollection(used, "s" & st.Name) Then
                Err.Clear
                st.Delete
                If Err.Number = 0 Then n = n + 1
            End If
        End If
    Next i
    On Error GoTo 0
    RemoveUnusedStylesSilent = n
End Function

' Finds the last cell that really contains data or formatting worth keeping.
Public Function RealLastCell(ByVal ws As Worksheet) As Range
    Dim lr As Long, lc As Long, f As Range
    On Error Resume Next
    Set f = ws.Cells.Find(What:="*", LookIn:=xlFormulas, LookAt:=xlPart, SearchOrder:=xlByRows, SearchDirection:=xlPrevious)
    If Not f Is Nothing Then lr = f.Row
    Set f = ws.Cells.Find(What:="*", LookIn:=xlFormulas, LookAt:=xlPart, SearchOrder:=xlByColumns, SearchDirection:=xlPrevious)
    If Not f Is Nothing Then lc = f.Column
    On Error GoTo 0
    If lr = 0 Then lr = 1
    If lc = 0 Then lc = 1
    Set RealLastCell = ws.Cells(lr, lc)
End Function

Public Sub XC_DeleteEndingRowsCols()
    On Error GoTo eh
    Dim sh As Object, n As Long, before As String, after As String, s As String
    If Not AskYesNo("Delete all rows and columns after the last cell with data on each selected sheet (" & SelectedSheetsCount() & ")? This also resets Ctrl+End.") Then Exit Sub
    SafeStart "Cleaning ending rows and columns"
    For Each sh In ActiveWindow.SelectedSheets
        If TypeName(sh) = "Worksheet" Then
            before = sh.UsedRange.Address(False, False)
            TrimSheet sh
            after = sh.UsedRange.Address(False, False)
            s = s & sh.Name & ": " & before & " -> " & after & vbCrLf
            n = n + 1
        End If
    Next sh
    SafeEnd
    Done "Delete Ending Rows/Columns on " & Plural(n, "sheet") & ":" & vbCrLf & s
    Exit Sub
eh:
    ReportError "Delete and Reset Empty Ending Rows and Columns"
End Sub

Public Sub ResetLastCellSilent(ByVal ws As Worksheet)
    TrimSheet ws
End Sub

Private Sub TrimSheet(ByVal ws As Worksheet)
    Dim last As Range, ur As Range
    Set last = RealLastCell(ws)
    If last.Row < ws.Rows.Count Then ws.Range(ws.Rows(last.Row + 1), ws.Rows(ws.Rows.Count)).Delete
    If last.Column < ws.Columns.Count Then ws.Range(ws.Columns(last.Column + 1), ws.Columns(ws.Columns.Count)).Delete
    Set ur = ws.UsedRange   ' forces Excel to recalculate the used range
End Sub

Public Sub XC_ResetLastCell()
    On Error GoTo eh
    Dim before As String, ws As Worksheet
    Set ws = ActiveSheet
    before = ws.UsedRange.Address(False, False)
    SafeStart
    TrimSheet ws
    SafeEnd
    Done "Reset Last Cell on '" & ws.Name & "': used range " & before & " -> " & ws.UsedRange.Address(False, False) & ". Save the workbook to make Ctrl+End reflect it."
    Exit Sub
eh:
    ReportError "Reset Last Cell"
End Sub

Public Function InCollection(ByVal col As Collection, ByVal key As String) As Boolean
    Dim v As Variant
    On Error Resume Next
    v = col(key)
    InCollection = (Err.Number = 0)
    On Error GoTo 0
End Function
