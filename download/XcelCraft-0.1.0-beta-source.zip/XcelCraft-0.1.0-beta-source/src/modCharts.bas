Attribute VB_Name = "modCharts"
'==============================================================================
' SPDX-License-Identifier: MIT
' XcelCraft - modCharts
' Chart tools: series color cycle / recolor, waterfall, floating-bar range, combo.
' Original implementation (basic versions).
'==============================================================================
Option Explicit

Private Function SeriesColors() As Variant
    Dim s As String
    s = GetSetting(REG_APP, "Cycles", "ChartColors", "")
    If Len(s) = 0 Then s = "4485828|9330180|15380407|11760990|7303023|8421504"  ' blue, red, light blue, green, dark, gray (RGB longs)
    SeriesColors = Split(s, "|")
End Function

' Applies the next chart color to whatever chart element is selected.
Public Sub XC_ChartColorCycle()
    On Error GoTo eh
    Dim cols As Variant, i As Long, sel As Object, t As String, c As Long
    If ActiveChart Is Nothing Then MsgBox "Select a chart element first (a series, point, plot area, chart area, gridlines or legend).", vbInformation, APP_NAME: Exit Sub
    cols = SeriesColors()
    i = modFormatCycles.NextCycleIndex("ChartColor", UBound(cols) + 1)
    c = CLng(cols(i))
    Set sel = Selection
    t = TypeName(sel)
    Select Case t
        Case "Series"
            If sel.ChartType = xlLine Or sel.ChartType = xlLineMarkers Or sel.ChartType = xlXYScatterLines Then
                sel.Format.Line.ForeColor.RGB = c
            Else
                sel.Format.Fill.ForeColor.RGB = c
            End If
        Case "Point": sel.Format.Fill.ForeColor.RGB = c
        Case "ChartArea", "PlotArea", "Legend": sel.Format.Fill.ForeColor.RGB = c: sel.Format.Fill.Visible = msoTrue
        Case "Gridlines": sel.Format.Line.ForeColor.RGB = c
        Case Else: MsgBox "Cannot color a " & t & ".", vbInformation, APP_NAME
    End Select
    Exit Sub
eh:
    ReportError "Chart Color Cycle"
End Sub

' Applies the series colors (wrapping) to every series of the selected chart(s).
Public Sub XC_RecolorSeries()
    On Error GoTo eh
    Dim cols As Variant, ch As Chart, s As Series, i As Long, n As Long, co As ChartObject, charts As Collection, v As Variant
    cols = SeriesColors()
    Set charts = New Collection
    If Not ActiveChart Is Nothing Then
        charts.Add ActiveChart
    ElseIf TypeName(Selection) = "DrawingObjects" Then
        For Each co In ActiveSheet.ChartObjects
            charts.Add co.Chart
        Next co
    Else
        If AskYesNo("No chart selected. Recolor ALL charts on the active sheet?") Then
            For Each co In ActiveSheet.ChartObjects: charts.Add co.Chart: Next co
        End If
    End If
    For Each v In charts
        Set ch = v
        i = 0
        For Each s In ch.SeriesCollection
            If s.ChartType = xlLine Or s.ChartType = xlLineMarkers Or s.ChartType = xlXYScatterLines Or s.ChartType = xlXYScatter Then
                s.Format.Line.ForeColor.RGB = CLng(cols(i Mod (UBound(cols) + 1)))
                s.MarkerBackgroundColor = CLng(cols(i Mod (UBound(cols) + 1)))
                s.MarkerForegroundColor = CLng(cols(i Mod (UBound(cols) + 1)))
            Else
                s.Format.Fill.ForeColor.RGB = CLng(cols(i Mod (UBound(cols) + 1)))
            End If
            i = i + 1
        Next s
        n = n + 1
    Next v
    Done "Recolor Series: " & Plural(n, "chart") & " recolored."
    Exit Sub
eh:
    ReportError "Recolor Chart Series"
End Sub

Public Sub XC_ChartColorSettings()
    Dim s As String
    s = AskText("Series colors as RGB long values separated by | (first = Series 1):", Join(SeriesColors(), "|"), "Chart Colors")
    If Len(s) > 0 Then SaveSetting REG_APP, "Cycles", "ChartColors", s
End Sub

'--- Waterfall ----------------------------------------------------------------------
' Select two columns: labels and values (first row = start, last row = end, optional).
Public Sub XC_WaterfallChart()
    On Error GoTo eh
    Dim rng As Range, n As Long, i As Long, ws As Worksheet, hdr As Boolean, firstRow As Long, helper As Range, co As ChartObject, ch As Chart
    Dim running As Double, v As Double, baseNm As Double, up As Double, down As Double, lastIsTotal As Boolean, startCol As Long, tmpTop As Long
    Set rng = SelRangeOrRegion()
    If rng Is Nothing Then Exit Sub
    If rng.Columns.Count <> 2 Then MsgBox "Select two columns: labels and values.", vbExclamation, APP_NAME: Exit Sub
    Set ws = rng.Worksheet
    hdr = Not IsNumeric(rng.Cells(1, 2).Value)
    firstRow = IIf(hdr, 2, 1)
    lastIsTotal = AskYesNo("Is the LAST value a total (end point) rather than a change?")
    n = rng.Rows.Count - firstRow + 1
    If n < 2 Then Exit Sub
    SafeStart "Building waterfall"
    ' helper table to the right of the used range: Label | Base | Up | Down | Total
    startCol = ws.UsedRange.Column + ws.UsedRange.Columns.Count + 1
    tmpTop = rng.Row
    Set helper = ws.Range(ws.Cells(tmpTop, startCol), ws.Cells(tmpTop + n, startCol + 4))
    helper.Rows(1).Value = Array("Label", "Base", "Increase", "Decrease", "Total")
    running = 0
    For i = 1 To n
        v = CDbl(rng.Cells(firstRow + i - 1, 2).Value)
        helper.Cells(i + 1, 1).Value = rng.Cells(firstRow + i - 1, 1).Text
        baseNm = 0: up = 0: down = 0
        If i = 1 Or (i = n And lastIsTotal) Then
            helper.Cells(i + 1, 5).Value = v
            running = v
        Else
            If v >= 0 Then
                baseNm = running: up = v
            Else
                baseNm = running + v: down = -v
            End If
            running = running + v
            helper.Cells(i + 1, 2).Value = baseNm
            helper.Cells(i + 1, 3).Value = up
            helper.Cells(i + 1, 4).Value = down
        End If
    Next i
    Set co = ws.ChartObjects.Add(rng.Left + rng.Width + 20, rng.Top, 480, 300)
    Set ch = co.Chart
    ch.ChartType = xlColumnStacked
    ch.SetSourceData helper
    ch.SeriesCollection(1).Format.Fill.Visible = msoFalse
    ch.SeriesCollection(1).Format.Line.Visible = msoFalse
    ch.SeriesCollection(2).Format.Fill.ForeColor.RGB = RGB(112, 173, 71)
    ch.SeriesCollection(3).Format.Fill.ForeColor.RGB = RGB(192, 0, 0)
    ch.SeriesCollection(4).Format.Fill.ForeColor.RGB = RGB(68, 114, 196)
    ch.ChartGroups(1).GapWidth = 40
    ch.HasLegend = False
    ch.HasTitle = True: ch.ChartTitle.Text = "Waterfall"
    ch.Axes(xlCategory).TickLabelPosition = xlTickLabelPositionLow
    helper.Font.Color = RGB(150, 150, 150)
    SafeEnd
    Done "Waterfall chart created. The helper table (" & helper.Address(False, False) & ") feeds the chart - keep or hide it."
    Exit Sub
eh:
    ReportError "Waterfall Chart"
End Sub

'--- Floating-bar range chart ---------------------------------------------------
' Select three columns: label, low, high.
Public Sub XC_RangeBarChart()
    On Error GoTo eh
    Dim rng As Range, ws As Worksheet, hdr As Boolean, firstRow As Long, n As Long, i As Long, helper As Range, co As ChartObject, ch As Chart, startCol As Long
    Set rng = SelRangeOrRegion()
    If rng Is Nothing Then Exit Sub
    If rng.Columns.Count <> 3 Then MsgBox "Select three columns: label, low value, high value.", vbExclamation, APP_NAME: Exit Sub
    Set ws = rng.Worksheet
    hdr = Not IsNumeric(rng.Cells(1, 2).Value)
    firstRow = IIf(hdr, 2, 1)
    n = rng.Rows.Count - firstRow + 1
    SafeStart "Building chart"
    startCol = ws.UsedRange.Column + ws.UsedRange.Columns.Count + 1
    Set helper = ws.Range(ws.Cells(rng.Row, startCol), ws.Cells(rng.Row + n, startCol + 2))
    helper.Rows(1).Value = Array("Label", "Low", "Range")
    For i = 1 To n
        helper.Cells(i + 1, 1).Value = rng.Cells(firstRow + i - 1, 1).Text
        helper.Cells(i + 1, 2).Value = rng.Cells(firstRow + i - 1, 2).Value
        helper.Cells(i + 1, 3).Value = rng.Cells(firstRow + i - 1, 3).Value - rng.Cells(firstRow + i - 1, 2).Value
    Next i
    Set co = ws.ChartObjects.Add(rng.Left + rng.Width + 20, rng.Top, 480, 300)
    Set ch = co.Chart
    ch.ChartType = xlBarStacked
    ch.SetSourceData helper
    ch.SeriesCollection(1).Format.Fill.Visible = msoFalse
    ch.SeriesCollection(1).Format.Line.Visible = msoFalse
    ch.SeriesCollection(2).Format.Fill.ForeColor.RGB = RGB(68, 114, 196)
    ch.ChartGroups(1).GapWidth = 60
    ch.HasLegend = False
    ch.Axes(xlCategory).ReversePlotOrder = True
    ch.HasTitle = True: ch.ChartTitle.Text = "Valuation Range"
    helper.Font.Color = RGB(150, 150, 150)
    SafeEnd
    Done "Floating-bar range chart created. Helper table: " & helper.Address(False, False)
    Exit Sub
eh:
    ReportError "Floating-Bar Range Chart"
End Sub

'--- Combo chart (columns + line on secondary axis) ---------------------------------------
Public Sub XC_ComboChart()
    On Error GoTo eh
    Dim rng As Range, co As ChartObject, ch As Chart, s As Series, i As Long, lineIdx As Variant
    Set rng = SelRangeOrRegion()
    If rng Is Nothing Then Exit Sub
    If rng.Columns.Count < 3 Then MsgBox "Select at least three columns: categories and two or more series.", vbExclamation, APP_NAME: Exit Sub
    lineIdx = AskNumber("Which series should be a LINE on the secondary axis? (1 = first data column, " & (rng.Columns.Count - 1) & " = last)", rng.Columns.Count - 1, "Combo Chart", 1, rng.Columns.Count - 1)
    If IsEmpty(lineIdx) Then Exit Sub
    SafeStart "Building chart"
    Set co = rng.Worksheet.ChartObjects.Add(rng.Left + rng.Width + 20, rng.Top, 480, 300)
    Set ch = co.Chart
    ch.ChartType = xlColumnClustered
    ch.SetSourceData rng
    i = 0
    For Each s In ch.SeriesCollection
        i = i + 1
        If i = lineIdx Then
            s.ChartType = xlLineMarkers
            s.AxisGroup = xlSecondary
        End If
    Next s
    ch.HasLegend = True
    SafeEnd
    Exit Sub
eh:
    ReportError "Combo Chart"
End Sub
