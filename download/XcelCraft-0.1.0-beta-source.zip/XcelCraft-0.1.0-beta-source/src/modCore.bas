Attribute VB_Name = "modCore"
'==============================================================================
' SPDX-License-Identifier: MIT
' XcelCraft - modCore
' Shared helpers used by every tool module.
'
' Original VBA utility and modeling toolset for Excel.
' No third-party code.
'==============================================================================
Option Explicit
Option Private Module

Public Const APP_NAME As String = "XcelCraft"
Public Const APP_VERSION As String = "0.1.0-beta"
Public Const REG_APP As String = "XcelCraft"

' --- application events (previous sheet tracking, cell-type coloring on entry) ---
Public gPrevSheetName As String
Public gPrevSheetBook As String
Private mAppEvents As clsAppEvents

Public Sub HookAppEvents()
    On Error Resume Next
    Set mAppEvents = New clsAppEvents
    Set mAppEvents.App = Application
End Sub

Public Sub UnhookAppEvents()
    On Error Resume Next
    Set mAppEvents = Nothing
End Sub

' --- one-level undo buffer (in-place tools call SnapshotRange before writing) ---
Private mUndoSheet As Worksheet
Private mUndoAddress As String
Private mUndoFormulas As Variant
Private mUndoFormats As Variant   ' NumberFormat per cell (optional)
Private mUndoToolName As String
Private mUndoHasFormats As Boolean

' --- state saved by SafeStart / restored by SafeEnd ---
Private mSavedCalc As XlCalculation
Private mSavedEvents As Boolean
Private mSavedScreen As Boolean
Private mSavedAlerts As Boolean
Private mNesting As Long

'------------------------------------------------------------------------------
' Performance / state guards
'------------------------------------------------------------------------------
Public Sub SafeStart(Optional ByVal statusText As String = "")
    If mNesting = 0 Then
        mSavedScreen = Application.ScreenUpdating
        mSavedEvents = Application.EnableEvents
        mSavedAlerts = Application.DisplayAlerts
        mSavedCalc = Application.Calculation
        Application.ScreenUpdating = False
        Application.EnableEvents = False
        If Application.Calculation <> xlCalculationManual Then Application.Calculation = xlCalculationManual
    End If
    mNesting = mNesting + 1
    If Len(statusText) > 0 Then Application.StatusBar = APP_NAME & ": " & statusText
End Sub

Public Sub SafeEnd()
    mNesting = mNesting - 1
    If mNesting <= 0 Then
        mNesting = 0
        On Error Resume Next
        Application.Calculation = mSavedCalc
        Application.EnableEvents = mSavedEvents
        Application.DisplayAlerts = mSavedAlerts
        Application.ScreenUpdating = mSavedScreen
        Application.StatusBar = False
        On Error GoTo 0
    End If
End Sub

' Call from an error handler so state never stays broken.
Public Sub SafeAbort(Optional ByVal msg As String = "")
    mNesting = 1
    SafeEnd
    If Len(msg) > 0 Then MsgBox msg, vbExclamation, APP_NAME
End Sub

Public Sub ReportError(ByVal toolName As String)
    Dim n As Long, d As String
    n = Err.Number: d = Err.Description
    SafeAbort
    If n <> 0 Then
        MsgBox "An error occurred in '" & toolName & "'." & vbCrLf & vbCrLf & _
               "Error " & n & ": " & d, vbExclamation, APP_NAME
    End If
End Sub

'------------------------------------------------------------------------------
' Selection helpers
'------------------------------------------------------------------------------
' Returns the selected range, limited to the used range when whole rows/columns
' are selected. Returns Nothing (and tells the user) if no range is selected.
Public Function SelRange(Optional ByVal requireMultiCell As Boolean = False, _
                         Optional ByVal silent As Boolean = False) As Range
    Dim rng As Range, ur As Range, a As Range, result As Range
    If ActiveSheet Is Nothing Then Exit Function
    If TypeName(Selection) <> "Range" Then
        If Not silent Then MsgBox "Please select a range of cells first.", vbInformation, APP_NAME
        Exit Function
    End If
    Set rng = Selection
    Set ur = rng.Worksheet.UsedRange
    For Each a In rng.Areas
        If a.Rows.Count = a.Worksheet.Rows.Count Or a.Columns.Count = a.Worksheet.Columns.Count Then
            Set a = Intersect(a, ur)
        End If
        If Not a Is Nothing Then
            If result Is Nothing Then Set result = a Else Set result = Union(result, a)
        End If
    Next a
    If result Is Nothing Then
        If Not silent Then MsgBox "The selection contains no used cells.", vbInformation, APP_NAME
        Exit Function
    End If
    If requireMultiCell And result.Cells.CountLarge < 2 Then
        If Not silent Then MsgBox "Please select more than one cell.", vbInformation, APP_NAME
        Exit Function
    End If
    Set SelRange = result
End Function

' Range of cells the user selected, expanded to the current region if only one
' cell is selected (handy for "whole table" tools).
Public Function SelRangeOrRegion() As Range
    Dim r As Range
    Set r = SelRange(False, True)
    If r Is Nothing Then Exit Function
    If r.Cells.CountLarge = 1 Then Set r = r.CurrentRegion
    Set SelRangeOrRegion = r
End Function

Public Function IsFormulaText(ByVal v As Variant) As Boolean
    If VarType(v) = vbString Then IsFormulaText = (Left$(v, 1) = "=")
End Function

' Writes a string back to a cell as text, preserving it as text even when it
' looks numeric (e.g. "007", "1/2").
Public Sub WriteText(ByVal c As Range, ByVal s As String)
    If Len(s) = 0 Then
        c.ClearContents
    ElseIf IsNumeric(s) Or IsDate(s) Or Left$(s, 1) = "=" Or Left$(s, 1) = "+" Or Left$(s, 1) = "-" Or Left$(s, 1) = "@" Then
        c.Formula = "'" & s
    Else
        c.Value = s
    End If
End Sub

' Core engine for most text tools: applies a transform to every non-formula
' text cell. mode is dispatched by modText.TransformText.
Public Function ForEachTextCell(ByVal rng As Range, ByVal mode As String, _
                                Optional ByVal p1 As Variant, Optional ByVal p2 As Variant, _
                                Optional ByVal p3 As Variant, Optional ByVal includeNumbers As Boolean = False) As Long
    Dim a As Range, arr As Variant, r As Long, cc As Long, v As Variant, s As String, nv As String
    Dim changed As Long, c As Range
    For Each a In rng.Areas
        arr = a.Formula
        If Not IsArray(arr) Then
            Dim tmp(1 To 1, 1 To 1) As Variant
            tmp(1, 1) = arr: arr = tmp
        End If
        For r = 1 To UBound(arr, 1)
            For cc = 1 To UBound(arr, 2)
                v = arr(r, cc)
                If Not IsEmpty(v) And Not IsFormulaText(v) Then
                    Set c = a.Cells(r, cc)
                    If VarType(c.Value) = vbString Or includeNumbers Then
                        s = CStr(c.Value)
                        nv = modText.TransformText(s, mode, p1, p2, p3)
                        If nv <> s Then
                            WriteText c, nv
                            changed = changed + 1
                        End If
                    End If
                End If
            Next cc
        Next r
    Next a
    ForEachTextCell = changed
End Function

'------------------------------------------------------------------------------
' Undo (one level, in-place range tools)
'------------------------------------------------------------------------------
Public Sub SnapshotRange(ByVal rng As Range, ByVal toolName As String, Optional ByVal withFormats As Boolean = False)
    On Error GoTo fail
    If rng.Areas.Count > 1 Then Set rng = BoundingBox(rng)
    If rng.Cells.CountLarge > 2000000 Then GoTo fail ' too big to buffer safely
    Set mUndoSheet = rng.Worksheet
    mUndoAddress = rng.Address
    mUndoFormulas = rng.Formula
    mUndoToolName = toolName
    mUndoHasFormats = withFormats
    If withFormats Then
        Dim r As Long, c As Long
        ReDim mUndoFormats(1 To rng.Rows.Count, 1 To rng.Columns.Count)
        For r = 1 To rng.Rows.Count
            For c = 1 To rng.Columns.Count
                mUndoFormats(r, c) = rng.Cells(r, c).NumberFormat
            Next c
        Next r
    End If
    Exit Sub
fail:
    Set mUndoSheet = Nothing
    mUndoToolName = ""
End Sub

Public Sub XC_UndoLastTool()
    On Error GoTo eh
    If mUndoSheet Is Nothing Then
        MsgBox "There is nothing to undo.", vbInformation, APP_NAME
        Exit Sub
    End If
    Dim rng As Range
    Set rng = mUndoSheet.Range(mUndoAddress)
    If MsgBox("Undo '" & mUndoToolName & "' on " & mUndoSheet.Name & "!" & mUndoAddress & "?", _
              vbQuestion + vbYesNo, APP_NAME) <> vbYes Then Exit Sub
    SafeStart "Undoing..."
    mUndoSheet.Activate
    rng.Formula = mUndoFormulas
    If mUndoHasFormats Then
        Dim r As Long, c As Long
        For r = 1 To rng.Rows.Count
            For c = 1 To rng.Columns.Count
                rng.Cells(r, c).NumberFormat = mUndoFormats(r, c)
            Next c
        Next r
    End If
    rng.Select
    Set mUndoSheet = Nothing
    mUndoToolName = ""
    SafeEnd
    Exit Sub
eh:
    ReportError "Undo"
End Sub

'------------------------------------------------------------------------------
' Input helpers
'------------------------------------------------------------------------------
Public Function AskText(ByVal prompt As String, Optional ByVal defaultText As String = "", _
                        Optional ByVal title As String = "") As String
    If Len(title) = 0 Then title = APP_NAME
    AskText = InputBox(prompt, title, defaultText)
End Function

' Returns Empty if cancelled.
Public Function AskNumber(ByVal prompt As String, Optional ByVal defaultValue As Variant = 0, _
                          Optional ByVal title As String = "", Optional ByVal minValue As Variant, _
                          Optional ByVal maxValue As Variant) As Variant
    Dim v As Variant
    If Len(title) = 0 Then title = APP_NAME
    Do
        v = Application.InputBox(prompt, title, defaultValue, Type:=1)
        If VarType(v) = vbBoolean Then AskNumber = Empty: Exit Function
        If Not IsMissing(minValue) Then If v < minValue Then MsgBox "Please enter a value of at least " & minValue & ".", vbExclamation, APP_NAME: GoTo again
        If Not IsMissing(maxValue) Then If v > maxValue Then MsgBox "Please enter a value of at most " & maxValue & ".", vbExclamation, APP_NAME: GoTo again
        AskNumber = v
        Exit Function
again:
    Loop
End Function

' Numbered-choice prompt. Returns 0 if cancelled.
Public Function AskChoice(ByVal prompt As String, ByVal choices As Variant, Optional ByVal defaultChoice As Long = 1) As Long
    Dim i As Long, s As String, v As Variant
    s = prompt & vbCrLf & vbCrLf
    For i = LBound(choices) To UBound(choices)
        s = s & (i - LBound(choices) + 1) & ". " & choices(i) & vbCrLf
    Next i
    Do
        v = Application.InputBox(s, APP_NAME, defaultChoice, Type:=1)
        If VarType(v) = vbBoolean Then AskChoice = 0: Exit Function
        If v >= 1 And v <= (UBound(choices) - LBound(choices) + 1) Then AskChoice = CLng(v): Exit Function
    Loop
End Function

Public Function AskYesNo(ByVal prompt As String, Optional ByVal defaultYes As Boolean = True) As Boolean
    Dim flags As VbMsgBoxStyle
    flags = vbQuestion + vbYesNo
    If Not defaultYes Then flags = flags + vbDefaultButton2
    AskYesNo = (MsgBox(prompt, flags, APP_NAME) = vbYes)
End Function

Public Function AskRange(ByVal prompt As String, Optional ByVal defaultAddr As String = "") As Range
    On Error Resume Next
    Set AskRange = Application.InputBox(prompt, APP_NAME, defaultAddr, Type:=8)
    On Error GoTo 0
End Function

Public Sub Done(ByVal msg As String)
    Application.StatusBar = False
    If GetSetting(REG_APP, "Options", "QuietMode", "0") <> "1" Then
        MsgBox msg, vbInformation, APP_NAME
    End If
End Sub

Public Function Plural(ByVal n As Long, ByVal singular As String, Optional ByVal pluralWord As String = "") As String
    If Len(pluralWord) = 0 Then pluralWord = singular & "s"
    Plural = n & " " & IIf(n = 1, singular, pluralWord)
End Function

'------------------------------------------------------------------------------
' Misc helpers
'------------------------------------------------------------------------------
Public Function IsMac() As Boolean
    #If Mac Then
        IsMac = True
    #Else
        IsMac = False
    #End If
End Function

Public Function SheetExists(ByVal nm As String, Optional ByVal wb As Workbook) As Boolean
    Dim s As Object
    If wb Is Nothing Then Set wb = ActiveWorkbook
    On Error Resume Next
    Set s = wb.Sheets(nm)
    SheetExists = Not s Is Nothing
    On Error GoTo 0
End Function

Public Function SafeSheetName(ByVal nm As String) As String
    Dim bad As Variant, i As Long
    bad = Array("\", "/", "?", "*", "[", "]", ":")
    For i = LBound(bad) To UBound(bad)
        nm = Replace(nm, bad(i), "_")
    Next i
    nm = Trim$(nm)
    If Len(nm) = 0 Then nm = "Sheet"
    If Len(nm) > 31 Then nm = Left$(nm, 31)
    SafeSheetName = nm
End Function

Public Function UniqueSheetName(ByVal baseNm As String, Optional ByVal wb As Workbook) As String
    Dim nm As String, i As Long
    If wb Is Nothing Then Set wb = ActiveWorkbook
    baseNm = SafeSheetName(baseNm)
    nm = baseNm
    i = 1
    Do While SheetExists(nm, wb)
        i = i + 1
        nm = Left$(baseNm, 31 - Len(" (" & i & ")")) & " (" & i & ")"
    Loop
    UniqueSheetName = nm
End Function

Public Function NewReportSheet(ByVal title As String, Optional ByVal inNewWorkbook As Boolean = True) As Worksheet
    Dim ws As Worksheet
    If inNewWorkbook Then
        Set ws = Workbooks.Add(xlWBATWorksheet).Worksheets(1)
    Else
        Set ws = ActiveWorkbook.Worksheets.Add(After:=ActiveWorkbook.Sheets(ActiveWorkbook.Sheets.Count))
    End If
    On Error Resume Next
    ws.Name = UniqueSheetName(title, ws.Parent)
    On Error GoTo 0
    Set NewReportSheet = ws
End Function

Public Function RegexReplace(ByVal s As String, ByVal pattern As String, ByVal repl As String, _
                             Optional ByVal ignoreCase As Boolean = True) As String
    ' Windows: VBScript RegExp. Mac: no RegExp object; caller must provide fallback.
    #If Mac Then
        RegexReplace = s
    #Else
        Dim re As Object
        Set re = CreateObject("VBScript.RegExp")
        re.Global = True
        re.IgnoreCase = ignoreCase
        re.pattern = pattern
        RegexReplace = re.Replace(s, repl)
    #End If
End Function

Public Function HasRegex() As Boolean
    #If Mac Then
        HasRegex = False
    #Else
        HasRegex = True
    #End If
End Function

' Put text on the clipboard (Windows via MSForms DataObject or HTML; Mac via osascript-free fallback).
Public Sub SetClipboardText(ByVal s As String)
    #If Mac Then
        ' Simplest cross-version approach on Mac: route through a cell copy.
        Dim wsTmp As Worksheet
        Set wsTmp = Workbooks.Add(xlWBATWorksheet).Worksheets(1)
        wsTmp.Range("A1").Value = s
        wsTmp.Range("A1").Copy
        ' leave the temp workbook open; closing it clears the clipboard
    #Else
        Dim o As Object
        On Error GoTo fallback
        Set o = CreateObject("New:{1C3B4210-F441-11CE-B9EA-00AA006B1A69}") ' MSForms.DataObject
        o.SetText s
        o.PutInClipboard
        Exit Sub
fallback:
        ' last resort: use a temp cell
        Dim wsT As Worksheet
        Set wsT = Workbooks.Add(xlWBATWorksheet).Worksheets(1)
        wsT.Range("A1").Value = s
        wsT.Range("A1").Copy
    #End If
End Sub

' Smallest single rectangle that contains every area of a multi-area range.
Public Function BoundingBox(ByVal rng As Range) As Range
    Dim a As Range, r1 As Long, c1 As Long, r2 As Long, c2 As Long
    r1 = rng.Worksheet.Rows.Count: c1 = rng.Worksheet.Columns.Count: r2 = 1: c2 = 1
    For Each a In rng.Areas
        If a.Row < r1 Then r1 = a.Row
        If a.Column < c1 Then c1 = a.Column
        If a.Row + a.Rows.Count - 1 > r2 Then r2 = a.Row + a.Rows.Count - 1
        If a.Column + a.Columns.Count - 1 > c2 Then c2 = a.Column + a.Columns.Count - 1
    Next a
    Set BoundingBox = rng.Worksheet.Range(rng.Worksheet.Cells(r1, c1), rng.Worksheet.Cells(r2, c2))
End Function

Public Function Max2(ByVal a As Variant, ByVal b As Variant) As Variant
    If a > b Then Max2 = a Else Max2 = b
End Function

Public Function Min2(ByVal a As Variant, ByVal b As Variant) As Variant
    If a < b Then Min2 = a Else Min2 = b
End Function

' Read a 2-D variant array from a range even for single cells.
Public Function RangeToArray(ByVal rng As Range, Optional ByVal useFormula As Boolean = False) As Variant
    Dim v As Variant
    If useFormula Then v = rng.Formula Else v = rng.Value2
    If Not IsArray(v) Then
        Dim t(1 To 1, 1 To 1) As Variant
        t(1, 1) = v
        v = t
    End If
    RangeToArray = v
End Function
