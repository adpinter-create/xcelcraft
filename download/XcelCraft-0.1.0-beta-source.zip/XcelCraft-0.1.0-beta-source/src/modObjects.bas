Attribute VB_Name = "modObjects"
'==============================================================================
' SPDX-License-Identifier: MIT
' XcelCraft - modObjects
' Objects & Comments category. Original implementation.
'==============================================================================
Option Explicit

'--- Comments / notes manager ----------------------------------------------------
Public Sub XC_ManageComments()
    On Error GoTo eh
    Dim mode As Long, ws As Worksheet, cm As Comment, n As Long, rpt As Worksheet, r As Long, scope As Long, author As String, f As String, rp As String
    Dim shList As Collection, sh As Object, v As Variant
    mode = AskChoice("Comments / notes:", Array( _
        "List all comments in a new workbook (sheet, cell, author, text)", _
        "Resize all comments to fit their text", _
        "Change the author name in all comments", _
        "Find and replace text inside comments", _
        "Delete all comments", _
        "Show all comments", "Hide all comments", _
        "Convert comments to cell values (column to the right)"))
    If mode = 0 Then Exit Sub
    scope = AskChoice("Scope:", Array("Active sheet", "All worksheets"))
    If scope = 0 Then Exit Sub
    Set shList = New Collection
    If scope = 1 Then
        shList.Add ActiveSheet
    Else
        For Each ws In ActiveWorkbook.Worksheets: shList.Add ws: Next ws
    End If
    Select Case mode
        Case 3
            author = AskText("New author name:", Application.UserName, "Comments")
            If Len(author) = 0 Then Exit Sub
        Case 4
            f = AskText("Find:", "", "Comments"): If Len(f) = 0 Then Exit Sub
            rp = AskText("Replace with:", "", "Comments")
        Case 5
            If Not AskYesNo("Delete ALL comments/notes in the chosen scope?", False) Then Exit Sub
    End Select
    SafeStart "Processing comments"
    If mode = 1 Then
        Set rpt = NewReportSheet("Comments")
        rpt.Range("A1:D1").Value = Array("Sheet", "Cell", "Author", "Comment")
        rpt.Range("A1:D1").Font.Bold = True
        r = 2
    End If
    For Each v In shList
        Set ws = v
        For Each cm In ws.Comments
            Select Case mode
                Case 1
                    rpt.Cells(r, 1).Value = ws.Name: rpt.Cells(r, 2).Value = cm.Parent.Address(False, False)
                    rpt.Cells(r, 3).Value = cm.Author: rpt.Cells(r, 4).Value = cm.Text
                    r = r + 1
                Case 2
                    cm.Shape.TextFrame.AutoSize = True
                Case 3
                    Dim txt As String, p As Long
                    txt = cm.Text
                    p = InStr(txt, ":")
                    If p > 0 And p < 60 Then txt = author & ":" & Mid$(txt, p + 1) Else txt = author & ":" & vbLf & txt
                    cm.Text Text:=txt
                Case 4
                    If InStr(1, cm.Text, f, vbTextCompare) > 0 Then cm.Text Text:=Replace(cm.Text, f, rp, , , vbTextCompare)
                Case 6: cm.Visible = True
                Case 7: cm.Visible = False
                Case 8: cm.Parent.Offset(0, 1).Value = cm.Text
            End Select
            n = n + 1
        Next cm
        If mode = 5 Then ws.Cells.ClearComments
    Next v
    If mode = 1 Then rpt.Columns("A:D").AutoFit: If rpt.Columns("D").ColumnWidth > 80 Then rpt.Columns("D").ColumnWidth = 80
    SafeEnd
    Done "Comments: " & Plural(n, "comment") & " processed."
    Exit Sub
eh:
    ReportError "Edit, Extract and Manage Comments"
End Sub

Public Sub XC_AddValueToComment()
    On Error GoTo eh
    Dim rng As Range, c As Range, mode As Long, n As Long, s As String
    Set rng = SelRange()
    If rng Is Nothing Then Exit Sub
    mode = AskChoice("Add to each cell's comment:", Array("The cell's current VALUE", "The cell's FORMULA (or value if none)", "Both"))
    If mode = 0 Then Exit Sub
    SafeStart "Adding comments"
    For Each c In rng.Cells
        If Not IsEmpty(c.Value) Then
            Select Case mode
                Case 1: s = c.Text
                Case 2: s = c.Formula
                Case 3: s = c.Text & IIf(c.HasFormula, vbLf & c.Formula, "")
            End Select
            If c.Comment Is Nothing Then
                c.AddComment s
            Else
                c.Comment.Text Text:=c.Comment.Text & vbLf & s
            End If
            c.Comment.Shape.TextFrame.AutoSize = True
            n = n + 1
        End If
    Next c
    SafeEnd
    Done "Add Value/Formula to Comment: " & Plural(n, "cell") & "."
    Exit Sub
eh:
    ReportError "Add Cell's Value or Formula to Comment"
End Sub

'--- Objects -------------------------------------------------------------------------
Public Sub XC_DeleteAllObjects()
    On Error GoTo eh
    Dim sh As Object, i As Long, n As Long, keepComments As Boolean
    If Not AskYesNo("Delete ALL shapes, pictures, charts and controls on the " & ActiveWindow.SelectedSheets.Count & " selected sheet(s)?", False) Then Exit Sub
    SafeStart "Deleting objects"
    For Each sh In ActiveWindow.SelectedSheets
        If TypeName(sh) = "Worksheet" Then
            For i = sh.Shapes.Count To 1 Step -1
                If sh.Shapes(i).Type <> msoComment Then sh.Shapes(i).Delete: n = n + 1
            Next i
        End If
    Next sh
    SafeEnd
    Done "Delete All Objects: " & Plural(n, "object") & " deleted."
    Exit Sub
eh:
    ReportError "Delete All Objects"
End Sub

Public Sub XC_DeleteFormButtons()
    On Error GoTo eh
    Dim sh As Object, i As Long, n As Long
    SafeStart "Deleting form buttons"
    For Each sh In ActiveWindow.SelectedSheets
        If TypeName(sh) = "Worksheet" Then
            For i = sh.Shapes.Count To 1 Step -1
                If sh.Shapes(i).Type = msoFormControl Then
                    If sh.Shapes(i).FormControlType = xlButtonControl Then sh.Shapes(i).Delete: n = n + 1
                End If
            Next i
        End If
    Next sh
    SafeEnd
    Done "Delete All Form Buttons: " & Plural(n, "button") & " deleted."
    Exit Sub
eh:
    ReportError "Delete All Form Buttons"
End Sub

Public Sub XC_ResizePictures()
    On Error GoTo eh
    Dim pct As Variant, shp As Shape, n As Long, scope As Long, sr As ShapeRange, i As Long
    pct = AskNumber("Resize pictures and OLE objects to what percent of their ORIGINAL size?", 100, "Resize Pictures", 1, 1000)
    If IsEmpty(pct) Then Exit Sub
    scope = AskChoice("Apply to:", Array("Selected objects", "All pictures/OLE objects on the active sheet"))
    If scope = 0 Then Exit Sub
    SafeStart "Resizing"
    If scope = 1 Then
        On Error Resume Next
        Set sr = Selection.ShapeRange
        On Error GoTo eh
        If sr Is Nothing Then MsgBox "Select one or more pictures first.", vbInformation, APP_NAME: SafeEnd: Exit Sub
        For i = 1 To sr.Count
            Set shp = sr(i)
            shp.LockAspectRatio = msoTrue
            shp.ScaleWidth pct / 100, msoTrue
            shp.ScaleHeight pct / 100, msoTrue
            n = n + 1
        Next i
    Else
        For Each shp In ActiveSheet.Shapes
            If shp.Type = msoPicture Or shp.Type = msoLinkedPicture Or shp.Type = msoEmbeddedOLEObject Or shp.Type = msoLinkedOLEObject Then
                shp.LockAspectRatio = msoTrue
                shp.ScaleWidth pct / 100, msoTrue
                shp.ScaleHeight pct / 100, msoTrue
                n = n + 1
            End If
        Next shp
    End If
    SafeEnd
    Done "Resize Pictures: " & Plural(n, "object") & " resized to " & pct & "% of original size."
    Exit Sub
eh:
    ReportError "Resize Pictures and OLE Objects"
End Sub

Public Sub XC_RemoveShapeBorders()
    On Error GoTo eh
    Dim sr As ShapeRange, i As Long, n As Long
    On Error Resume Next
    Set sr = Selection.ShapeRange
    On Error GoTo eh
    If sr Is Nothing Then MsgBox "Select one or more shapes or pictures first.", vbInformation, APP_NAME: Exit Sub
    For i = 1 To sr.Count
        sr(i).Line.Visible = msoFalse
        n = n + 1
    Next i
    Done "Border line removed from " & Plural(n, "shape") & "."
    Exit Sub
eh:
    ReportError "Remove Border Line from Selected Shapes"
End Sub
