Attribute VB_Name = "modInfo"
'==============================================================================
' SPDX-License-Identifier: MIT
' XcelCraft - modInfo
' Info & List category. Original implementation.
'==============================================================================
Option Explicit

Public Sub XC_AnalyzeCells()
    On Error GoTo eh
    Dim rng As Range, c As Range, v As Variant, cnt As Long, nums As Long, txt As Long, blanks As Long, fml As Long, errs As Long, bools As Long, dates As Long
    Dim sum As Double, mn As Double, mx As Double, first As Boolean, s As String, distinct As Collection, k As String, vis As Long
    Set rng = SelRange()
    If rng Is Nothing Then Exit Sub
    SafeStart "Analyzing"
    Set distinct = New Collection
    first = True
    For Each c In rng.Cells
        cnt = cnt + 1
        v = c.Value
        If Not c.EntireRow.Hidden And Not c.EntireColumn.Hidden Then vis = vis + 1
        If c.HasFormula Then fml = fml + 1
        If IsEmpty(v) Then
            blanks = blanks + 1
        ElseIf IsError(v) Then
            errs = errs + 1
        ElseIf VarType(v) = vbBoolean Then
            bools = bools + 1
        ElseIf VarType(v) = vbDate Then
            dates = dates + 1
        ElseIf VarType(v) = vbString Then
            txt = txt + 1
        ElseIf IsNumeric(v) Then
            nums = nums + 1
            sum = sum + CDbl(v)
            If first Then mn = v: mx = v: first = False
            If v < mn Then mn = v
            If v > mx Then mx = v
        End If
        If Not IsEmpty(v) And Not IsError(v) Then
            k = "k" & LCase$(CStr(v))
            On Error Resume Next
            distinct.Add 1, k
            On Error GoTo eh
        End If
    Next c
    SafeEnd
    s = "Selection: " & rng.Address(False, False) & vbCrLf & vbCrLf
    s = s & "Cells: " & cnt & "   (visible: " & vis & ")" & vbCrLf
    s = s & "Empty: " & blanks & vbCrLf
    s = s & "Numbers: " & nums & vbCrLf
    s = s & "Text: " & txt & vbCrLf
    s = s & "Dates: " & dates & "   Booleans: " & bools & vbCrLf
    s = s & "Formulas: " & fml & "   Errors: " & errs & vbCrLf
    s = s & "Distinct values: " & distinct.Count & vbCrLf & vbCrLf
    If nums > 0 Then
        s = s & "Sum: " & Format$(sum, "#,##0.####") & vbCrLf
        s = s & "Average: " & Format$(sum / nums, "#,##0.####") & vbCrLf
        s = s & "Min: " & Format$(mn, "#,##0.####") & "   Max: " & Format$(mx, "#,##0.####") & vbCrLf
    End If
    MsgBox s, vbInformation, "Analyze Selected Cells"
    Exit Sub
eh:
    ReportError "Analyze Selected Cells"
End Sub

Public Sub XC_WorkbookDetails()
    On Error GoTo eh
    Dim wb As Workbook, s As String, ws As Worksheet, cellCount As Double, fml As Long, fr As Range, names As Long, cmts As Long, shapes As Long, sz As String
    Set wb = ActiveWorkbook
    SafeStart "Collecting details"
    For Each ws In wb.Worksheets
        cellCount = cellCount + ws.UsedRange.Cells.CountLarge
        Set fr = Nothing
        On Error Resume Next
        Set fr = ws.UsedRange.SpecialCells(xlCellTypeFormulas)
        On Error GoTo eh
        If Not fr Is Nothing Then fml = fml + fr.Cells.CountLarge
        cmts = cmts + ws.Comments.Count
        shapes = shapes + ws.Shapes.Count
    Next ws
    On Error Resume Next
    sz = Format$(FileLen(wb.FullName) / 1024, "#,##0") & " KB"
    On Error GoTo eh
    SafeEnd
    s = "Workbook: " & wb.Name & vbCrLf & "Path: " & wb.Path & vbCrLf & "Size on disk: " & IIf(Len(sz) > 0, sz, "(not saved)") & vbCrLf & _
        "File format: " & wb.FileFormat & vbCrLf & "Saved: " & wb.Saved & "   Read-only: " & wb.ReadOnly & vbCrLf & vbCrLf & _
        "Worksheets: " & wb.Worksheets.Count & "   Charts: " & wb.Charts.Count & "   Total sheets: " & wb.Sheets.Count & vbCrLf & _
        "Used cells (sum of used ranges): " & Format$(cellCount, "#,##0") & vbCrLf & "Formulas: " & Format$(fml, "#,##0") & vbCrLf & _
        "Defined names: " & wb.Names.Count & "   Comments: " & cmts & "   Shapes/objects: " & shapes & vbCrLf & _
        "Styles: " & wb.Styles.Count & "   Links to other workbooks: " & LinkCount(wb) & vbCrLf & vbCrLf
    If TypeName(Selection) = "Range" Then
        s = s & "Active sheet: " & ActiveSheet.Name & "   Used range: " & ActiveSheet.UsedRange.Address(False, False) & vbCrLf & _
            "Selection: " & Selection.Address(False, False) & "   Cells: " & Format$(Selection.Cells.CountLarge, "#,##0") & "   Areas: " & Selection.Areas.Count & vbCrLf & _
            "Active cell: " & ActiveCell.Address(False, False) & "   Number format: " & ActiveCell.NumberFormat & vbCrLf
    End If
    MsgBox s, vbInformation, "Workbook and Selection Details"
    Exit Sub
eh:
    ReportError "Workbook and Selection Details"
End Sub

Private Function LinkCount(ByVal wb As Workbook) As Long
    Dim l As Variant
    On Error Resume Next
    l = wb.LinkSources(xlExcelLinks)
    If IsArray(l) Then LinkCount = UBound(l) - LBound(l) + 1
End Function

Public Sub XC_CopyPathToClipboard()
    On Error GoTo eh
    SetClipboardText ActiveWorkbook.FullName
    Application.StatusBar = APP_NAME & ": copied " & ActiveWorkbook.FullName
    Exit Sub
eh:
    ReportError "Copy Full File Path to Clipboard"
End Sub

Public Sub XC_PrintedPageNumber()
    On Error GoTo eh
    Dim ws As Worksheet, c As Range, hp As Long, vp As Long, hpb As HPageBreak, vpb As VPageBreak, pageNo As Long, hCount As Long, vCount As Long, pa As Range
    Set ws = ActiveSheet: Set c = ActiveCell
    SafeStart
    ws.DisplayPageBreaks = True
    If Len(ws.PageSetup.PrintArea) > 0 Then Set pa = ws.Range(ws.PageSetup.PrintArea) Else Set pa = ws.UsedRange
    hp = 1: vp = 1
    For Each hpb In ws.HPageBreaks
        If hpb.Location.Row <= c.Row Then hp = hp + 1
    Next hpb
    For Each vpb In ws.VPageBreaks
        If vpb.Location.Column <= c.Column Then vp = vp + 1
    Next vpb
    hCount = ws.HPageBreaks.Count + 1: vCount = ws.VPageBreaks.Count + 1
    If ws.PageSetup.Order = xlDownThenOver Then
        pageNo = (vp - 1) * hCount + hp
    Else
        pageNo = (hp - 1) * vCount + vp
    End If
    SafeEnd
    MsgBox "Cell " & c.Address(False, False) & " prints on page " & pageNo & " of " & (hCount * vCount) & "." & vbCrLf & _
           "(Page order: " & IIf(ws.PageSetup.Order = xlDownThenOver, "down, then over", "over, then down") & ")", vbInformation, APP_NAME
    Exit Sub
eh:
    ReportError "Find the Printed Page Number"
End Sub

Public Sub XC_CountDistinct()
    On Error GoTo eh
    Dim rng As Range, c As Range, distinct As Collection, k As String, blanks As Long, mode As Long, rpt As Worksheet, r As Long, firstCells As Collection, v As Variant
    Set rng = SelRange()
    If rng Is Nothing Then Exit Sub
    mode = AskChoice("Count distinct values:", Array("Show the count", "List each distinct value with its frequency in a new workbook"))
    If mode = 0 Then Exit Sub
    SafeStart "Counting"
    Set distinct = New Collection: Set firstCells = New Collection
    For Each c In rng.Cells
        If IsEmpty(c.Value) Then
            blanks = blanks + 1
        Else
            k = "k" & LCase$(CStr(c.Value))
            On Error Resume Next
            distinct.Add c.Value, k
            If Err.Number = 0 Then firstCells.Add c, k
            Err.Clear
            On Error GoTo eh
        End If
    Next c
    If mode = 2 Then
        Set rpt = NewReportSheet("Distinct")
        rpt.Range("A1:B1").Value = Array("Value", "Count")
        rpt.Range("A1:B1").Font.Bold = True
        r = 2
        For Each v In firstCells
            rpt.Cells(r, 1).Value = v.Value
            rpt.Cells(r, 2).Value = Application.WorksheetFunction.CountIf(rng, v.Value)
            r = r + 1
        Next v
        rpt.Columns("A:B").AutoFit
    End If
    SafeEnd
    Done "Distinct values: " & distinct.Count & "   (empty cells: " & blanks & ", total cells: " & rng.Cells.CountLarge & ")"
    Exit Sub
eh:
    ReportError "Count Distinct Values"
End Sub

Public Sub XC_CountCharacters()
    On Error GoTo eh
    Dim rng As Range, c As Range, total As Long, noSpace As Long, words As Long, lines As Long, s As String, i As Long
    Set rng = SelRange()
    If rng Is Nothing Then Exit Sub
    For Each c In rng.Cells
        s = c.Text
        total = total + Len(s)
        noSpace = noSpace + Len(Replace(Replace(s, " ", ""), vbLf, ""))
        If Len(Trim$(s)) > 0 Then words = words + UBound(Split(Application.WorksheetFunction.Trim(Replace(s, vbLf, " ")), " ")) + 1
        lines = lines + UBound(Split(s, vbLf)) + IIf(Len(s) > 0, 1, 0)
    Next c
    MsgBox "Cells: " & rng.Cells.CountLarge & vbCrLf & "Characters: " & total & vbCrLf & "Characters (no spaces): " & noSpace & vbCrLf & _
           "Words: " & words & vbCrLf & "Lines: " & lines, vbInformation, "Count Characters"
    Exit Sub
eh:
    ReportError "Count Characters in Selected Cells"
End Sub

Public Sub XC_ListDocumentProperties()
    On Error GoTo eh
    Dim rpt As Worksheet, p As Object, r As Long, wb As Workbook
    Set wb = ActiveWorkbook
    Set rpt = NewReportSheet("Properties")
    rpt.Range("A1:C1").Value = Array("Property", "Value", "Type")
    rpt.Range("A1:C1").Font.Bold = True
    r = 2
    For Each p In wb.BuiltinDocumentProperties
        rpt.Cells(r, 1).Value = p.Name
        On Error Resume Next
        rpt.Cells(r, 2).Value = CStr(p.Value)
        On Error GoTo eh
        rpt.Cells(r, 3).Value = "Built-in"
        r = r + 1
    Next p
    For Each p In wb.CustomDocumentProperties
        rpt.Cells(r, 1).Value = p.Name
        On Error Resume Next
        rpt.Cells(r, 2).Value = CStr(p.Value)
        On Error GoTo eh
        rpt.Cells(r, 3).Value = "Custom"
        r = r + 1
    Next p
    rpt.Columns("A:C").AutoFit
    Exit Sub
eh:
    ReportError "List Document Properties"
End Sub

Public Sub XC_ListSheetNames()
    On Error GoTo eh
    Dim rpt As Worksheet, sh As Object, r As Long, wb As Workbook, mode As Long
    Set wb = ActiveWorkbook
    mode = AskChoice("List sheet names:", Array("In a new workbook (with details)", "In a new sheet of this workbook (with hyperlinks)"))
    If mode = 0 Then Exit Sub
    Set rpt = NewReportSheet("Sheet list", mode = 2)
    rpt.Range("A1:E1").Value = Array("#", "Sheet", "Type", "Visible", "Used range")
    rpt.Range("A1:E1").Font.Bold = True
    r = 2
    For Each sh In wb.Sheets
        If sh.Name <> rpt.Name Then
            rpt.Cells(r, 1).Value = r - 1
            If mode = 2 Then
                rpt.Hyperlinks.Add Anchor:=rpt.Cells(r, 2), Address:="", SubAddress:="'" & sh.Name & "'!A1", TextToDisplay:=sh.Name
            Else
                rpt.Cells(r, 2).Value = sh.Name
            End If
            rpt.Cells(r, 3).Value = TypeName(sh)
            rpt.Cells(r, 4).Value = VisibleText(sh.Visible)
            If TypeName(sh) = "Worksheet" Then rpt.Cells(r, 5).Value = sh.UsedRange.Address(False, False)
            r = r + 1
        End If
    Next sh
    rpt.Columns("A:E").AutoFit
    Exit Sub
eh:
    ReportError "List All Sheet Names"
End Sub

' Colors a copy of the sheet by cell type so the structure is visible at a glance.
Public Sub XC_VisualMapOfCellTypes()
    On Error GoTo eh
    Dim src As Worksheet, rpt As Worksheet, c As Range, ur As Range, v As Variant, n As Long
    Set src = ActiveSheet
    Set ur = src.UsedRange
    If ur.Cells.CountLarge > 200000 Then MsgBox "The used range is too large to map (> 200,000 cells).", vbExclamation, APP_NAME: Exit Sub
    SafeStart "Mapping"
    Set rpt = NewReportSheet("Map of " & src.Name)
    For Each c In ur.Cells
        v = c.Value
        If Not IsEmpty(v) Then
            With rpt.Range(c.Address)
                If c.HasFormula Then
                    If InStr(c.Formula, "!") > 0 Then .Interior.Color = RGB(198, 239, 206) Else .Interior.Color = RGB(255, 235, 156)
                ElseIf IsError(v) Then
                    .Interior.Color = RGB(255, 0, 0)
                ElseIf VarType(v) = vbString Then
                    .Interior.Color = RGB(221, 235, 247)
                ElseIf VarType(v) = vbDate Then
                    .Interior.Color = RGB(226, 207, 245)
                Else
                    .Interior.Color = RGB(255, 204, 153)
                End If
            End With
            n = n + 1
        End If
    Next c
    rpt.Cells.ColumnWidth = 3
    With rpt.Parent.Worksheets.Add(After:=rpt)
        .Name = "Legend"
        .Range("A1:A6").Value = Application.Transpose(Array("Legend", "Text", "Number", "Date", "Formula (same sheet)", "Formula (other sheet/workbook)"))
        .Range("A7").Value = "Error"
        .Range("A2").Interior.Color = RGB(221, 235, 247): .Range("A3").Interior.Color = RGB(255, 204, 153)
        .Range("A4").Interior.Color = RGB(226, 207, 245): .Range("A5").Interior.Color = RGB(255, 235, 156)
        .Range("A6").Interior.Color = RGB(198, 239, 206): .Range("A7").Interior.Color = RGB(255, 0, 0)
        .Columns("A").AutoFit
    End With
    rpt.Activate
    SafeEnd
    Done "Visual map created for " & Plural(n, "cell") & "."
    Exit Sub
eh:
    ReportError "Create a Visual Map of Cell Types"
End Sub

Public Sub XC_DisplaySelectionType()
    MsgBox "TypeName(Selection) = " & TypeName(Selection) & vbCrLf & IIf(TypeName(Selection) = "Range", "Address: " & Selection.Address(False, False), ""), vbInformation, APP_NAME
End Sub

Public Sub XC_CountSheets()
    On Error GoTo eh
    Dim wb As Workbook, sh As Object, ws As Long, ch As Long, mac As Long, dlg As Long, hid As Long
    Set wb = ActiveWorkbook
    For Each sh In wb.Sheets
        Select Case TypeName(sh)
            Case "Worksheet": ws = ws + 1
            Case "Chart": ch = ch + 1
            Case "DialogSheet": dlg = dlg + 1
            Case Else: mac = mac + 1
        End Select
        If sh.Visible <> xlSheetVisible Then hid = hid + 1
    Next sh
    MsgBox "Worksheets: " & ws & vbCrLf & "Chart sheets: " & ch & vbCrLf & "Macro/other sheets: " & mac & vbCrLf & "Dialog sheets: " & dlg & vbCrLf & vbCrLf & _
           "Total: " & wb.Sheets.Count & "   (hidden: " & hid & ")", vbInformation, APP_NAME
    Exit Sub
eh:
    ReportError "Count All Worksheets"
End Sub

Public Sub XC_FindRefErrors()
    On Error GoTo eh
    Dim ws As Worksheet, fr As Range, c As Range, rpt As Worksheet, r As Long, nm As Name
    SafeStart "Searching #REF!"
    Set rpt = NewReportSheet("REF errors")
    rpt.Range("A1:C1").Value = Array("Sheet / Name", "Cell", "Formula")
    rpt.Range("A1:C1").Font.Bold = True
    r = 2
    For Each ws In ActiveWorkbook.Worksheets
        Set fr = Nothing
        On Error Resume Next
        Set fr = ws.UsedRange.SpecialCells(xlCellTypeFormulas)
        On Error GoTo eh
        If Not fr Is Nothing Then
            For Each c In fr.Cells
                If InStr(c.Formula, "#REF") > 0 Then
                    rpt.Cells(r, 1).Value = ws.Name: rpt.Cells(r, 2).Value = c.Address(False, False): rpt.Cells(r, 3).Value = "'" & c.Formula
                    r = r + 1
                End If
            Next c
        End If
    Next ws
    For Each nm In ActiveWorkbook.Names
        If InStr(nm.RefersTo, "#REF") > 0 Then
            rpt.Cells(r, 1).Value = "Name: " & nm.Name: rpt.Cells(r, 3).Value = "'" & nm.RefersTo
            r = r + 1
        End If
    Next nm
    rpt.Columns("A:C").AutoFit
    SafeEnd
    Done "Find #REF! Errors: " & Plural(r - 2, "broken reference") & " found."
    Exit Sub
eh:
    ReportError "Find #REF! Formula Errors"
End Sub

Public Sub XC_FindHashColumns()
    On Error GoTo eh
    Dim ws As Worksheet, c As Range, result As Range, n As Long, t As String
    Set ws = ActiveSheet
    SafeStart "Scanning"
    For Each c In ws.UsedRange.Cells
        If Not IsEmpty(c.Value) Then
            t = c.Text
            If Len(t) > 0 And Left$(t, 1) = "#" And Len(Replace(t, "#", "")) = 0 Then
                If result Is Nothing Then Set result = c.EntireColumn Else Set result = Union(result, c.EntireColumn)
                n = n + 1
            End If
        End If
    Next c
    SafeEnd
    If result Is Nothing Then
        MsgBox "No cells showing #### found on the active sheet.", vbInformation, APP_NAME
    Else
        If AskYesNo(Plural(n, "cell") & " show ####. Autofit the affected column(s) (" & result.Address(False, False) & ")?") Then result.AutoFit Else result.Select
    End If
    Exit Sub
eh:
    ReportError "Find Columns Showing #### Errors"
End Sub

Public Sub XC_ScreenResolution()
    On Error Resume Next
    MsgBox "Excel application window: " & Application.Width & " x " & Application.Height & " points" & vbCrLf & _
           "Usable area: " & Application.UsableWidth & " x " & Application.UsableHeight & " points" & vbCrLf & _
           "Window state: " & IIf(Application.WindowState = xlMaximized, "maximized", IIf(Application.WindowState = xlMinimized, "minimized", "normal")) & vbCrLf & _
           "Active window zoom: " & ActiveWindow.Zoom & "%" & vbCrLf & _
           "Visible range: " & ActiveWindow.VisibleRange.Address(False, False) & vbCrLf & vbCrLf & _
           "(Pixel resolution needs a Windows API call; points x 96/72 approximates pixels at 100% scaling.)", vbInformation, "Screen"
End Sub

Public Sub XC_RegionalSettings()
    On Error Resume Next
    MsgBox "Decimal separator: " & Application.International(xlDecimalSeparator) & vbCrLf & _
           "Thousands separator: " & Application.International(xlThousandsSeparator) & vbCrLf & _
           "List (argument) separator: " & Application.International(xlListSeparator) & vbCrLf & _
           "Date order: " & Choose(Application.International(xlDateOrder) + 1, "Month-Day-Year", "Day-Month-Year", "Year-Month-Day") & vbCrLf & _
           "Date separator: " & Application.International(xlDateSeparator) & vbCrLf & _
           "Time separator: " & Application.International(xlTimeSeparator) & vbCrLf & _
           "Currency code: " & Application.International(xlCurrencyCode) & vbCrLf & _
           "24-hour clock: " & Application.International(xl24HourClock) & vbCrLf & _
           "Use system separators: " & Application.UseSystemSeparators & vbCrLf & _
           "Country code: " & Application.International(xlCountryCode), vbInformation, "Regional Settings Used by Excel"
End Sub

Public Sub XC_ListAddins()
    On Error GoTo eh
    Dim rpt As Worksheet, ai As AddIn, r As Long, co As Object
    Set rpt = NewReportSheet("Add-ins")
    rpt.Range("A1:D1").Value = Array("Add-in", "Type", "Installed / Connected", "Path")
    rpt.Range("A1:D1").Font.Bold = True
    r = 2
    For Each ai In Application.AddIns
        rpt.Cells(r, 1).Value = ai.Name: rpt.Cells(r, 2).Value = "Excel add-in"
        rpt.Cells(r, 3).Value = ai.Installed: rpt.Cells(r, 4).Value = ai.FullName
        r = r + 1
    Next ai
    On Error Resume Next
    For Each co In Application.COMAddIns
        rpt.Cells(r, 1).Value = co.Description: rpt.Cells(r, 2).Value = "COM add-in"
        rpt.Cells(r, 3).Value = co.Connect: rpt.Cells(r, 4).Value = co.progID
        r = r + 1
    Next co
    On Error GoTo eh
    rpt.Columns("A:D").AutoFit
    Exit Sub
eh:
    ReportError "List Installed Add-ins"
End Sub

Public Sub XC_ListFonts()
    On Error GoTo eh
    Dim rpt As Worksheet, ctl As Object, i As Long, r As Long
    Set ctl = Nothing
    On Error Resume Next
    Set ctl = Application.CommandBars("Formatting").FindControl(ID:=1728)
    On Error GoTo eh
    If ctl Is Nothing Then MsgBox "The font list is not accessible on this platform.", vbInformation, APP_NAME: Exit Sub
    SafeStart "Listing fonts"
    Set rpt = NewReportSheet("Fonts")
    rpt.Range("A1:B1").Value = Array("Font", "Sample")
    rpt.Range("A1:B1").Font.Bold = True
    r = 2
    For i = 1 To ctl.ListCount
        rpt.Cells(r, 1).Value = ctl.List(i)
        rpt.Cells(r, 2).Value = "The quick brown fox 0123456789"
        rpt.Cells(r, 2).Font.Name = ctl.List(i)
        r = r + 1
    Next i
    rpt.Columns("A:B").AutoFit
    SafeEnd
    Done Plural(r - 2, "font") & " listed."
    Exit Sub
eh:
    ReportError "List Available Fonts"
End Sub

Public Function VisibleText(ByVal v As Long) As String
    Select Case v
        Case xlSheetVisible: VisibleText = "Visible"
        Case xlSheetHidden: VisibleText = "Hidden"
        Case xlSheetVeryHidden: VisibleText = "Very hidden"
        Case Else: VisibleText = CStr(v)
    End Select
End Function
