Attribute VB_Name = "modSelect"
'==============================================================================
' SPDX-License-Identifier: MIT
' XcelCraft - modSelect
' Select category. Original implementation.
'==============================================================================
Option Explicit

'--- Advanced criteria-based cell selection -----------------------------------
Public Sub XC_SelectCellsByCriteria()
    On Error GoTo eh
    Dim rng As Range, cond As Long, crit As String, c As Range, result As Range, hit As Boolean, v As Variant, t As String, n As Long, cmpV As Double
    Set rng = SelRangeOrRegion()
    If rng Is Nothing Then Exit Sub
    cond = AskChoice("Select all cells in " & rng.Address(False, False) & " that:", Array( _
        "Equal a value", "Do not equal a value", "Contain text", "Do not contain text", "Start with text", "End with text", _
        "Are greater than a number", "Are less than a number", "Are between two numbers (enter as  low;high)", _
        "Are empty", "Are not empty", "Contain a formula", "Contain a number (constant)", "Contain text (constant)", _
        "Contain an error", "Contain a date", "Have a fill color", "Are bold", "Are merged", "Have a comment/note", "Have a hyperlink", "Are locked", "Are unlocked"))
    If cond = 0 Then Exit Sub
    If cond <= 9 Then
        crit = AskText("Value:", "", "Select Cells by Criteria")
        If StrPtr(crit) = 0 Then Exit Sub
    End If
    SafeStart "Selecting"
    For Each c In rng.Cells
        v = c.Value: t = CStr(c.Text): hit = False
        Select Case cond
            Case 1: hit = (StrComp(t, crit, vbTextCompare) = 0) Or (IsNumeric(crit) And IsNumeric(v) And Not IsEmpty(v) And VarType(v) <> vbString And CDbl(v) = Val(crit))
            Case 2: hit = Not ((StrComp(t, crit, vbTextCompare) = 0) Or (IsNumeric(crit) And IsNumeric(v) And Not IsEmpty(v) And VarType(v) <> vbString And CDbl(v) = Val(crit)))
            Case 3: hit = InStr(1, t, crit, vbTextCompare) > 0
            Case 4: hit = InStr(1, t, crit, vbTextCompare) = 0
            Case 5: hit = StrComp(Left$(t, Len(crit)), crit, vbTextCompare) = 0 And Len(t) > 0
            Case 6: hit = StrComp(Right$(t, Len(crit)), crit, vbTextCompare) = 0 And Len(t) > 0
            Case 7: If IsNumeric(v) And Not IsEmpty(v) And VarType(v) <> vbString And IsNumeric(crit) Then hit = CDbl(v) > Val(crit)
            Case 8: If IsNumeric(v) And Not IsEmpty(v) And VarType(v) <> vbString And IsNumeric(crit) Then hit = CDbl(v) < Val(crit)
            Case 9
                If IsNumeric(v) And Not IsEmpty(v) And VarType(v) <> vbString And InStr(crit, ";") > 0 Then
                    hit = CDbl(v) >= Val(Split(crit, ";")(0)) And CDbl(v) <= Val(Split(crit, ";")(1))
                End If
            Case 10: hit = IsEmpty(v)
            Case 11: hit = Not IsEmpty(v)
            Case 12: hit = c.HasFormula
            Case 13: hit = Not c.HasFormula And IsNumeric(v) And Not IsEmpty(v) And VarType(v) <> vbString And VarType(v) <> vbBoolean And VarType(v) <> vbDate
            Case 14: hit = Not c.HasFormula And VarType(v) = vbString
            Case 15: hit = IsError(v)
            Case 16: hit = (VarType(v) = vbDate)
            Case 17: hit = (c.Interior.ColorIndex <> xlColorIndexNone)
            Case 18: hit = (c.Font.Bold = True)
            Case 19: hit = c.MergeCells
            Case 20: hit = Not c.Comment Is Nothing
            Case 21: hit = c.Hyperlinks.Count > 0
            Case 22: hit = c.Locked
            Case 23: hit = Not c.Locked
        End Select
        If hit Then
            If result Is Nothing Then Set result = c Else Set result = Union(result, c)
            n = n + 1
        End If
    Next c
    SafeEnd
    If result Is Nothing Then
        MsgBox "No cells match.", vbInformation, APP_NAME
    Else
        result.Select
        Application.StatusBar = APP_NAME & ": " & Plural(n, "cell") & " selected."
    End If
    Exit Sub
eh:
    ReportError "Advanced Criteria-Based Cell Selection"
End Sub

'--- Move / extend / shrink selection ------------------------------------------
Public Sub XC_MoveExtendShrink()
    On Error GoTo eh
    Dim rng As Range, mode As Long, n As Variant, ws As Worksheet, r1 As Long, c1 As Long, r2 As Long, c2 As Long
    If TypeName(Selection) <> "Range" Then Exit Sub
    Set rng = Selection.Areas(1): Set ws = rng.Worksheet
    mode = AskChoice("Selection " & rng.Address(False, False) & ":", Array( _
        "Move up", "Move down", "Move left", "Move right", _
        "Extend up", "Extend down", "Extend left", "Extend right", _
        "Shrink from top", "Shrink from bottom", "Shrink from left", "Shrink from right"))
    If mode = 0 Then Exit Sub
    n = AskNumber("Number of rows/columns:", 1, "Move, Extend or Shrink Selection", 1)
    If IsEmpty(n) Then Exit Sub
    r1 = rng.Row: c1 = rng.Column: r2 = r1 + rng.Rows.Count - 1: c2 = c1 + rng.Columns.Count - 1
    Select Case mode
        Case 1: r1 = r1 - n: r2 = r2 - n
        Case 2: r1 = r1 + n: r2 = r2 + n
        Case 3: c1 = c1 - n: c2 = c2 - n
        Case 4: c1 = c1 + n: c2 = c2 + n
        Case 5: r1 = r1 - n
        Case 6: r2 = r2 + n
        Case 7: c1 = c1 - n
        Case 8: c2 = c2 + n
        Case 9: r1 = r1 + n
        Case 10: r2 = r2 - n
        Case 11: c1 = c1 + n
        Case 12: c2 = c2 - n
    End Select
    If r1 < 1 Or c1 < 1 Or r2 > ws.Rows.Count Or c2 > ws.Columns.Count Or r2 < r1 Or c2 < c1 Then
        MsgBox "That would move the selection outside the sheet or make it empty.", vbExclamation, APP_NAME
        Exit Sub
    End If
    ws.Range(ws.Cells(r1, c1), ws.Cells(r2, c2)).Select
    Exit Sub
eh:
    ReportError "Move, Extend or Shrink Selection"
End Sub

'--- Deselect / invert / merge -------------------------------------------------
Public Sub XC_DeselectCells()
    On Error GoTo eh
    Dim rng As Range, remove As Range, c As Range, result As Range
    If TypeName(Selection) <> "Range" Then Exit Sub
    Set rng = Selection
    Set remove = AskRange("Select the cells to REMOVE from the current selection:")
    If remove Is Nothing Then Exit Sub
    For Each c In rng.Cells
        If Intersect(c, remove) Is Nothing Then
            If result Is Nothing Then Set result = c Else Set result = Union(result, c)
        End If
    Next c
    If result Is Nothing Then MsgBox "Nothing would remain selected.", vbInformation, APP_NAME Else result.Select
    Exit Sub
eh:
    ReportError "Deselect Cells"
End Sub

Public Sub XC_InvertSelection()
    On Error GoTo eh
    Dim rng As Range, scope As Range, c As Range, result As Range, mode As Long
    If TypeName(Selection) <> "Range" Then Exit Sub
    Set rng = Selection
    mode = AskChoice("Invert the selection within:", Array("The used range of the sheet", "The bounding rectangle of the current selection"))
    If mode = 0 Then Exit Sub
    If mode = 1 Then Set scope = Union(ActiveSheet.UsedRange, BoundingBox(rng)) Else Set scope = BoundingBox(rng)
    If scope.Cells.CountLarge > 500000 Then MsgBox "The area is too large to invert cell by cell.", vbExclamation, APP_NAME: Exit Sub
    SafeStart "Inverting"
    For Each c In scope.Cells
        If Intersect(c, rng) Is Nothing Then
            If result Is Nothing Then Set result = c Else Set result = Union(result, c)
        End If
    Next c
    SafeEnd
    If result Is Nothing Then MsgBox "Nothing to select.", vbInformation, APP_NAME Else result.Select
    Exit Sub
eh:
    ReportError "Invert Range Selection"
End Sub

Public Sub XC_MergeContiguousSelections()
    On Error Resume Next
    If TypeName(Selection) <> "Range" Then Exit Sub
    If Selection.Areas.Count = 1 Then Exit Sub
    BoundingBox(Selection).Select
End Sub

'--- Adjacent matching / extend / jump -----------------------------------------
Public Sub XC_SelectMatchingBelow()
    On Error GoTo eh
    Dim c As Range, v As String, last As Range, ws As Worksheet
    If TypeName(Selection) <> "Range" Then Exit Sub
    Set c = ActiveCell: Set ws = c.Worksheet: v = c.Text
    Set last = c
    Do While last.Row < ws.Rows.Count
        If last.Offset(1, 0).Text <> v Then Exit Do
        Set last = last.Offset(1, 0)
    Loop
    ws.Range(c, last).Select
    Exit Sub
eh:
    ReportError "Select Adjacent Matching Cells Below"
End Sub

Public Sub XC_SelectMatchingInColumn()
    On Error GoTo eh
    Dim c As Range, v As String, first As Range, last As Range, ws As Worksheet
    If TypeName(Selection) <> "Range" Then Exit Sub
    Set c = ActiveCell: Set ws = c.Worksheet: v = c.Text
    Set first = c: Set last = c
    Do While first.Row > 1
        If first.Offset(-1, 0).Text <> v Then Exit Do
        Set first = first.Offset(-1, 0)
    Loop
    Do While last.Row < ws.Rows.Count
        If last.Offset(1, 0).Text <> v Then Exit Do
        Set last = last.Offset(1, 0)
    Loop
    ws.Range(first, last).Select
    Exit Sub
eh:
    ReportError "Select Adjacent Matching Cells in the Column"
End Sub

Public Sub XC_ExtendToLowestUsedRow()
    On Error GoTo eh
    Dim rng As Range, last As Range, ws As Worksheet
    If TypeName(Selection) <> "Range" Then Exit Sub
    Set rng = Selection.Areas(1): Set ws = rng.Worksheet
    Set last = modSheets.RealLastCell(ws)
    If last.Row > rng.Row Then ws.Range(rng.Cells(1, 1), ws.Cells(last.Row, rng.Column + rng.Columns.Count - 1)).Select
    Exit Sub
eh:
    ReportError "Extend Selection to the Lowest Used Row"
End Sub

Public Sub XC_ExtendToRightmostUsedColumn()
    On Error GoTo eh
    Dim rng As Range, last As Range, ws As Worksheet
    If TypeName(Selection) <> "Range" Then Exit Sub
    Set rng = Selection.Areas(1): Set ws = rng.Worksheet
    Set last = modSheets.RealLastCell(ws)
    If last.Column > rng.Column Then ws.Range(rng.Cells(1, 1), ws.Cells(rng.Row + rng.Rows.Count - 1, last.Column)).Select
    Exit Sub
eh:
    ReportError "Extend Selection to the Rightmost Used Column"
End Sub

Public Sub XC_JumpToFirstDifferent()
    On Error GoTo eh
    Dim rng As Range, c As Range, v As String, first As Boolean
    Set rng = SelRange(True)
    If rng Is Nothing Then Exit Sub
    first = True
    For Each c In rng.Cells
        If first Then
            v = c.Text: first = False
        ElseIf c.Text <> v Then
            c.Select
            Exit Sub
        End If
    Next c
    MsgBox "All selected cells contain the same value.", vbInformation, APP_NAME
    Exit Sub
eh:
    ReportError "Jump to the First Different Value"
End Sub

Private Sub SelectExtremeCells(ByVal wantMin As Boolean)
    On Error GoTo eh
    Dim rng As Range, c As Range, best As Variant, result As Range, v As Variant
    Set rng = SelRangeOrRegion()
    If rng Is Nothing Then Exit Sub
    For Each c In rng.Cells
        v = c.Value
        If IsNumeric(v) And Not IsEmpty(v) And VarType(v) <> vbString And VarType(v) <> vbBoolean Then
            If IsEmpty(best) Then
                best = v
            ElseIf (wantMin And v < best) Or (Not wantMin And v > best) Then
                best = v
            End If
        End If
    Next c
    If IsEmpty(best) Then MsgBox "No numeric values found.", vbInformation, APP_NAME: Exit Sub
    For Each c In rng.Cells
        v = c.Value
        If IsNumeric(v) And Not IsEmpty(v) And VarType(v) <> vbString And VarType(v) <> vbBoolean Then
            If v = best Then
                If result Is Nothing Then Set result = c Else Set result = Union(result, c)
            End If
        End If
    Next c
    result.Select
    Application.StatusBar = APP_NAME & ": " & Plural(result.Cells.Count, "cell") & " with the " & IIf(wantMin, "lowest", "highest") & " value (" & best & ") selected."
    Exit Sub
eh:
    ReportError IIf(wantMin, "Select Cells Containing the Lowest Value", "Select Cells Containing the Highest Value")
End Sub

Public Sub XC_SelectLowestValue(): SelectExtremeCells True: End Sub
Public Sub XC_SelectHighestValue(): SelectExtremeCells False: End Sub

Public Sub XC_SelectFormulaErrors()
    On Error GoTo eh
    Dim rng As Range, r As Range
    Set rng = SelRangeOrRegion()
    If rng Is Nothing Then Set rng = ActiveSheet.UsedRange
    On Error Resume Next
    Set r = rng.SpecialCells(xlCellTypeFormulas, xlErrors)
    On Error GoTo eh
    If r Is Nothing Then MsgBox "No formulas returning errors found.", vbInformation, APP_NAME Else r.Select
    Exit Sub
eh:
    ReportError "Select All Cells Where Formulas Return an Error"
End Sub

'--- Sheets / objects / printing ----------------------------------------------------
Public Sub XC_SelectAllSheets()
    On Error Resume Next
    ActiveWorkbook.Sheets.Select
End Sub

Public Sub XC_SelectAllObjects()
    On Error GoTo eh
    If ActiveSheet.Shapes.Count = 0 Then MsgBox "The active sheet has no objects.", vbInformation, APP_NAME: Exit Sub
    ActiveSheet.Shapes.SelectAll
    Exit Sub
eh:
    ReportError "Select All Objects"
End Sub

Public Sub XC_PrintPreviewSelection()
    On Error GoTo eh
    If TypeName(Selection) <> "Range" Then Exit Sub
    Selection.PrintPreview
    Exit Sub
eh:
    ReportError "Print Preview Selection"
End Sub

Public Sub XC_PrintSelection()
    On Error GoTo eh
    If TypeName(Selection) <> "Range" Then Exit Sub
    If AskYesNo("Print the selection " & Selection.Address(False, False) & " now?") Then Selection.PrintOut
    Exit Sub
eh:
    ReportError "Print Selection"
End Sub

Public Sub XC_ApplySelectionToAllSheets()
    On Error GoTo eh
    Dim addr As String, ws As Worksheet, cur As Worksheet
    If TypeName(Selection) <> "Range" Then Exit Sub
    addr = Selection.Address
    Set cur = ActiveSheet
    SafeStart
    For Each ws In ActiveWorkbook.Worksheets
        If ws.Visible = xlSheetVisible Then
            ws.Activate
            ws.Range(addr).Select
        End If
    Next ws
    cur.Activate
    SafeEnd
    Done "Selection " & addr & " applied on every visible worksheet."
    Exit Sub
eh:
    ReportError "Apply Current Range Selection to All Worksheets"
End Sub
