Attribute VB_Name = "modFill"
'==============================================================================
' SPDX-License-Identifier: MIT
' XcelCraft - modFill
' Fill category. Original implementation.
'==============================================================================
Option Explicit

'--- Fill blanks / overwrite ------------------------------------------------
Public Sub XC_FillBlanks()
    On Error GoTo eh
    Dim rng As Range, c As Range, v As String, n As Long, asFormula As Boolean
    Set rng = SelRange()
    If rng Is Nothing Then Exit Sub
    v = AskText("Value (or formula starting with =) to put in every EMPTY cell of the selection:", "0", "Fill Blank Cells")
    If Len(v) = 0 Then Exit Sub
    asFormula = (Left$(v, 1) = "=")
    SnapshotRange rng, "Fill Blank Cells"
    SafeStart "Filling blanks"
    For Each c In rng.Cells
        If IsEmpty(c.Value) Then
            If asFormula Then c.Formula = v Else c.Value = v
            n = n + 1
        End If
    Next c
    SafeEnd
    Done "Fill Blank Cells: " & Plural(n, "cell") & " filled."
    Exit Sub
eh:
    ReportError "Fill Blank Cells"
End Sub

Public Sub XC_OverwriteFilled()
    On Error GoTo eh
    Dim rng As Range, c As Range, v As String, n As Long, asFormula As Boolean
    Set rng = SelRange()
    If rng Is Nothing Then Exit Sub
    v = AskText("Value (or formula) to put in every NON-EMPTY cell of the selection:", "", "Overwrite Filled Cells")
    If Len(v) = 0 Then Exit Sub
    If Not AskYesNo("This replaces the contents of every filled cell in the selection. Continue?", False) Then Exit Sub
    asFormula = (Left$(v, 1) = "=")
    SnapshotRange rng, "Overwrite Filled Cells"
    SafeStart "Overwriting"
    For Each c In rng.Cells
        If Not IsEmpty(c.Value) Then
            If asFormula Then c.Formula = v Else c.Value = v
            n = n + 1
        End If
    Next c
    SafeEnd
    Done "Overwrite Filled Cells: " & Plural(n, "cell") & " overwritten."
    Exit Sub
eh:
    ReportError "Overwrite Filled Cells"
End Sub

Public Sub XC_FillBlanksFromAbove()
    On Error GoTo eh
    Dim rng As Range, a As Range, arr As Variant, r As Long, c As Long, n As Long, last As Variant
    Set rng = SelRange()
    If rng Is Nothing Then Exit Sub
    SnapshotRange rng, "Fill Blanks from Above"
    SafeStart "Filling blanks from above"
    For Each a In rng.Areas
        arr = RangeToArray(a, True)
        For c = 1 To UBound(arr, 2)
            last = Empty
            For r = 1 To UBound(arr, 1)
                If IsEmpty(arr(r, c)) Or (VarType(arr(r, c)) = vbString And Len(arr(r, c)) = 0) Then
                    If Not IsEmpty(last) Then
                        arr(r, c) = last: n = n + 1
                    End If
                Else
                    last = arr(r, c)
                End If
            Next r
        Next c
        a.Formula = arr
    Next a
    SafeEnd
    Done "Fill Blank Cells with Value from Above: " & Plural(n, "cell") & " filled."
    Exit Sub
eh:
    ReportError "Fill Blank Cells with Value from Above"
End Sub

'--- Leading zeros ----------------------------------------------------------
Public Sub XC_AddLeadingZeros()
    On Error GoTo eh
    Dim rng As Range, c As Range, ln As Variant, n As Long, s As String, mode As Long
    Set rng = SelRange()
    If rng Is Nothing Then Exit Sub
    ln = AskNumber("Total length each value should have (leading zeros are added until this length is reached):", 6, "Add Leading Zeros", 1, 255)
    If IsEmpty(ln) Then Exit Sub
    mode = AskChoice("How should the result be stored?", Array("As text (e.g. '000123 - safest, keeps the zeros)", "As a number with a custom number format (value stays numeric)"))
    If mode = 0 Then Exit Sub
    SnapshotRange rng, "Add Leading Zeros", True
    SafeStart "Adding leading zeros"
    For Each c In rng.Cells
        If Not c.HasFormula And Not IsEmpty(c.Value) Then
            If mode = 2 Then
                If IsNumeric(c.Value) Then c.NumberFormat = String$(CLng(ln), "0"): n = n + 1
            Else
                s = CStr(c.Value)
                If VarType(c.Value) <> vbString Then s = c.Text
                If Len(s) < ln Then
                    If Left$(s, 1) = "-" Then
                        s = "-" & String$(CLng(ln) - Len(s), "0") & Mid$(s, 2)
                    Else
                        s = String$(CLng(ln) - Len(s), "0") & s
                    End If
                End If
                c.NumberFormat = "@"
                c.Value = s
                n = n + 1
            End If
        End If
    Next c
    SafeEnd
    Done "Add Leading Zeros: " & Plural(n, "cell") & " changed."
    Exit Sub
eh:
    ReportError "Add Leading Zeros"
End Sub

'--- Trend series -----------------------------------------------------------
Private Sub FillTrend(ByVal byRows As Boolean)
    On Error GoTo eh
    Dim rng As Range, a As Range, nm As String
    nm = IIf(byRows, "Fill Horizontal with Linear Trend", "Fill Vertical with Linear Trend")
    Set rng = SelRange(True)
    If rng Is Nothing Then Exit Sub
    SnapshotRange rng, nm
    SafeStart nm
    For Each a In rng.Areas
        a.DataSeries Rowcol:=IIf(byRows, xlRows, xlColumns), Type:=xlLinear, Trend:=True
    Next a
    SafeEnd
    Done nm & ": done. The first cells of each row/column are used as the basis for the trend."
    Exit Sub
eh:
    ReportError nm
End Sub

Public Sub XC_FillTrendVertical(): FillTrend False: End Sub
Public Sub XC_FillTrendHorizontal(): FillTrend True: End Sub

'--- Auto numbering ---------------------------------------------------------
Public Sub XC_AutoNumber()
    On Error GoTo eh
    Dim rng As Range, c As Range, startV As Variant, stepV As Variant, pre As String, suf As String
    Dim order As Long, n As Long, i As Double, a As Range, r As Long, col As Long, digits As Variant, s As String, onlyBlank As Boolean
    Set rng = SelRange()
    If rng Is Nothing Then Exit Sub
    startV = AskNumber("Start at:", 1, "Auto Numbering")
    If IsEmpty(startV) Then Exit Sub
    stepV = AskNumber("Step (increment):", 1, "Auto Numbering")
    If IsEmpty(stepV) Then Exit Sub
    pre = AskText("Prefix text (optional, e.g. 'ID-'):", "", "Auto Numbering")
    suf = AskText("Suffix text (optional):", "", "Auto Numbering")
    digits = AskNumber("Minimum number of digits (pads with leading zeros, 0 = none):", 0, "Auto Numbering", 0, 20)
    If IsEmpty(digits) Then Exit Sub
    order = AskChoice("Numbering order:", Array("Down then across (column by column)", "Across then down (row by row)"))
    If order = 0 Then Exit Sub
    onlyBlank = AskYesNo("Only number EMPTY cells (skip cells that already contain something)?", False)
    SnapshotRange rng, "Auto Numbering"
    SafeStart "Numbering"
    i = startV
    For Each a In rng.Areas
        If order = 1 Then
            For col = 1 To a.Columns.Count
                For r = 1 To a.Rows.Count
                    Set c = a.Cells(r, col)
                    If Not (onlyBlank And Not IsEmpty(c.Value)) Then
                        PutNumber c, i, pre, suf, CLng(digits): i = i + stepV: n = n + 1
                    End If
                Next r
            Next col
        Else
            For r = 1 To a.Rows.Count
                For col = 1 To a.Columns.Count
                    Set c = a.Cells(r, col)
                    If Not (onlyBlank And Not IsEmpty(c.Value)) Then
                        PutNumber c, i, pre, suf, CLng(digits): i = i + stepV: n = n + 1
                    End If
                Next col
            Next r
        End If
    Next a
    SafeEnd
    Done "Auto Numbering: " & Plural(n, "cell") & " numbered."
    Exit Sub
eh:
    ReportError "Auto Numbering"
End Sub

Private Sub PutNumber(ByVal c As Range, ByVal i As Double, ByVal pre As String, ByVal suf As String, ByVal digits As Long)
    Dim s As String
    If digits > 0 Then s = Format$(i, String$(digits, "0")) Else s = CStr(i)
    If Len(pre) = 0 And Len(suf) = 0 And digits = 0 Then
        c.Value = i
    Else
        WriteText c, pre & s & suf
    End If
End Sub

'--- Unique random numbers --------------------------------------------------
Public Sub XC_UniqueRandom()
    On Error GoTo eh
    Dim rng As Range, lo As Variant, hi As Variant, cnt As Long, i As Long, j As Long, pool() As Long, t As Long, c As Range, k As Long
    Set rng = SelRange()
    If rng Is Nothing Then Exit Sub
    cnt = rng.Cells.CountLarge
    lo = AskNumber("Lowest number:", 1, "Insert Unique Random Numbers")
    If IsEmpty(lo) Then Exit Sub
    hi = AskNumber("Highest number:", Max2(cnt, 100), "Insert Unique Random Numbers")
    If IsEmpty(hi) Then Exit Sub
    If hi - lo + 1 < cnt Then
        MsgBox "The range " & lo & " to " & hi & " contains only " & (hi - lo + 1) & " numbers, but " & cnt & " cells are selected." & vbCrLf & _
               "Widen the range or select fewer cells.", vbExclamation, APP_NAME
        Exit Sub
    End If
    If hi - lo + 1 > 5000000 Then
        MsgBox "Please use a range of at most 5,000,000 numbers.", vbExclamation, APP_NAME
        Exit Sub
    End If
    SnapshotRange rng, "Unique Random Numbers"
    SafeStart "Generating unique random numbers"
    ReDim pool(0 To CLng(hi - lo))
    For i = 0 To UBound(pool): pool(i) = CLng(lo) + i: Next i
    Randomize
    ' partial Fisher-Yates shuffle: only the first cnt positions are needed
    For i = 0 To cnt - 1
        j = i + Int(Rnd() * (UBound(pool) - i + 1))
        t = pool(i): pool(i) = pool(j): pool(j) = t
    Next i
    k = 0
    For Each c In rng.Cells
        c.Value = pool(k): k = k + 1
    Next c
    SafeEnd
    Done "Insert Unique Random Numbers: " & Plural(cnt, "number") & " inserted."
    Exit Sub
eh:
    ReportError "Insert Unique Random Numbers"
End Sub

'--- Date / time inserts ----------------------------------------------------
Public Sub XC_InsertNowSeconds()
    On Error GoTo eh
    Dim rng As Range
    Set rng = SelRange()
    If rng Is Nothing Then Exit Sub
    SnapshotRange rng, "Insert Date and Time", True
    rng.NumberFormat = "yyyy-mm-dd hh:mm:ss"
    rng.Value = Now
    Exit Sub
eh:
    ReportError "Insert Current Date and Time"
End Sub

Public Sub XC_InsertTimeSeconds()
    On Error GoTo eh
    Dim rng As Range
    Set rng = SelRange()
    If rng Is Nothing Then Exit Sub
    SnapshotRange rng, "Insert Time", True
    rng.NumberFormat = "hh:mm:ss"
    rng.Value = Time
    Exit Sub
eh:
    ReportError "Insert Current Time"
End Sub

' Without a UserForm calendar we offer a quick list plus free typing.
Public Sub XC_InsertDate()
    On Error GoTo eh
    Dim rng As Range, s As String, d As Date, fmt As String, c As Long
    Set rng = SelRange()
    If rng Is Nothing Then Exit Sub
    c = AskChoice("Which date do you want to insert?", Array("Today", "Tomorrow", "Yesterday", "First day of this month", "Last day of this month", "First day of next month", "Last day of last month", "Type a date..."))
    If c = 0 Then Exit Sub
    Select Case c
        Case 1: d = Date
        Case 2: d = Date + 1
        Case 3: d = Date - 1
        Case 4: d = DateSerial(Year(Date), Month(Date), 1)
        Case 5: d = DateSerial(Year(Date), Month(Date) + 1, 0)
        Case 6: d = DateSerial(Year(Date), Month(Date) + 1, 1)
        Case 7: d = DateSerial(Year(Date), Month(Date), 0)
        Case 8
            s = AskText("Enter the date (e.g. " & Format$(Date, "yyyy-mm-dd") & " or " & Format$(Date, "Short Date") & "):", Format$(Date, "yyyy-mm-dd"), "Insert Date")
            If Len(s) = 0 Then Exit Sub
            If Not IsDate(s) Then MsgBox "'" & s & "' is not a valid date.", vbExclamation, APP_NAME: Exit Sub
            d = CDate(s)
    End Select
    fmt = AskText("Date format (leave empty to keep the current cell format):", GetSetting(REG_APP, "Fill", "DateFormat", "yyyy-mm-dd"), "Insert Date")
    If Len(fmt) > 0 Then SaveSetting REG_APP, "Fill", "DateFormat", fmt
    SnapshotRange rng, "Insert Date", True
    If Len(fmt) > 0 Then rng.NumberFormat = fmt
    rng.Value = d
    Exit Sub
eh:
    ReportError "Insert Date"
End Sub

'--- File path in header/footer/cell ---------------------------------------
Public Sub XC_InsertFilePath()
    On Error GoTo eh
    Dim where As Long, what As Long, ws As Worksheet, txt As String, code As String, sel As Object
    where = AskChoice("Where do you want to insert the workbook's path and name?", Array( _
        "Active cell (as text)", "Active cell (as a formula that updates: =CELL(""filename""))", _
        "Left footer", "Center footer", "Right footer", "Left header", "Center header", "Right header"))
    If where = 0 Then Exit Sub
    what = AskChoice("What to insert?", Array("Full path and file name", "File name only", "Folder path only", "Path, file name and sheet name"))
    If what = 0 Then Exit Sub
    Select Case what
        Case 1: txt = ActiveWorkbook.FullName:  code = "&Z&F"
        Case 2: txt = ActiveWorkbook.Name:      code = "&F"
        Case 3: txt = ActiveWorkbook.Path:      code = "&Z"
        Case 4: txt = ActiveWorkbook.FullName & " [" & ActiveSheet.Name & "]": code = "&Z&F [&A]"
    End Select
    If where = 1 Then
        If TypeName(Selection) <> "Range" Then Exit Sub
        ActiveCell.Value = txt
    ElseIf where = 2 Then
        If TypeName(Selection) <> "Range" Then Exit Sub
        Select Case what
            Case 1: ActiveCell.Formula = "=LEFT(CELL(""filename"",A1),FIND(""]"",CELL(""filename"",A1))-1)"
            Case 2: ActiveCell.Formula = "=MID(CELL(""filename"",A1),FIND(""["",CELL(""filename"",A1))+1,FIND(""]"",CELL(""filename"",A1))-FIND(""["",CELL(""filename"",A1))-1)"
            Case 3: ActiveCell.Formula = "=LEFT(CELL(""filename"",A1),FIND(""["",CELL(""filename"",A1))-1)"
            Case 4: ActiveCell.Formula = "=CELL(""filename"",A1)"
        End Select
        ActiveCell.Formula = Replace(ActiveCell.Formula, "A1", ActiveCell.Address(False, False))
    Else
        For Each ws In ActiveWindow.SelectedSheets
            With ws.PageSetup
                Select Case where
                    Case 3: .LeftFooter = code
                    Case 4: .CenterFooter = code
                    Case 5: .RightFooter = code
                    Case 6: .LeftHeader = code
                    Case 7: .CenterHeader = code
                    Case 8: .RightHeader = code
                End Select
            End With
        Next ws
        Done "Inserted in the header/footer of " & Plural(ActiveWindow.SelectedSheets.Count, "sheet") & "."
    End If
    Exit Sub
eh:
    ReportError "Insert File Path and Name"
End Sub

'--- List files in folder ---------------------------------------------------
Public Sub XC_ListFilesInFolder()
    On Error GoTo eh
    Dim folder As String, pattern As String, ws As Worksheet, f As String, r As Long, includeSub As Boolean
    folder = PickFolder()
    If Len(folder) = 0 Then Exit Sub
    pattern = AskText("File name filter (e.g. *.xlsx, *.pdf, * for all):", "*", "List File Names")
    If Len(pattern) = 0 Then Exit Sub
    includeSub = AskYesNo("Include files in subfolders?", False)
    SafeStart "Listing files"
    Set ws = NewReportSheet("Files")
    ws.Range("A1:F1").Value = Array("File name", "Folder", "Full path", "Size (bytes)", "Modified", "Extension")
    ws.Range("A1:F1").Font.Bold = True
    r = 2
    ListFolder folder, pattern, ws, r, includeSub
    ws.Columns("A:F").AutoFit
    SafeEnd
    Done "List File Names: " & Plural(r - 2, "file") & " listed."
    Exit Sub
eh:
    ReportError "List File Names and Properties"
End Sub

Private Sub ListFolder(ByVal folder As String, ByVal pattern As String, ByVal ws As Worksheet, ByRef r As Long, ByVal includeSub As Boolean)
    Dim f As String, subs As Collection, s As Variant, sep As String
    sep = Application.PathSeparator
    If Right$(folder, 1) <> sep Then folder = folder & sep
    f = Dir(folder & pattern)
    Do While Len(f) > 0
        If (GetAttr(folder & f) And vbDirectory) = 0 Then
            ws.Cells(r, 1).Value = f
            ws.Cells(r, 2).Value = folder
            ws.Cells(r, 3).Value = folder & f
            ws.Cells(r, 4).Value = FileLen(folder & f)
            ws.Cells(r, 5).Value = FileDateTime(folder & f)
            ws.Cells(r, 6).Value = LCase$(Mid$(f, InStrRev(f, ".") + 1))
            r = r + 1
        End If
        f = Dir
    Loop
    If includeSub Then
        Set subs = New Collection
        f = Dir(folder, vbDirectory)
        Do While Len(f) > 0
            If f <> "." And f <> ".." Then
                If (GetAttr(folder & f) And vbDirectory) = vbDirectory Then subs.Add folder & f
            End If
            f = Dir
        Loop
        For Each s In subs
            ListFolder CStr(s), pattern, ws, r, True
        Next s
    End If
End Sub

Public Function PickFolder() As String
    #If Mac Then
        Dim p As String
        On Error Resume Next
        p = MacScript("return POSIX path of (choose folder with prompt ""Select a folder"")")
        On Error GoTo 0
        If Len(p) = 0 Then p = AskText("Enter the folder path:", ActiveWorkbook.Path, "Select Folder")
        PickFolder = p
    #Else
        With Application.FileDialog(4) ' msoFileDialogFolderPicker
            .Title = "Select a folder"
            .AllowMultiSelect = False
            If .Show = -1 Then PickFolder = .SelectedItems(1)
        End With
    #End If
End Function

'--- Sheet names into cells -------------------------------------------------
Public Sub XC_InsertSheetNames()
    On Error GoTo eh
    Dim ws As Worksheet, addr As String, n As Long, asFormula As Boolean
    If TypeName(Selection) <> "Range" Then Exit Sub
    addr = ActiveCell.Address(False, False)
    If Not AskYesNo("Insert each sheet's name into cell " & addr & " of every selected sheet (" & ActiveWindow.SelectedSheets.Count & " selected)?") Then Exit Sub
    asFormula = AskYesNo("Insert as a formula that updates when the sheet is renamed?" & vbCrLf & "(No = plain text)", False)
    SafeStart "Inserting sheet names"
    For Each ws In ActiveWindow.SelectedSheets
        If asFormula Then
            ws.Range(addr).Formula = "=MID(CELL(""filename""," & addr & "),FIND(""]"",CELL(""filename""," & addr & "))+1,255)"
        Else
            ws.Range(addr).Value = ws.Name
        End If
        n = n + 1
    Next ws
    SafeEnd
    Done "Insert Sheet Names: " & Plural(n, "sheet") & " updated."
    Exit Sub
eh:
    ReportError "Insert Sheet Names"
End Sub
