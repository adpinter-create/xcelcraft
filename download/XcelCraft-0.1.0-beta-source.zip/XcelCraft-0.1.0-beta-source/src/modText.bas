Attribute VB_Name = "modText"
'==============================================================================
' SPDX-License-Identifier: MIT
' XcelCraft - modText
' Text category (27 menu entries). Original implementation.
'==============================================================================
Option Explicit

'------------------------------------------------------------------------------
' Generic runner: apply a TransformText mode to the selection
'------------------------------------------------------------------------------
Private Sub RunTextTool(ByVal toolName As String, ByVal mode As String, _
                        Optional ByVal p1 As Variant, Optional ByVal p2 As Variant, _
                        Optional ByVal p3 As Variant, Optional ByVal includeNumbers As Boolean = False)
    On Error GoTo eh
    Dim rng As Range, n As Long
    Set rng = SelRange()
    If rng Is Nothing Then Exit Sub
    SnapshotRange rng, toolName
    SafeStart toolName
    n = ForEachTextCell(rng, mode, p1, p2, p3, includeNumbers)
    SafeEnd
    Done toolName & ": " & Plural(n, "cell") & " changed."
    Exit Sub
eh:
    ReportError toolName
End Sub

'------------------------------------------------------------------------------
' The transform dispatcher (also used by modCore.ForEachTextCell)
'------------------------------------------------------------------------------
Public Function TransformText(ByVal s As String, ByVal mode As String, _
                              Optional ByVal p1 As Variant, Optional ByVal p2 As Variant, _
                              Optional ByVal p3 As Variant) As String
    Select Case mode
        Case "upper":        TransformText = UCase$(s)
        Case "lower":        TransformText = LCase$(s)
        Case "capfirst":     TransformText = CapFirstLetter(s, False)
        Case "sentence":     TransformText = CapFirstLetter(s, True)
        Case "sentences":    TransformText = SentenceCase(s)
        Case "title":        TransformText = TitleCase(s, CStr(IIf(IsMissing(p1), "", p1)))
        Case "toggle":       TransformText = ToggleCase(s)
        Case "trim":         TransformText = TrimSpaces(s)
        Case "trimall":      TransformText = TrimAllSpaces(s)
        Case "trimlb":       TransformText = TrimLineBreaks(s, True, True)
        Case "rmtrailinglb": TransformText = TrimLineBreaks(s, False, True)
        Case "addtext":      TransformText = CStr(p1) & s & CStr(p2)
        Case "rmchars":      TransformText = RemoveChars(s, CStr(p1), CStr(p2))
        Case "accents":      TransformText = RemoveAccents(s)
        Case "rmletters":    TransformText = KeepOrRemoveClass(s, "letters", True)
        Case "rmnumbers":    TransformText = KeepOrRemoveClass(s, "digits", True)
        Case "rmfirst":      TransformText = Mid$(s, CLng(p1) + 1)
        Case "rmlast":       If Len(s) > CLng(p1) Then TransformText = Left$(s, Len(s) - CLng(p1)) Else TransformText = ""
        Case "keepfirst":    TransformText = Left$(s, CLng(p1))
        Case "reverse":      TransformText = StrReverse(s)
        Case "sortinside":   TransformText = SortInsideCell(s, CStr(p1), CBool(p2), CBool(p3))
        Case "rmhtml":       TransformText = StripHtml(s)
        Case "clean":        TransformText = CleanNonPrinting(s)
        Case Else:           TransformText = s
    End Select
End Function

'------------------------------------------------------------------------------
' Transform primitives
'------------------------------------------------------------------------------
Public Function CapFirstLetter(ByVal s As String, ByVal lowerRest As Boolean) As String
    Dim i As Long
    If lowerRest Then s = LCase$(s)
    ' find first letter
    For i = 1 To Len(s)
        If IsLetter(Mid$(s, i, 1)) Then
            CapFirstLetter = Left$(s, i - 1) & UCase$(Mid$(s, i, 1)) & Mid$(s, i + 1)
            Exit Function
        End If
    Next i
    CapFirstLetter = s
End Function

' Capitalizes the first letter after every sentence terminator (. ! ? and line breaks).
Public Function SentenceCase(ByVal s As String) As String
    Dim i As Long, ch As String, capNext As Boolean, out As String
    s = LCase$(s)
    capNext = True
    For i = 1 To Len(s)
        ch = Mid$(s, i, 1)
        If capNext And IsLetter(ch) Then
            ch = UCase$(ch)
            capNext = False
        ElseIf ch = "." Or ch = "!" Or ch = "?" Or ch = vbLf Or ch = vbCr Then
            capNext = True
        End If
        out = out & ch
    Next i
    ' lone "i" as a word
    out = " " & out & " "
    out = Replace(out, " i ", " I ")
    out = Replace(out, " i'", " I'")
    SentenceCase = Mid$(out, 2, Len(out) - 2)
End Function

' Title case. exceptions: space-separated lowercase words kept lowercase
' unless they are the first word.
Public Function TitleCase(ByVal s As String, Optional ByVal exceptions As String = "") As String
    Dim words() As String, i As Long, w As String, exc As String, j As Long, out As String
    Dim parts() As String
    exc = " " & LCase$(Trim$(exceptions)) & " "
    words = Split(s, " ")
    For i = LBound(words) To UBound(words)
        w = LCase$(words(i))
        If Len(w) > 0 Then
            If i > LBound(words) And InStr(exc, " " & w & " ") > 0 Then
                ' keep lowercase
            Else
                ' capitalise first letter and after hyphens; not after apostrophes
                parts = Split(w, "-")
                For j = LBound(parts) To UBound(parts)
                    parts(j) = CapFirstLetter(parts(j), False)
                Next j
                w = Join(parts, "-")
            End If
        End If
        words(i) = w
    Next i
    out = Join(words, " ")
    TitleCase = out
End Function

Public Function ToggleCase(ByVal s As String) As String
    Dim i As Long, ch As String, out As String
    For i = 1 To Len(s)
        ch = Mid$(s, i, 1)
        If ch = UCase$(ch) And ch <> LCase$(ch) Then
            ch = LCase$(ch)
        ElseIf ch = LCase$(ch) And ch <> UCase$(ch) Then
            ch = UCase$(ch)
        End If
        out = out & ch
    Next i
    ToggleCase = out
End Function

Public Function IsLetter(ByVal ch As String) As Boolean
    If Len(ch) = 0 Then Exit Function
    IsLetter = (UCase$(ch) <> LCase$(ch))
End Function

Public Function IsDigitChar(ByVal ch As String) As Boolean
    If Len(ch) <> 1 Then Exit Function
    IsDigitChar = (ch >= "0" And ch <= "9")
End Function

' Trim normal spaces and non-breaking spaces at both ends.
Public Function TrimSpaces(ByVal s As String) As String
    Dim nb As String
    nb = ChrW(160)
    Do While Len(s) > 0 And (Left$(s, 1) = " " Or Left$(s, 1) = nb Or Left$(s, 1) = vbTab)
        s = Mid$(s, 2)
    Loop
    Do While Len(s) > 0 And (Right$(s, 1) = " " Or Right$(s, 1) = nb Or Right$(s, 1) = vbTab)
        s = Left$(s, Len(s) - 1)
    Loop
    TrimSpaces = s
End Function

' Like Excel TRIM but also handles non-breaking spaces and tabs.
Public Function TrimAllSpaces(ByVal s As String) As String
    s = Replace(s, ChrW(160), " ")
    s = Replace(s, vbTab, " ")
    Do While InStr(s, "  ") > 0
        s = Replace(s, "  ", " ")
    Loop
    ' do not collapse spaces across line breaks but trim around them
    s = Replace(s, " " & vbLf, vbLf)
    s = Replace(s, vbLf & " ", vbLf)
    TrimAllSpaces = Trim$(s)
End Function

Public Function TrimLineBreaks(ByVal s As String, ByVal leading As Boolean, ByVal trailing As Boolean) As String
    If leading Then
        Do While Len(s) > 0 And (Left$(s, 1) = vbLf Or Left$(s, 1) = vbCr)
            s = Mid$(s, 2)
        Loop
    End If
    If trailing Then
        Do While Len(s) > 0 And (Right$(s, 1) = vbLf Or Right$(s, 1) = vbCr)
            s = Left$(s, Len(s) - 1)
        Loop
    End If
    TrimLineBreaks = s
End Function

Public Function RemoveChars(ByVal s As String, ByVal chars As String, ByVal replacement As String) As String
    Dim i As Long
    For i = 1 To Len(chars)
        s = Replace(s, Mid$(chars, i, 1), replacement)
    Next i
    RemoveChars = s
End Function

Public Function KeepOrRemoveClass(ByVal s As String, ByVal cls As String, ByVal removeIt As Boolean) As String
    Dim i As Long, ch As String, hit As Boolean, out As String
    For i = 1 To Len(s)
        ch = Mid$(s, i, 1)
        Select Case cls
            Case "letters": hit = (UCase$(ch) <> LCase$(ch)) Or (ch >= "A" And ch <= "Z") Or (ch >= "a" And ch <= "z")
            Case "digits":  hit = IsDigitChar(ch)
            Case Else:      hit = False
        End Select
        If hit <> removeIt Then out = out & ch
    Next i
    KeepOrRemoveClass = out
End Function

Public Function RemoveAccents(ByVal s As String) As String
    Static src As Variant, dst As String, ready As Boolean
    Dim i As Long, codes As String
    If Not ready Then
        codes = "192,193,194,195,196,197,256,258,260,224,225,226,227,228,229,257,259,261,200,201," & _
                "202,203,274,278,280,282,232,233,234,235,275,279,281,283,204,205,206,207,298,302," & _
                "304,236,237,238,239,299,303,305,210,211,212,213,214,216,332,336,242,243,244,245," & _
                "246,248,333,337,217,218,219,220,362,366,368,370,249,250,251,252,363,367,369,371," & _
                "221,376,253,255,209,323,327,241,324,328,199,262,268,231,263,269,352,346,350,353," & _
                "347,351,381,377,379,382,378,380,272,270,273,271,286,287,321,322,344,345,356,357," & _
                "290,291,310,311,315,316,325,326,342,343"
        src = Split(codes, ",")
        dst = "AAAAAAAAAaaaaaaaaaEEEEEEEEeeeeeeeeIIIIIIIiiiiiiiOOOOOOOOooooooooUUUUUUUUuuuuuuuuYYyyNNNnnnCCCcccSSSsssZZZzzzDDddGgLlRrTtGgKkLlNnRr"
        ready = True
    End If
    For i = 0 To UBound(src)
        s = Replace(s, ChrW(CLng(src(i))), Mid$(dst, i + 1, 1))
    Next i
    s = Replace(s, ChrW(198), "AE")
    s = Replace(s, ChrW(230), "ae")
    s = Replace(s, ChrW(338), "OE")
    s = Replace(s, ChrW(339), "oe")
    s = Replace(s, ChrW(223), "ss")
    s = Replace(s, ChrW(208), "D")
    s = Replace(s, ChrW(240), "d")
    s = Replace(s, ChrW(222), "Th")
    s = Replace(s, ChrW(254), "th")
    s = Replace(s, ChrW(306), "IJ")
    s = Replace(s, ChrW(307), "ij")
    RemoveAccents = s
End Function

Public Function SortInsideCell(ByVal s As String, ByVal delim As String, ByVal descending As Boolean, ByVal numericSort As Boolean) As String
    Dim parts() As String, i As Long, j As Long, t As String, swapIt As Boolean
    If Len(delim) = 0 Then delim = " "
    If delim = "\n" Then delim = vbLf
    parts = Split(s, delim)
    For i = LBound(parts) To UBound(parts) - 1
        For j = i + 1 To UBound(parts)
            If numericSort And IsNumeric(parts(i)) And IsNumeric(parts(j)) Then
                swapIt = (Val(parts(i)) > Val(parts(j)))
            Else
                swapIt = (StrComp(parts(i), parts(j), vbTextCompare) > 0)
            End If
            If descending Then swapIt = Not swapIt And (StrComp(parts(i), parts(j), vbTextCompare) <> 0)
            If swapIt Then t = parts(i): parts(i) = parts(j): parts(j) = t
        Next j
    Next i
    SortInsideCell = Join(parts, delim)
End Function

Public Function StripHtml(ByVal s As String) As String
    Dim i As Long, ch As String, inTag As Boolean, out As String
    For i = 1 To Len(s)
        ch = Mid$(s, i, 1)
        If ch = "<" Then
            inTag = True
        ElseIf ch = ">" And inTag Then
            inTag = False
        ElseIf Not inTag Then
            out = out & ch
        End If
    Next i
    StripHtml = out
End Function

Public Function CleanNonPrinting(ByVal s As String) As String
    Dim i As Long, ch As String, out As String, code As Long
    For i = 1 To Len(s)
        ch = Mid$(s, i, 1)
        code = AscW(ch)
        If code < 0 Then code = code + 65536
        If code = 160 Then
            out = out & " "
        ElseIf code = 10 Or code = 13 Or code = 9 Or code >= 32 Then
            If code <> 127 And Not (code >= 128 And code <= 159) And code <> 8203 And code <> 65279 Then out = out & ch
        End If
    Next i
    CleanNonPrinting = out
End Function

'------------------------------------------------------------------------------
' Menu tools
'------------------------------------------------------------------------------
Public Sub XC_AddTextStartEnd()
    Dim pre As String, suf As String
    If SelRange() Is Nothing Then Exit Sub
    pre = AskText("Text to add at the BEGINNING of each selected cell (leave empty for none):", "", "Add Text to Beginning and/or End")
    suf = AskText("Text to add at the END of each selected cell (leave empty for none):", "", "Add Text to Beginning and/or End")
    If Len(pre) = 0 And Len(suf) = 0 Then Exit Sub
    RunTextTool "Add Text to Beginning and/or End", "addtext", pre, suf, , True
End Sub

Public Sub XC_Upper(): RunTextTool "Change to UPPERCASE", "upper": End Sub
Public Sub XC_Lower(): RunTextTool "Change to lowercase", "lower": End Sub
Public Sub XC_CapFirstOnly(): RunTextTool "Capitalize First Letter Only", "capfirst": End Sub
Public Sub XC_CapFirstLowerRest(): RunTextTool "Capitalize First Letter, Lowercase the Rest", "sentence": End Sub

Public Sub XC_TitleCase()
    Dim exc As String
    If SelRange() Is Nothing Then Exit Sub
    exc = AskText("Words to keep in lowercase (except at the start), separated by spaces:" & vbCrLf & _
                  "Leave empty to capitalize every word.", GetSetting(REG_APP, "Text", "TitleExceptions", "a an and as at but by for in nor of on or the to vs via"), "Title Case")
    SaveSetting REG_APP, "Text", "TitleExceptions", exc
    RunTextTool "Title Case", "title", exc
End Sub

Public Sub XC_ChangeCaseOptions()
    Dim c As Long
    If SelRange() Is Nothing Then Exit Sub
    c = AskChoice("Choose the capitalization to apply:", Array("UPPERCASE", "lowercase", "Sentence case. Each sentence starts with a capital.", _
                 "Title Case (Each Word)", "tOGGLE cASE", "Capitalize first letter only (rest unchanged)", "Capitalize first letter, lowercase the rest"))
    Select Case c
        Case 1: RunTextTool "Change Case", "upper"
        Case 2: RunTextTool "Change Case", "lower"
        Case 3: RunTextTool "Change Case", "sentences"
        Case 4: RunTextTool "Change Case", "title", ""
        Case 5: RunTextTool "Change Case", "toggle"
        Case 6: RunTextTool "Change Case", "capfirst"
        Case 7: RunTextTool "Change Case", "sentence"
    End Select
End Sub

Public Sub XC_TrimSpaces(): RunTextTool "Remove Leading and Trailing Spaces", "trim": End Sub
Public Sub XC_TrimAllSpaces(): RunTextTool "Remove Leading, Trailing and Extra Spaces", "trimall": End Sub
Public Sub XC_TrimLineBreaks(): RunTextTool "Remove Leading and Trailing Line Breaks", "trimlb": End Sub
Public Sub XC_RemoveTrailingLineBreaks(): RunTextTool "Remove Trailing Line Breaks", "rmtrailinglb": End Sub
Public Sub XC_RemoveAccents(): RunTextTool "Remove Accents", "accents": End Sub
Public Sub XC_RemoveLetters(): RunTextTool "Remove All Letters", "rmletters", , , , True: End Sub
Public Sub XC_RemoveNumbers(): RunTextTool "Remove All Numbers", "rmnumbers", , , , True: End Sub
Public Sub XC_ReverseText(): RunTextTool "Reverse Text", "reverse", , , , True: End Sub

Public Sub XC_RemoveUnwantedChars()
    Dim chars As String, repl As String
    If SelRange() Is Nothing Then Exit Sub
    chars = AskText("Enter the characters to remove (each character separately, no separator)." & vbCrLf & _
                    "Example: .,;-/\()  removes all of those characters.", "", "Remove or Replace Unwanted Characters")
    If Len(chars) = 0 Then Exit Sub
    repl = AskText("Replace each of those characters with (leave empty to remove):", "", "Remove or Replace Unwanted Characters")
    RunTextTool "Remove or Replace Unwanted Characters", "rmchars", chars, repl, , True
End Sub

Public Sub XC_RemoveFirstX()
    Dim n As Variant
    If SelRange() Is Nothing Then Exit Sub
    n = AskNumber("Remove how many characters from the START of each cell?", 1, "Remove First X Characters", 1)
    If IsEmpty(n) Then Exit Sub
    RunTextTool "Remove First X Characters", "rmfirst", CLng(n), , , True
End Sub

Public Sub XC_RemoveLastX()
    Dim n As Variant
    If SelRange() Is Nothing Then Exit Sub
    n = AskNumber("Remove how many characters from the END of each cell?", 1, "Remove Last X Characters", 1)
    If IsEmpty(n) Then Exit Sub
    RunTextTool "Remove Last X Characters", "rmlast", CLng(n), , , True
End Sub

Public Sub XC_KeepFirstX()
    Dim n As Variant
    If SelRange() Is Nothing Then Exit Sub
    n = AskNumber("Keep how many characters from the START of each cell?", 10, "Keep Only the First X Characters", 1)
    If IsEmpty(n) Then Exit Sub
    RunTextTool "Keep Only the First X Characters", "keepfirst", CLng(n), , , True
End Sub

Public Sub XC_SortInsideCell()
    Dim delim As String, c As Long, numeric As Boolean
    If SelRange() Is Nothing Then Exit Sub
    delim = AskText("Separator between the values inside each cell:" & vbCrLf & _
                    "(use \n for a line break, a single space is the default)", ",", "Sort Values Inside Each Cell")
    If Len(delim) = 0 Then Exit Sub
    c = AskChoice("Sort order:", Array("Ascending (A-Z, 0-9)", "Descending (Z-A, 9-0)"))
    If c = 0 Then Exit Sub
    numeric = AskYesNo("Sort numeric values by their number value (10 after 9) rather than as text?")
    RunTextTool "Sort Values Inside Each Cell", "sortinside", delim, (c = 2), numeric, True
End Sub

'--- Character-level formatting tools --------------------------------------
Public Sub XC_SubscriptChemical()
    On Error GoTo eh
    Dim rng As Range, c As Range, s As String, i As Long, ch As String, prev As String, n As Long, inSub As Boolean
    Set rng = SelRange()
    If rng Is Nothing Then Exit Sub
    SafeStart "Subscripting chemical formulas"
    For Each c In rng.Cells
        If Not c.HasFormula And VarType(c.Value) = vbString Then
            s = c.Value
            inSub = False
            For i = 1 To Len(s)
                ch = Mid$(s, i, 1)
                If i > 1 Then prev = Mid$(s, i - 1, 1) Else prev = ""
                If IsDigitChar(ch) Then
                    ' a digit after a letter or closing bracket (or continuing a subscript) is a subscript;
                    ' a leading coefficient (start, after space, +, = or arrow) is not.
                    If IsLetter(prev) Or prev = ")" Or prev = "]" Or (inSub And IsDigitChar(prev)) Then
                        c.Characters(i, 1).Font.Subscript = True
                        inSub = True
                    Else
                        inSub = False
                    End If
                Else
                    inSub = False
                End If
            Next i
            n = n + 1
        End If
    Next c
    SafeEnd
    Done "Subscript Numbers in Chemical Formulas: " & Plural(n, "cell") & " processed."
    Exit Sub
eh:
    ReportError "Subscript Numbers in Chemical Formulas"
End Sub

Private Sub ScriptLastChar(ByVal superscript As Boolean)
    On Error GoTo eh
    Dim rng As Range, c As Range, n As Long, nm As String
    nm = IIf(superscript, "Superscript Last Character", "Subscript Last Character")
    Set rng = SelRange()
    If rng Is Nothing Then Exit Sub
    SafeStart nm
    For Each c In rng.Cells
        If Not c.HasFormula And Len(c.Formula) > 0 Then
            With c.Characters(Len(c.Formula), 1).Font
                If superscript Then .Superscript = True Else .Subscript = True
            End With
            n = n + 1
        End If
    Next c
    SafeEnd
    Done nm & ": " & Plural(n, "cell") & " changed."
    Exit Sub
eh:
    ReportError nm
End Sub

Public Sub XC_SuperscriptLast(): ScriptLastChar True: End Sub
Public Sub XC_SubscriptLast(): ScriptLastChar False: End Sub

'--- Spell numbers ----------------------------------------------------------
Public Sub XC_SpellNumbers()
    On Error GoTo eh
    Dim rng As Range, c As Range, mode As Long, n As Long, cur As String, sub1 As String, v As Variant
    Set rng = SelRange()
    If rng Is Nothing Then Exit Sub
    mode = AskChoice("How should the numbers be written out?", Array( _
        "Plain words, replace the number (e.g. 1234 -> one thousand two hundred thirty-four)", _
        "As an amount with currency (e.g. 12.50 -> Twelve Dollars and Fifty Cents)", _
        "Plain words, write to the cell to the RIGHT (keep the number)", _
        "Amount with currency, write to the cell to the RIGHT (keep the number)"))
    If mode = 0 Then Exit Sub
    If mode = 2 Or mode = 4 Then
        cur = AskText("Name of the main currency unit (plural):", GetSetting(REG_APP, "Text", "Currency", "Dollars"), "Spell Amounts")
        sub1 = AskText("Name of the fractional unit (plural):", GetSetting(REG_APP, "Text", "SubCurrency", "Cents"), "Spell Amounts")
        SaveSetting REG_APP, "Text", "Currency", cur
        SaveSetting REG_APP, "Text", "SubCurrency", sub1
    End If
    If mode = 1 Or mode = 2 Then SnapshotRange rng, "Spell Numbers"
    SafeStart "Spelling numbers"
    For Each c In rng.Cells
        v = c.Value
        If IsNumeric(v) And Not IsEmpty(v) And VarType(v) <> vbString Then
            If mode = 1 Then
                c.Value = NumberToWords(CDbl(v))
            ElseIf mode = 2 Then
                c.Value = AmountToWords(CDbl(v), cur, sub1)
            ElseIf mode = 3 Then
                c.Offset(0, 1).Value = NumberToWords(CDbl(v))
            Else
                c.Offset(0, 1).Value = AmountToWords(CDbl(v), cur, sub1)
            End If
            n = n + 1
        End If
    Next c
    SafeEnd
    Done "Spell Numbers: " & Plural(n, "number") & " converted."
    Exit Sub
eh:
    ReportError "Spell Numbers"
End Sub

Public Function NumberToWords(ByVal n As Double) As String
    Dim neg As Boolean, intPart As Double, frac As Double, s As String, fracS As String, i As Long
    If n < 0 Then neg = True: n = -n
    intPart = Fix(n)
    frac = n - intPart
    s = IntegerToWords(intPart)
    If frac > 0.0000001 Then
        fracS = Mid$(Format$(Round(frac, 6), "0.######"), 3)
        s = s & " point"
        For i = 1 To Len(fracS)
            s = s & " " & LCase$(Ones(CLng(Mid$(fracS, i, 1))))
        Next i
    End If
    If neg Then s = "minus " & s
    NumberToWords = s
End Function

Public Function AmountToWords(ByVal n As Double, ByVal mainUnit As String, ByVal subUnit As String) As String
    Dim neg As Boolean, intPart As Double, cents As Long, s As String
    If n < 0 Then neg = True: n = -n
    n = Round(n, 2)
    intPart = Fix(n)
    cents = CLng(Round((n - intPart) * 100))
    If cents = 100 Then intPart = intPart + 1: cents = 0
    s = StrConv(IntegerToWords(intPart), vbProperCase) & " " & mainUnit
    If cents > 0 Then s = s & " and " & StrConv(IntegerToWords(cents), vbProperCase) & " " & subUnit
    If neg Then s = "Minus " & s
    AmountToWords = s
End Function

Private Function Ones(ByVal d As Long) As String
    Ones = Choose(d + 1, "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine")
End Function

Private Function IntegerToWords(ByVal n As Double) As String
    Dim scales As Variant, i As Long, chunk As Long, s As String, part As String
    If n = 0 Then IntegerToWords = "zero": Exit Function
    If n >= 1E+18 Then IntegerToWords = Format$(n, "0"): Exit Function
    scales = Array("", " thousand", " million", " billion", " trillion", " quadrillion")
    i = 0
    Do While n > 0
        chunk = CLng(n - Fix(n / 1000) * 1000)
        If chunk > 0 Then
            part = HundredsToWords(chunk) & scales(i)
            If Len(s) > 0 Then s = part & " " & s Else s = part
        End If
        n = Fix(n / 1000)
        i = i + 1
    Loop
    IntegerToWords = s
End Function

Private Function HundredsToWords(ByVal n As Long) As String
    Dim tens As Variant, teens As Variant, s As String, h As Long, t As Long, o As Long
    tens = Array("", "", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety")
    teens = Array("ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen")
    h = n \ 100: t = (n Mod 100) \ 10: o = n Mod 10
    If h > 0 Then s = Ones(h) & " hundred"
    If t = 1 Then
        s = s & IIf(Len(s) > 0, " ", "") & teens(o)
    Else
        If t > 1 Then s = s & IIf(Len(s) > 0, " ", "") & tens(t)
        If o > 0 Then
            If t > 1 Then s = s & "-" & Ones(o) Else s = s & IIf(Len(s) > 0, " ", "") & Ones(o)
        End If
    End If
    HundredsToWords = s
End Function

'--- Text dates -------------------------------------------------------------
Public Sub XC_TextToDates()
    On Error GoTo eh
    Dim rng As Range, c As Range, order As Long, n As Long, failed As Long, d As Variant, fmt As String
    Set rng = SelRange()
    If rng Is Nothing Then Exit Sub
    order = AskChoice("In what order are day, month and year written in the text?", Array( _
        "DMY  (31/12/2024, 31-12-24, 31.12.2024)", _
        "MDY  (12/31/2024, 12-31-24)", _
        "YMD  (2024-12-31, 20241231)", _
        "Let Excel guess (uses your regional settings; also handles month names like 'March 5, 2024')"))
    If order = 0 Then Exit Sub
    fmt = AskText("Date format to apply to the converted cells:", "yyyy-mm-dd", "Convert Text Dates")
    SnapshotRange rng, "Convert Text Dates", True
    SafeStart "Converting text dates"
    For Each c In rng.Cells
        If Not c.HasFormula And VarType(c.Value) = vbString Then
            d = ParseTextDate(Trim$(c.Value), order)
            If IsDate(d) Then
                c.NumberFormat = fmt
                c.Value = CDate(d)
                n = n + 1
            ElseIf Len(Trim$(c.Value)) > 0 Then
                failed = failed + 1
            End If
        End If
    Next c
    SafeEnd
    Done "Convert Text Dates: " & Plural(n, "cell") & " converted" & IIf(failed > 0, ", " & failed & " could not be recognized.", ".")
    Exit Sub
eh:
    ReportError "Convert Text Dates"
End Sub

' order: 1=DMY 2=MDY 3=YMD 4=auto
Public Function ParseTextDate(ByVal s As String, ByVal order As Long) As Variant
    Dim digits As String, i As Long, ch As String, parts() As String, grp As String, cnt As Long
    Dim d As Long, m As Long, y As Long, timePart As String, p As Long
    ParseTextDate = Empty
    If Len(s) = 0 Then Exit Function
    If order = 4 Then
        If IsDate(s) Then ParseTextDate = CDate(s)
        Exit Function
    End If
    ' separate a trailing time part (e.g. "31/12/2024 14:30")
    p = InStr(s, " ")
    If p > 0 And InStr(s, ":") > p Then timePart = Mid$(s, p + 1): s = Left$(s, p - 1)
    ' collect digit groups
    ReDim parts(0 To 2)
    For i = 1 To Len(s)
        ch = Mid$(s, i, 1)
        If IsDigitChar(ch) Then
            grp = grp & ch
        ElseIf Len(grp) > 0 Then
            If cnt > 2 Then Exit Function
            parts(cnt) = grp: cnt = cnt + 1: grp = ""
        End If
    Next i
    If Len(grp) > 0 Then
        If cnt > 2 Then Exit Function
        parts(cnt) = grp: cnt = cnt + 1
    End If
    If cnt = 1 Then
        ' compact form: 8 digits
        grp = parts(0)
        If Len(grp) = 8 Then
            Select Case order
                Case 1: parts(0) = Left$(grp, 2): parts(1) = Mid$(grp, 3, 2): parts(2) = Right$(grp, 4)
                Case 2: parts(0) = Left$(grp, 2): parts(1) = Mid$(grp, 3, 2): parts(2) = Right$(grp, 4)
                Case 3: parts(0) = Left$(grp, 4): parts(1) = Mid$(grp, 5, 2): parts(2) = Right$(grp, 2)
            End Select
            cnt = 3
        ElseIf Len(grp) = 6 Then
            parts(0) = Left$(grp, 2): parts(1) = Mid$(grp, 3, 2): parts(2) = Right$(grp, 2)
            cnt = 3
        Else
            ' maybe month names: fall back to Excel
            If IsDate(s) Then ParseTextDate = CDate(s)
            Exit Function
        End If
    End If
    If cnt <> 3 Then
        If IsDate(s) Then ParseTextDate = CDate(s)
        Exit Function
    End If
    Select Case order
        Case 1: d = CLng(parts(0)): m = CLng(parts(1)): y = CLng(parts(2))
        Case 2: m = CLng(parts(0)): d = CLng(parts(1)): y = CLng(parts(2))
        Case 3: y = CLng(parts(0)): m = CLng(parts(1)): d = CLng(parts(2))
    End Select
    If y < 100 Then y = y + IIf(y < 30, 2000, 1900)
    If m < 1 Or m > 12 Or d < 1 Or d > 31 Or y < 1900 Or y > 9999 Then Exit Function
    On Error Resume Next
    ParseTextDate = DateSerial(y, m, d)
    If Len(timePart) > 0 Then
        If IsDate(timePart) Then ParseTextDate = ParseTextDate + TimeValue(timePart)
    End If
    On Error GoTo 0
End Function

'--- Clean up data ----------------------------------------------------------
Public Sub XC_CleanUpData()
    On Error GoTo eh
    Dim rng As Range, c As Range, opts As String, n As Long, s As String, v As Variant, nv As String
    Dim doTrim As Boolean, doClean As Boolean, doNum As Boolean, doFmt As Boolean, doMerge As Boolean, doLb As Boolean
    Set rng = SelRange()
    If rng Is Nothing Then Exit Sub
    opts = AskText("Clean up the selected cells. Enter the numbers of the actions to perform, separated by commas:" & vbCrLf & vbCrLf & _
                   "1. Remove leading, trailing and double spaces (incl. non-breaking spaces)" & vbCrLf & _
                   "2. Remove non-printable characters" & vbCrLf & _
                   "3. Convert numbers stored as text to real numbers" & vbCrLf & _
                   "4. Replace line breaks with a space" & vbCrLf & _
                   "5. Unmerge all merged cells" & vbCrLf & _
                   "6. Reset formatting to the Normal style", "1,2,3", "Clean Up Data and Formatting")
    If Len(opts) = 0 Then Exit Sub
    opts = "," & Replace(opts, " ", "") & ","
    doTrim = InStr(opts, ",1,") > 0: doClean = InStr(opts, ",2,") > 0: doNum = InStr(opts, ",3,") > 0
    doLb = InStr(opts, ",4,") > 0: doMerge = InStr(opts, ",5,") > 0: doFmt = InStr(opts, ",6,") > 0
    SnapshotRange rng, "Clean Up Data", True
    SafeStart "Cleaning up"
    If doMerge Then rng.UnMerge
    If doFmt Then rng.Style = "Normal": rng.ClearFormats
    For Each c In rng.Cells
        If Not c.HasFormula Then
            v = c.Value
            If VarType(v) = vbString Then
                s = v
                nv = s
                If doClean Then nv = CleanNonPrinting(nv)
                If doLb Then nv = Replace(Replace(nv, vbCrLf, " "), vbLf, " ")
                If doTrim Then nv = TrimAllSpaces(nv)
                If doNum And IsNumeric(nv) And Len(nv) > 0 Then
                    c.NumberFormat = "General"
                    c.Value = CDbl(nv)
                    n = n + 1
                ElseIf nv <> s Then
                    WriteText c, nv
                    n = n + 1
                End If
            End If
        End If
    Next c
    SafeEnd
    Done "Clean Up Data: " & Plural(n, "cell") & " changed."
    Exit Sub
eh:
    ReportError "Clean Up Data"
End Sub

'--- Advanced find and replace ---------------------------------------------
Public Sub XC_AdvancedFindReplace()
    On Error GoTo eh
    Dim findS As String, replS As String, scope As Long, lookIn As Long, matchCase As Boolean, wholeCell As Boolean
    Dim ws As Worksheet, rng As Range, n As Long, cm As Comment, shp As Shape, shList As Collection, v As Variant
    findS = AskText("Find what:", "", "Advanced Find and Replace")
    If Len(findS) = 0 Then Exit Sub
    replS = AskText("Replace with (empty removes the text):", "", "Advanced Find and Replace")
    scope = AskChoice("Where to search?", Array("Current selection", "Active sheet", "All sheets in this workbook"))
    If scope = 0 Then Exit Sub
    lookIn = AskChoice("Look in:", Array("Formulas and values (like Excel)", "Cell values only (skip formula cells)", "Comments / notes", "Shapes and text boxes", "Everything above"))
    If lookIn = 0 Then Exit Sub
    matchCase = AskYesNo("Match case?", False)
    wholeCell = AskYesNo("Match the entire cell contents only?", False)
    Set shList = New Collection
    If scope = 3 Then
        For Each ws In ActiveWorkbook.Worksheets: shList.Add ws: Next ws
    Else
        shList.Add ActiveSheet
    End If
    SafeStart "Find and replace"
    For Each v In shList
        Set ws = v
        If scope = 1 Then Set rng = SelRange() Else Set rng = ws.UsedRange
        If Not rng Is Nothing Then
            If lookIn = 1 Or lookIn = 5 Then
                n = n + CountOccurrences(rng, findS, matchCase, wholeCell, False)
                rng.Replace What:=findS, Replacement:=replS, LookAt:=IIf(wholeCell, xlWhole, xlPart), _
                            SearchOrder:=xlByRows, MatchCase:=matchCase, SearchFormat:=False, ReplaceFormat:=False
            ElseIf lookIn = 2 Then
                n = n + ReplaceInValuesOnly(rng, findS, replS, matchCase, wholeCell)
            End If
            If lookIn = 3 Or lookIn = 5 Then
                For Each cm In ws.Comments
                    If scope <> 1 Or Not Intersect(cm.Parent, rng) Is Nothing Then
                        If InStr(1, cm.Text, findS, IIf(matchCase, vbBinaryCompare, vbTextCompare)) > 0 Then
                            cm.Text Text:=Replace(cm.Text, findS, replS, , , IIf(matchCase, vbBinaryCompare, vbTextCompare))
                            n = n + 1
                        End If
                    End If
                Next cm
            End If
            If lookIn = 4 Or lookIn = 5 Then
                For Each shp In ws.Shapes
                    On Error Resume Next
                    If shp.TextFrame2.HasText Then
                        If InStr(1, shp.TextFrame2.TextRange.Text, findS, IIf(matchCase, vbBinaryCompare, vbTextCompare)) > 0 Then
                            shp.TextFrame2.TextRange.Text = Replace(shp.TextFrame2.TextRange.Text, findS, replS, , , IIf(matchCase, vbBinaryCompare, vbTextCompare))
                            n = n + 1
                        End If
                    End If
                    On Error GoTo eh
                Next shp
            End If
        End If
    Next v
    SafeEnd
    Done "Advanced Find and Replace: " & Plural(n, "replacement") & " made."
    Exit Sub
eh:
    ReportError "Advanced Find and Replace"
End Sub

Private Function CountOccurrences(ByVal rng As Range, ByVal findS As String, ByVal matchCase As Boolean, ByVal wholeCell As Boolean, ByVal valuesOnly As Boolean) As Long
    Dim c As Range, s As String, cmp As VbCompareMethod, n As Long
    cmp = IIf(matchCase, vbBinaryCompare, vbTextCompare)
    For Each c In rng.Cells
        If Not (valuesOnly And c.HasFormula) Then
            s = c.Formula
            If wholeCell Then
                If StrComp(s, findS, cmp) = 0 Then n = n + 1
            ElseIf InStr(1, s, findS, cmp) > 0 Then
                n = n + 1
            End If
        End If
    Next c
    CountOccurrences = n
End Function

Private Function ReplaceInValuesOnly(ByVal rng As Range, ByVal findS As String, ByVal replS As String, ByVal matchCase As Boolean, ByVal wholeCell As Boolean) As Long
    Dim c As Range, s As String, nv As String, cmp As VbCompareMethod, n As Long
    cmp = IIf(matchCase, vbBinaryCompare, vbTextCompare)
    For Each c In rng.Cells
        If Not c.HasFormula And Not IsEmpty(c.Value) Then
            s = CStr(c.Value)
            If wholeCell Then
                If StrComp(s, findS, cmp) = 0 Then nv = replS Else nv = s
            Else
                nv = Replace(s, findS, replS, , , cmp)
            End If
            If nv <> s Then WriteText c, nv: n = n + 1
        End If
    Next c
    ReplaceInValuesOnly = n
End Function
