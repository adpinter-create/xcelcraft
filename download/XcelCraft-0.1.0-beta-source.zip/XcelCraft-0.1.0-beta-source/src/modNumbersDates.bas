Attribute VB_Name = "modNumbersDates"
'==============================================================================
' SPDX-License-Identifier: MIT
' XcelCraft - modNumbersDates
' Numbers & Dates category. Original implementation.
' (SpellNumbers, TextToDates, AddLeadingZeros, AutoNumber, UniqueRandom and
'  InsertDate live in modText / modFill and are shared via the menu registry.)
'==============================================================================
Option Explicit

'--- Apply Calculation ------------------------------------------------------
Public Sub XC_ApplyCalculation()
    On Error GoTo eh
    Dim rng As Range, c As Range, op As Long, amt As Variant, asFormula As Boolean, n As Long, v As Variant, f As String
    Set rng = SelRange()
    If rng Is Nothing Then Exit Sub
    op = AskChoice("Which calculation do you want to apply to the selected cells?", Array( _
        "Add (+)", "Subtract (-)", "Multiply (x)", "Divide (/)", "Raise to the power (^)", _
        "Round to N decimals", "Round UP to N decimals", "Round DOWN to N decimals", "Make absolute (ABS)", "Reverse sign (x -1)"))
    If op = 0 Then Exit Sub
    If op <= 8 Then
        amt = AskNumber("Enter the number to use:", IIf(op >= 6, 0, 1), "Apply Calculation")
        If IsEmpty(amt) Then Exit Sub
        If op = 4 And amt = 0 Then MsgBox "Cannot divide by zero.", vbExclamation, APP_NAME: Exit Sub
    End If
    asFormula = AskYesNo("Keep the result as a formula?" & vbCrLf & "Yes = wrap the existing content in a formula (e.g. =(A1)*2)" & vbCrLf & "No = replace cell contents with the calculated value", False)
    SnapshotRange rng, "Apply Calculation"
    SafeStart "Applying calculation"
    For Each c In rng.Cells
        v = c.Value
        If (IsNumeric(v) And Not IsEmpty(v) And VarType(v) <> vbString And VarType(v) <> vbBoolean) Or (c.HasFormula And asFormula) Then
            If asFormula Then
                f = c.Formula
                If Left$(f, 1) = "=" Then f = Mid$(f, 2)
                c.Formula = "=" & WrapCalc("(" & f & ")", op, amt)
            Else
                If VarType(v) = vbDate Then v = CDbl(v)
                c.Value = CalcValue(CDbl(v), op, amt)
            End If
            n = n + 1
        End If
    Next c
    SafeEnd
    Done "Apply Calculation: " & Plural(n, "cell") & " changed."
    Exit Sub
eh:
    ReportError "Apply Calculation"
End Sub

Private Function WrapCalc(ByVal f As String, ByVal op As Long, ByVal amt As Variant) As String
    Select Case op
        Case 1: WrapCalc = f & "+" & amt
        Case 2: WrapCalc = f & "-" & amt
        Case 3: WrapCalc = f & "*" & amt
        Case 4: WrapCalc = f & "/" & amt
        Case 5: WrapCalc = f & "^" & amt
        Case 6: WrapCalc = "ROUND(" & f & "," & amt & ")"
        Case 7: WrapCalc = "ROUNDUP(" & f & "," & amt & ")"
        Case 8: WrapCalc = "ROUNDDOWN(" & f & "," & amt & ")"
        Case 9: WrapCalc = "ABS(" & f & ")"
        Case 10: WrapCalc = "-" & f
    End Select
End Function

Private Function CalcValue(ByVal v As Double, ByVal op As Long, ByVal amt As Variant) As Double
    Select Case op
        Case 1: CalcValue = v + amt
        Case 2: CalcValue = v - amt
        Case 3: CalcValue = v * amt
        Case 4: CalcValue = v / amt
        Case 5: CalcValue = v ^ amt
        Case 6: CalcValue = Application.WorksheetFunction.Round(v, amt)
        Case 7: CalcValue = Application.WorksheetFunction.RoundUp(v, amt)
        Case 8: CalcValue = Application.WorksheetFunction.RoundDown(v, amt)
        Case 9: CalcValue = Abs(v)
        Case 10: CalcValue = -v
    End Select
End Function

'--- Formulas to values -----------------------------------------------------
Public Sub XC_FormulasToValues()
    On Error GoTo eh
    Dim rng As Range, a As Range, n As Long
    Set rng = SelRange()
    If rng Is Nothing Then Exit Sub
    SnapshotRange rng, "Convert Formulas to Values"
    SafeStart "Converting formulas to values"
    For Each a In rng.Areas
        n = n + CountFormulas(a)
        a.Value = a.Value
    Next a
    SafeEnd
    Done "Convert Formulas to Values: " & Plural(n, "formula") & " converted."
    Exit Sub
eh:
    ReportError "Convert Formulas to Values"
End Sub

Public Function CountFormulas(ByVal rng As Range) As Long
    Dim f As Range
    On Error Resume Next
    Set f = rng.SpecialCells(xlCellTypeFormulas)
    On Error GoTo 0
    If Not f Is Nothing Then CountFormulas = f.Cells.CountLarge
End Function

'--- Text <-> numbers --------------------------------------------------------
Public Sub XC_TextToNumbers()
    On Error GoTo eh
    Dim rng As Range, c As Range, n As Long, v As Variant, s As String
    Set rng = SelRange()
    If rng Is Nothing Then Exit Sub
    SnapshotRange rng, "Text to Numbers", True
    SafeStart "Converting text to numbers"
    For Each c In rng.Cells
        If Not c.HasFormula Then
            v = c.Value
            If VarType(v) = vbString Then
                s = Trim$(Replace(v, ChrW(160), " "))
                ' handle trailing minus and surrounding parentheses
                If Right$(s, 1) = "-" And IsNumeric(Left$(s, Len(s) - 1)) Then s = "-" & Left$(s, Len(s) - 1)
                If Left$(s, 1) = "(" And Right$(s, 1) = ")" Then
                    If IsNumeric(Mid$(s, 2, Len(s) - 2)) Then s = "-" & Mid$(s, 2, Len(s) - 2)
                End If
                If Len(s) > 0 And IsNumeric(s) Then
                    If c.NumberFormat = "@" Then c.NumberFormat = "General"
                    c.Value = CDbl(s)
                    n = n + 1
                End If
            End If
        End If
    Next c
    SafeEnd
    Done "Convert Numbers Stored as Text: " & Plural(n, "cell") & " converted."
    Exit Sub
eh:
    ReportError "Convert Numbers Stored as Text"
End Sub

Public Sub XC_NumbersToText()
    On Error GoTo eh
    Dim rng As Range, c As Range, n As Long, v As Variant
    Set rng = SelRange()
    If rng Is Nothing Then Exit Sub
    SnapshotRange rng, "Numbers to Text"
    SafeStart "Storing numbers as text"
    For Each c In rng.Cells
        If Not c.HasFormula Then
            v = c.Value
            If IsNumeric(v) And Not IsEmpty(v) And VarType(v) <> vbString Then
                c.Formula = "'" & c.Text
                n = n + 1
            End If
        End If
    Next c
    SafeEnd
    Done "Insert Leading Apostrophe: " & Plural(n, "cell") & " changed."
    Exit Sub
eh:
    ReportError "Insert Leading Apostrophe"
End Sub

' Replace values with their displayed (formatted) text.
Public Sub XC_ValuesToFormattedText()
    On Error GoTo eh
    Dim rng As Range, c As Range, n As Long, t As String
    Set rng = SelRange()
    If rng Is Nothing Then Exit Sub
    SnapshotRange rng, "Values to Formatted Text", True
    SafeStart "Replacing values with formatted text"
    For Each c In rng.Cells
        If Not IsEmpty(c.Value) Then
            t = c.Text
            If InStr(t, "#") = 1 And Len(Replace(t, "#", "")) = 0 Then
                ' column too narrow: widen temporarily to get the real text
                Dim w As Double: w = c.ColumnWidth
                c.ColumnWidth = 255: t = c.Text: c.ColumnWidth = w
            End If
            c.NumberFormat = "@"
            c.Value = t
            n = n + 1
        End If
    Next c
    SafeEnd
    Done "Replace Values with Their Formatted Value: " & Plural(n, "cell") & " changed."
    Exit Sub
eh:
    ReportError "Replace Values with Their Formatted Value"
End Sub

'--- Signs ------------------------------------------------------------------
Public Sub XC_ChangeSigns()
    On Error GoTo eh
    Dim rng As Range, c As Range, mode As Long, n As Long, v As Variant, f As String
    Set rng = SelRange()
    If rng Is Nothing Then Exit Sub
    mode = AskChoice("How do you want to change the signs?", Array("Reverse the sign of all numbers", "Make all numbers positive", "Make all numbers negative"))
    If mode = 0 Then Exit Sub
    SnapshotRange rng, "Change Number Signs"
    SafeStart "Changing signs"
    For Each c In rng.Cells
        v = c.Value
        If c.HasFormula Then
            f = Mid$(c.Formula, 2)
            Select Case mode
                Case 1: c.Formula = "=-(" & f & ")"
                Case 2: c.Formula = "=ABS(" & f & ")"
                Case 3: c.Formula = "=-ABS(" & f & ")"
            End Select
            n = n + 1
        ElseIf IsNumeric(v) And Not IsEmpty(v) And VarType(v) <> vbString And VarType(v) <> vbBoolean Then
            Select Case mode
                Case 1: c.Value = -v
                Case 2: c.Value = Abs(v)
                Case 3: c.Value = -Abs(v)
            End Select
            n = n + 1
        End If
    Next c
    SafeEnd
    Done "Change Number Signs: " & Plural(n, "cell") & " changed."
    Exit Sub
eh:
    ReportError "Change Number Signs"
End Sub

Public Sub XC_FixTrailingMinus()
    On Error GoTo eh
    Dim rng As Range, c As Range, n As Long, v As Variant, s As String
    Set rng = SelRange()
    If rng Is Nothing Then Exit Sub
    SnapshotRange rng, "Fix Trailing Minus", True
    SafeStart "Fixing trailing minus signs"
    For Each c In rng.Cells
        If Not c.HasFormula Then
            v = c.Value
            If VarType(v) = vbString Then
                s = Trim$(v)
                If Len(s) > 1 And Right$(s, 1) = "-" Then
                    If IsNumeric(Left$(s, Len(s) - 1)) Then
                        If c.NumberFormat = "@" Then c.NumberFormat = "General"
                        c.Value = -CDbl(Left$(s, Len(s) - 1))
                        n = n + 1
                    End If
                End If
            End If
        End If
    Next c
    SafeEnd
    Done "Fix Trailing Minus Sign: " & Plural(n, "cell") & " fixed."
    Exit Sub
eh:
    ReportError "Fix Trailing Minus Sign"
End Sub

'--- Significant decimals ---------------------------------------------------
' Formats each number so that N significant non-zero decimals are shown,
' e.g. with N=2: 0.000123456 -> 0.00012 ; 12.3456 -> 12.35
Public Sub XC_SignificantDecimals()
    On Error GoTo eh
    Dim rng As Range, c As Range, sig As Variant, n As Long, v As Variant, d As Long, frac As Double, fmt As String
    Set rng = SelRange()
    If rng Is Nothing Then Exit Sub
    sig = AskNumber("How many significant (non-zero) decimals should be shown?", 2, "Significant Decimals", 1, 15)
    If IsEmpty(sig) Then Exit Sub
    SnapshotRange rng, "Significant Decimals", True
    SafeStart "Applying number formats"
    For Each c In rng.Cells
        v = c.Value
        If IsNumeric(v) And Not IsEmpty(v) And VarType(v) <> vbString And VarType(v) <> vbBoolean And VarType(v) <> vbDate Then
            frac = Abs(CDbl(v)) - Fix(Abs(CDbl(v)))
            If frac = 0 Then
                d = 0
            Else
                d = 0
                Do While frac * 10 ^ d < 10 ^ (sig - 1) And d < 15
                    d = d + 1
                Loop
                ' d now is the position of the first non-zero decimal + sig - 1 digits
            End If
            If d = 0 Then fmt = "0" Else fmt = "0." & String$(d, "0")
            c.NumberFormat = fmt
            n = n + 1
        End If
    Next c
    SafeEnd
    Done "Show Significant Decimals: " & Plural(n, "cell") & " formatted."
    Exit Sub
eh:
    ReportError "Show Significant Decimals"
End Sub

'--- Percent to number ------------------------------------------------------
Public Sub XC_PercentToNumber()
    On Error GoTo eh
    Dim rng As Range, c As Range, n As Long, v As Variant
    Set rng = SelRange()
    If rng Is Nothing Then Exit Sub
    SnapshotRange rng, "Percent to Number", True
    SafeStart "Converting percentages"
    For Each c In rng.Cells
        v = c.Value
        If IsNumeric(v) And Not IsEmpty(v) And VarType(v) <> vbString And InStr(c.NumberFormat, "%") > 0 Then
            If c.HasFormula Then
                c.Formula = "=(" & Mid$(c.Formula, 2) & ")*100"
            Else
                c.Value = CDbl(v) * 100
            End If
            c.NumberFormat = "General"
            n = n + 1
        End If
    Next c
    SafeEnd
    Done "Convert Percentages to Numbers: " & Plural(n, "cell") & " converted."
    Exit Sub
eh:
    ReportError "Convert Percentages to Numbers"
End Sub

'--- Permanent rounding -----------------------------------------------------
Public Sub XC_RoundPermanently()
    On Error GoTo eh
    Dim rng As Range, c As Range, mode As Long, dec As Variant, n As Long, v As Variant, r As Double
    Set rng = SelRange()
    If rng Is Nothing Then Exit Sub
    mode = AskChoice("Rounding method:", Array("Round (half away from zero, like Excel's ROUND)", "Round up (away from zero)", "Round down (towards zero)", "Round to nearest even (banker's rounding)", "Round to nearest multiple of..."))
    If mode = 0 Then Exit Sub
    If mode = 5 Then
        dec = AskNumber("Round to the nearest multiple of:", 5, "Permanently Round Numbers")
    Else
        dec = AskNumber("Number of decimals (negative rounds to tens, hundreds...):", 2, "Permanently Round Numbers", -15, 15)
    End If
    If IsEmpty(dec) Then Exit Sub
    SnapshotRange rng, "Round Permanently"
    SafeStart "Rounding"
    For Each c In rng.Cells
        v = c.Value
        If IsNumeric(v) And Not IsEmpty(v) And VarType(v) <> vbString And VarType(v) <> vbBoolean And Not c.HasFormula Then
            Select Case mode
                Case 1: r = Application.WorksheetFunction.Round(CDbl(v), dec)
                Case 2: r = Application.WorksheetFunction.RoundUp(CDbl(v), dec)
                Case 3: r = Application.WorksheetFunction.RoundDown(CDbl(v), dec)
                Case 4: r = Round(CDbl(v), dec)
                Case 5: r = Application.WorksheetFunction.MRound(CDbl(v), dec)
            End Select
            If r <> CDbl(v) Then c.Value = r: n = n + 1
        End If
    Next c
    SafeEnd
    Done "Permanently Round Numbers: " & Plural(n, "cell") & " rounded."
    Exit Sub
eh:
    ReportError "Permanently Round Numbers"
End Sub

'--- Julian dates -----------------------------------------------------------
' Supports yyddd, yyyyddd and cyyddd (c: 0=19xx, 1=20xx, 2=21xx)
Public Sub XC_JulianToDate()
    On Error GoTo eh
    Dim rng As Range, c As Range, n As Long, s As String, y As Long, d As Long, fmt As String, dt As Date, ok As Boolean
    Set rng = SelRange()
    If rng Is Nothing Then Exit Sub
    fmt = AskText("Date format to apply:", "yyyy-mm-dd", "Convert Julian Dates")
    If Len(fmt) = 0 Then Exit Sub
    SnapshotRange rng, "Julian to Date", True
    SafeStart "Converting Julian dates"
    For Each c In rng.Cells
        If Not c.HasFormula And Not IsEmpty(c.Value) Then
            s = Trim$(CStr(c.Value))
            If VarType(c.Value) <> vbString Then s = CStr(CLng(c.Value))
            ok = True
            Select Case Len(s)
                Case 5: y = CLng(Left$(s, 2)): y = y + IIf(y < 30, 2000, 1900): d = CLng(Right$(s, 3))
                Case 7: y = CLng(Left$(s, 4)): d = CLng(Right$(s, 3))
                Case 6: y = 1900 + CLng(Left$(s, 1)) * 100 + CLng(Mid$(s, 2, 2)): d = CLng(Right$(s, 3))
                Case Else: ok = False
            End Select
            If ok Then
                If d >= 1 And d <= 366 And IsNumeric(s) Then
                    dt = DateSerial(y, 1, 1) + d - 1
                    c.NumberFormat = fmt
                    c.Value = dt
                    n = n + 1
                End If
            End If
        End If
    Next c
    SafeEnd
    Done "Convert Julian Dates: " & Plural(n, "cell") & " converted."
    Exit Sub
eh:
    ReportError "Convert Julian Dates"
End Sub
