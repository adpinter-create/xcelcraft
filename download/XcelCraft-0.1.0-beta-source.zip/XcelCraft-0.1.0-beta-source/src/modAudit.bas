Attribute VB_Name = "modAudit"
'==============================================================================
' SPDX-License-Identifier: MIT
' XcelCraft - modAudit
' Auditing: precedent/dependent navigation (jump lists), show-all arrows,
' trace in/out with a return stack, formula-consistency check, model audit report.
' Original implementation.
'==============================================================================
Option Explicit

Private mTraceStack As Collection   ' addresses to return to (Trace Out)

'--- Precedents / dependents -------------------------------------------------------
' Lists every range the active cell's formula refers to (same sheet, other sheets,
' other workbooks) with its value; pick one to jump there.
Public Sub XC_PrecedentsList()
    On Error GoTo eh
    Dim c As Range, refs As Collection, i As Long, s As String, pick As Variant, r As Range, v As Variant
    If TypeName(Selection) <> "Range" Then Exit Sub
    Set c = ActiveCell
    If Not c.HasFormula Then MsgBox c.Address(False, False) & " does not contain a formula.", vbInformation, APP_NAME: Exit Sub
    Set refs = FormulaReferences(c)
    If refs.Count = 0 Then MsgBox "No cell references found in: " & c.Formula, vbInformation, APP_NAME: Exit Sub
    s = c.Address(False, False) & ":  " & Left$(c.Formula, 120) & vbCrLf & vbCrLf & "Precedents (enter a number to jump there):" & vbCrLf & vbCrLf
    For i = 1 To refs.Count
        Set r = refs(i)
        v = ""
        On Error Resume Next
        If r.Cells.CountLarge = 1 Then v = r.Text Else v = r.Cells.CountLarge & " cells, sum " & Application.WorksheetFunction.Sum(r)
        On Error GoTo eh
        s = s & i & ". " & RefLabel(r, c) & "   =  " & v & vbCrLf
        If i >= 30 Then s = s & "... (" & (refs.Count - 30) & " more)" & vbCrLf: Exit For
    Next i
    pick = Application.InputBox(s, "Precedents", 1, Type:=1)
    If VarType(pick) = vbBoolean Then Exit Sub
    If pick >= 1 And pick <= refs.Count Then
        PushTrace c
        JumpTo refs(CLng(pick))
    End If
    Exit Sub
eh:
    ReportError "Precedents"
End Sub

' Lists every formula in the workbook that refers to the active cell.
Public Sub XC_DependentsList()
    On Error GoTo eh
    Dim c As Range, deps As Collection, i As Long, s As String, pick As Variant, r As Range
    If TypeName(Selection) <> "Range" Then Exit Sub
    Set c = ActiveCell
    SafeStart "Finding dependents"
    Set deps = FindDependents(c)
    SafeEnd
    If deps.Count = 0 Then MsgBox "No formulas refer to " & c.Address(False, False) & " (direct references only; OFFSET/INDIRECT are not detected).", vbInformation, APP_NAME: Exit Sub
    s = "Dependents of " & c.Address(False, False) & " (enter a number to jump there):" & vbCrLf & vbCrLf
    For i = 1 To deps.Count
        Set r = deps(i)
        s = s & i & ". " & RefLabel(r, c) & "   " & Left$(r.Formula, 60) & vbCrLf
        If i >= 30 Then s = s & "... (" & (deps.Count - 30) & " more)" & vbCrLf: Exit For
    Next i
    pick = Application.InputBox(s, "Dependents", 1, Type:=1)
    If VarType(pick) = vbBoolean Then Exit Sub
    If pick >= 1 And pick <= deps.Count Then
        PushTrace c
        JumpTo deps(CLng(pick))
    End If
    Exit Sub
eh:
    ReportError "Dependents"
End Sub

Private Function RefLabel(ByVal r As Range, ByVal ctx As Range) As String
    If r.Worksheet.Parent.Name <> ctx.Worksheet.Parent.Name Then
        RefLabel = "[" & r.Worksheet.Parent.Name & "]" & r.Worksheet.Name & "!" & r.Address(False, False)
    ElseIf r.Worksheet.Name <> ctx.Worksheet.Name Then
        RefLabel = r.Worksheet.Name & "!" & r.Address(False, False)
    Else
        RefLabel = r.Address(False, False)
    End If
End Function

Private Sub JumpTo(ByVal r As Range)
    On Error Resume Next
    r.Worksheet.Parent.Activate
    r.Worksheet.Activate
    r.Select
End Sub

' Extracts the ranges a formula references, resolving sheet/workbook qualifiers and names.
Public Function FormulaReferences(ByVal c As Range) As Collection
    Dim refs As Collection, f As String, i As Long, ch As String, inQ As Boolean, tok As String, out As Collection, t As Variant, r As Range, k As Long
    Set refs = New Collection: Set out = New Collection
    f = Mid$(c.Formula, 2)
    ' tokenise: a reference token is a run of chars from the set [A-Za-z0-9_$:.!'[\] ] that contains no operators
    i = 1
    Do While i <= Len(f)
        ch = Mid$(f, i, 1)
        If ch = """" Then
            inQ = Not inQ: i = i + 1
        ElseIf inQ Then
            i = i + 1
        ElseIf ch = "'" Then
            ' quoted sheet name: read up to closing quote (doubled quotes inside)
            k = i + 1
            Do While k <= Len(f)
                If Mid$(f, k, 1) = "'" Then
                    If Mid$(f, k + 1, 1) = "'" Then k = k + 2 Else Exit Do
                Else
                    k = k + 1
                End If
            Loop
            tok = Mid$(f, i, k - i + 1)
            i = k + 1
            ' continue reading the !ref part
            Do While i <= Len(f) And InStr("!$:ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_.", Mid$(f, i, 1)) > 0
                tok = tok & Mid$(f, i, 1): i = i + 1
            Loop
            refs.Add tok
        ElseIf IsLetter(ch) Or ch = "$" Or ch = "[" Or ch = "_" Then
            tok = ""
            Do While i <= Len(f) And InStr("!$:[]ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_.", Mid$(f, i, 1)) > 0
                tok = tok & Mid$(f, i, 1): i = i + 1
            Loop
            If i <= Len(f) Then
                If Mid$(f, i, 1) = "(" Then tok = ""   ' function name
            End If
            If Len(tok) > 0 Then
                If Not (UCase$(tok) = "TRUE" Or UCase$(tok) = "FALSE") Then refs.Add tok
            End If
        Else
            i = i + 1
        End If
    Loop
    ' resolve each token to a Range (skip duplicates and non-resolvable tokens)
    Dim seen As Collection: Set seen = New Collection
    For Each t In refs
        Set r = ResolveRef(CStr(t), c)
        If Not r Is Nothing Then
            On Error Resume Next
            seen.Add 1, "k" & r.Address(External:=True)
            If Err.Number = 0 Then out.Add r
            Err.Clear
            On Error GoTo 0
        End If
    Next t
    Set FormulaReferences = out
End Function

Private Function ResolveRef(ByVal tok As String, ByVal ctx As Range) As Range
    Dim r As Range
    On Error Resume Next
    If InStr(tok, "!") > 0 Then
        Set r = Application.Range(tok)
        If r Is Nothing Then Set r = ctx.Worksheet.Parent.Application.Evaluate(tok)
    Else
        Set r = ctx.Worksheet.Range(tok)
        If r Is Nothing Then Set r = ctx.Worksheet.Evaluate(tok)   ' workbook-level names
    End If
    If TypeName(r) = "Range" Then Set ResolveRef = r
    On Error GoTo 0
End Function

' Scans all open workbooks' formulas for direct references to the cell.
Private Function FindDependents(ByVal c As Range) As Collection
    Dim deps As Collection, wb As Workbook, ws As Worksheet, fr As Range, f As Range, refs As Collection, r As Variant
    Set deps = New Collection
    For Each wb In Application.Workbooks
        For Each ws In wb.Worksheets
            Set fr = Nothing
            On Error Resume Next
            Set fr = ws.UsedRange.SpecialCells(xlCellTypeFormulas)
            On Error GoTo 0
            If Not fr Is Nothing Then
                For Each f In fr.Cells
                    ' quick text filter before the expensive parse
                    If QuickMayReference(f.Formula, c, ws) Then
                        Set refs = FormulaReferences(f)
                        For Each r In refs
                            If r.Worksheet.Parent.Name = c.Worksheet.Parent.Name And r.Worksheet.Name = c.Worksheet.Name Then
                                If Not Intersect(r, c) Is Nothing Then deps.Add f: Exit For
                            End If
                        Next r
                    End If
                Next f
            End If
        Next ws
    Next wb
    Set FindDependents = deps
End Function

Private Function QuickMayReference(ByVal f As String, ByVal c As Range, ByVal ws As Worksheet) As Boolean
    Dim colL As String, rowS As String
    colL = modModeling.ColumnLetter(c.Column): rowS = CStr(c.Row)
    If ws.Name <> c.Worksheet.Name And InStr(f, "!") = 0 Then Exit Function
    ' must mention the column letter(s) somewhere, or a colon range, or a name (skip names for speed)
    If InStr(1, UCase$(f), colL) = 0 And InStr(f, ":") = 0 Then Exit Function
    QuickMayReference = True
End Function

'--- Show all arrows / clear -----------------------------------------------------
Public Sub XC_ShowAllPrecedents()
    On Error GoTo eh
    Dim c As Range, rng As Range
    Set rng = SelRange(False, True)
    If rng Is Nothing Then Exit Sub
    If rng.Cells.CountLarge > 20 Then MsgBox "Select at most 20 cells.", vbInformation, APP_NAME: Exit Sub
    If modFormatCycles.NextCycleIndex("ArrowsP", 2) = 1 Then rng.Worksheet.ClearArrows: Exit Sub
    For Each c In rng.Cells
        If c.HasFormula Then c.ShowPrecedents
    Next c
    Exit Sub
eh:
    ReportError "Show All Precedents"
End Sub

Public Sub XC_ShowAllDependents()
    On Error GoTo eh
    Dim c As Range, rng As Range
    Set rng = SelRange(False, True)
    If rng Is Nothing Then Exit Sub
    If rng.Cells.CountLarge > 20 Then MsgBox "Select at most 20 cells.", vbInformation, APP_NAME: Exit Sub
    If modFormatCycles.NextCycleIndex("ArrowsD", 2) = 1 Then rng.Worksheet.ClearArrows: Exit Sub
    For Each c In rng.Cells
        c.ShowDependents
    Next c
    Exit Sub
eh:
    ReportError "Show All Dependents"
End Sub

Public Sub XC_ClearArrows()
    On Error Resume Next
    ActiveSheet.ClearArrows
End Sub

'--- Trace in / out ----------------------------------------------------------------
Private Sub PushTrace(ByVal c As Range)
    If mTraceStack Is Nothing Then Set mTraceStack = New Collection
    mTraceStack.Add c
    If mTraceStack.Count > 50 Then mTraceStack.Remove 1
End Sub

' Trace In: jump to the first precedent of the active cell (remembers where you came from).
Public Sub XC_TraceIn()
    On Error GoTo eh
    Dim c As Range, refs As Collection
    If TypeName(Selection) <> "Range" Then Exit Sub
    Set c = ActiveCell
    If Not c.HasFormula Then MsgBox "The active cell has no formula.", vbInformation, APP_NAME: Exit Sub
    Set refs = FormulaReferences(c)
    If refs.Count = 0 Then MsgBox "No references found.", vbInformation, APP_NAME: Exit Sub
    PushTrace c
    If refs.Count = 1 Then JumpTo refs(1) Else XC_PrecedentsList
    Exit Sub
eh:
    ReportError "Trace In"
End Sub

' Trace Out: return to the cell you traced in from.
Public Sub XC_TraceOut()
    On Error GoTo eh
    Dim c As Range
    If mTraceStack Is Nothing Then GoTo none
    If mTraceStack.Count = 0 Then GoTo none
    Set c = mTraceStack(mTraceStack.Count)
    mTraceStack.Remove mTraceStack.Count
    JumpTo c
    Exit Sub
none:
    MsgBox "Nothing to return to.", vbInformation, APP_NAME
    Exit Sub
eh:
    ReportError "Trace Out"
End Sub

'--- Formula Consistency: find formulas that break the pattern of their row/column -------
Public Sub XC_FormulaConsistency()
    On Error GoTo eh
    Dim rng As Range, c As Range, n As Long, mode As Long, result As Range, bad As Boolean
    Set rng = SelRangeOrRegion()
    If rng Is Nothing Then Exit Sub
    mode = AskChoice("Check formula consistency:", Array("Highlight inconsistent formulas (yellow)", "Select inconsistent formulas", "Report only"))
    If mode = 0 Then Exit Sub
    SafeStart "Checking formulas"
    For Each c In rng.Cells
        If c.HasFormula Then
            bad = IsInconsistent(c, rng)
            If bad Then
                n = n + 1
                If mode = 1 Then c.Interior.Color = RGB(255, 255, 0)
                If result Is Nothing Then Set result = c Else Set result = Union(result, c)
            End If
        End If
    Next c
    SafeEnd
    If mode = 2 And Not result Is Nothing Then result.Select
    Done "Formula Consistency: " & Plural(n, "inconsistent formula") & " found (R1C1 pattern differs from both horizontal and vertical neighbours)."
    Exit Sub
eh:
    ReportError "Formula Consistency"
End Sub

' A formula is inconsistent when its R1C1 text differs from BOTH horizontal
' neighbours that have formulas, and from BOTH vertical ones (i.e. it fits no run).
Public Function IsInconsistent(ByVal c As Range, ByVal within As Range) As Boolean
    Dim f As String, l As Boolean, r As Boolean, u As Boolean, d As Boolean, hasH As Boolean, hasV As Boolean
    f = c.FormulaR1C1
    l = NeighbourMatches(c, 0, -1, f, within, hasH)
    r = NeighbourMatches(c, 0, 1, f, within, hasH)
    u = NeighbourMatches(c, -1, 0, f, within, hasV)
    d = NeighbourMatches(c, 1, 0, f, within, hasV)
    If Not hasH And Not hasV Then Exit Function      ' isolated formula: nothing to compare
    IsInconsistent = Not (l Or r Or u Or d)
End Function

Private Function NeighbourMatches(ByVal c As Range, ByVal dr As Long, ByVal dc As Long, ByVal f As String, ByVal within As Range, ByRef hasNeighbour As Boolean) As Boolean
    Dim nb As Range
    On Error Resume Next
    Set nb = c.Offset(dr, dc)
    On Error GoTo 0
    If nb Is Nothing Then Exit Function
    If Intersect(nb, within) Is Nothing Then Exit Function
    If Not nb.HasFormula Then Exit Function
    hasNeighbour = True
    NeighbourMatches = (nb.FormulaR1C1 = f)
End Function

'--- Model audit report -----------------------------------------------------------
Public Sub XC_ModelAudit()
    On Error GoTo eh
    Dim ws As Worksheet, rpt As Worksheet, fr As Range, c As Range, r As Long, nm As Name, cat As String, wb As Workbook, f As String
    Dim nHard As Long, nInc As Long, nErr As Long, nExtLinks As Long, nRef As Long, nHid As Long, sh As Object, scope As Long, shList As Collection, v As Variant
    Set wb = ActiveWorkbook
    scope = AskChoice("Check:", Array("Active sheet", "Whole workbook"))
    If scope = 0 Then Exit Sub
    Set shList = New Collection
    If scope = 1 Then
        shList.Add ActiveSheet
    Else
        For Each ws In wb.Worksheets: shList.Add ws: Next ws
    End If
    SafeStart "Checking model"
    Set rpt = NewReportSheet("Model audit")
    rpt.Range("A1:E1").Value = Array("Check", "Sheet", "Cell", "Formula / detail", "Go")
    rpt.Range("A1:E1").Font.Bold = True
    r = 2
    For Each v In shList
        Set ws = v
        Set fr = Nothing
        On Error Resume Next
        Set fr = ws.UsedRange.SpecialCells(xlCellTypeFormulas)
        On Error GoTo eh
        If Not fr Is Nothing Then
            For Each c In fr.Cells
                f = c.Formula
                If IsError(c.Value) Then
                    AddFinding rpt, r, "Error", ws, c, f: nErr = nErr + 1
                End If
                If InStr(f, "[") > 0 And InStr(f, "]") > 0 Then
                    AddFinding rpt, r, "External link", ws, c, f: nExtLinks = nExtLinks + 1
                End If
                If InStr(f, "#REF") > 0 Then
                    AddFinding rpt, r, "Broken reference", ws, c, f: nRef = nRef + 1
                End If
                If modFormatCycles.HasHardcode(f) Then
                    AddFinding rpt, r, "Hard-coded number in formula", ws, c, f: nHard = nHard + 1
                End If
                If IsInconsistent(c, ws.UsedRange) Then
                    AddFinding rpt, r, "Inconsistent formula", ws, c, f: nInc = nInc + 1
                End If
            Next c
        End If
    Next v
    For Each nm In wb.Names
        If InStr(nm.RefersTo, "#REF") > 0 Then
            rpt.Cells(r, 1).Value = "Name with #REF!": rpt.Cells(r, 2).Value = nm.Name: rpt.Cells(r, 4).Value = "'" & nm.RefersTo
            r = r + 1: nRef = nRef + 1
        End If
    Next nm
    For Each sh In wb.Sheets
        If sh.Visible <> xlSheetVisible Then
            rpt.Cells(r, 1).Value = "Hidden sheet": rpt.Cells(r, 2).Value = sh.Name: rpt.Cells(r, 4).Value = modInfo.VisibleText(sh.Visible)
            r = r + 1: nHid = nHid + 1
        End If
    Next sh
    rpt.Columns("A:E").AutoFit
    If rpt.Columns("D").ColumnWidth > 80 Then rpt.Columns("D").ColumnWidth = 80
    rpt.Range("G1:H1").Value = Array("Summary", "")
    rpt.Range("G1:H1").Font.Bold = True
    rpt.Range("G2:H7").Value = Application.Transpose(Application.Transpose(Array( _
        Array("Errors", nErr), Array("External links", nExtLinks), Array("Broken references", nRef), _
        Array("Hard-coded numbers", nHard), Array("Inconsistent formulas", nInc), Array("Hidden sheets", nHid))))
    rpt.Columns("G:H").AutoFit
    SafeEnd
    Done "Model Audit: " & (r - 2) & " findings. Errors " & nErr & ", external links " & nExtLinks & ", broken refs " & nRef & ", hard-codes " & nHard & ", inconsistent " & nInc & ", hidden sheets " & nHid & "."
    Exit Sub
eh:
    ReportError "Model Audit"
End Sub

Private Sub AddFinding(ByVal rpt As Worksheet, ByRef r As Long, ByVal cat As String, ByVal ws As Worksheet, ByVal c As Range, ByVal f As String)
    rpt.Cells(r, 1).Value = cat
    rpt.Cells(r, 2).Value = ws.Name
    rpt.Cells(r, 3).Value = c.Address(False, False)
    rpt.Cells(r, 4).Value = "'" & f
    On Error Resume Next
    rpt.Hyperlinks.Add Anchor:=rpt.Cells(r, 5), Address:=ws.Parent.FullName, SubAddress:="'" & ws.Name & "'!" & c.Address(False, False), TextToDisplay:="go"
    On Error GoTo 0
    r = r + 1
End Sub
