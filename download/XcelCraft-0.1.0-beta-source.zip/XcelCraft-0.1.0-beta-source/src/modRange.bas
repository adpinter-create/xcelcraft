Attribute VB_Name = "modRange"
'==============================================================================
' SPDX-License-Identifier: MIT
' XcelCraft - modRange
' Range category. Original implementation.
' (Advanced Find & Replace, Sort Inside Cell, Values->Formatted live in
'  modText/modNumbersDates; Split Range lives in modSheets.)
'==============================================================================
Option Explicit

' Source range remembered by "Copy for XcelCraft paste" so the exact/duplicate/
' link paste tools know what was copied (VBA cannot read the Excel clipboard source).
Public gCopySource As Range

'--- Advanced sorting ---------------------------------------------------------
Public Sub XC_AdvancedSorting()
    On Error GoTo eh
    Dim rng As Range, mode As Long, hdr As Boolean, col As Variant, i As Long, r As Long, ws As Worksheet
    Dim keyCol As Range, tmpCol As Long, c As Range, k As Variant, desc As Boolean, dataR As Range, firstRow As Long
    Set rng = SelRangeOrRegion()
    If rng Is Nothing Then Exit Sub
    If rng.Areas.Count > 1 Then MsgBox "Please select one rectangular range.", vbExclamation, APP_NAME: Exit Sub
    Set ws = rng.Worksheet
    mode = AskChoice("Sort the rows of " & rng.Address(False, False) & " by:", Array( _
        "Cell fill color", "Font color", "Text length", "Numeric value inside the text (e.g. 'Item 12')", _
        "Last word", "Last character", "Reverse the current order", "Natural order (Sheet2 before Sheet10)", "Random order"))
    If mode = 0 Then Exit Sub
    hdr = AskYesNo("Does the first row contain headers (not sorted)?")
    firstRow = IIf(hdr, 2, 1)
    If rng.Rows.Count <= firstRow - 1 Then Exit Sub
    If mode <> 7 And mode <> 9 Then
        col = AskNumber("Which column of the range holds the sort key? (1 = first column)", 1, "Advanced Sorting", 1, rng.Columns.Count)
        If IsEmpty(col) Then Exit Sub
        desc = (AskChoice("Order:", Array("Ascending", "Descending")) = 2)
    End If
    SnapshotRange rng, "Advanced Sorting", True
    SafeStart "Sorting"
    ' helper column right after the used range
    tmpCol = Max2(ws.UsedRange.Column + ws.UsedRange.Columns.Count, rng.Column + rng.Columns.Count) + 1
    Set keyCol = ws.Range(ws.Cells(rng.Row, tmpCol), ws.Cells(rng.Row + rng.Rows.Count - 1, tmpCol))
    Randomize
    For r = 1 To rng.Rows.Count
        Set c = rng.Cells(r, IIf(IsEmpty(col), 1, col))
        Select Case mode
            Case 1: k = c.Interior.Color
            Case 2: k = c.Font.Color
            Case 3: k = Len(c.Text)
            Case 4: k = FirstNumberIn(c.Text)
            Case 5: k = LastWord(c.Text)
            Case 6: k = Right$(c.Text, 1)
            Case 7: k = -r
            Case 8: k = NaturalKey(c.Text)
            Case 9: k = Rnd()
        End Select
        keyCol.Cells(r, 1).Value = k
    Next r
    If hdr Then keyCol.Cells(1, 1).Value = IIf(VarType(keyCol.Cells(2, 1).Value) = vbString, "", -1E+300)
    Set dataR = ws.Range(rng.Cells(1, 1), keyCol.Cells(rng.Rows.Count, 1))
    dataR.Sort Key1:=keyCol.Cells(1, 1), Order1:=IIf(desc, xlDescending, xlAscending), Header:=IIf(hdr, xlYes, xlNo), MatchCase:=False, Orientation:=xlTopToBottom
    keyCol.Clear
    rng.Select
    SafeEnd
    Done "Advanced Sorting: done."
    Exit Sub
eh:
    ReportError "Advanced Sorting"
End Sub

Private Function FirstNumberIn(ByVal s As String) As Double
    Dim i As Long, ch As String, num As String, started As Boolean
    For i = 1 To Len(s)
        ch = Mid$(s, i, 1)
        If IsDigitChar(ch) Or (started And (ch = "." Or ch = ",")) Then
            num = num & IIf(ch = ",", "", ch): started = True
        ElseIf started Then
            Exit For
        End If
    Next i
    If Len(num) > 0 Then FirstNumberIn = Val(num)
End Function

Private Function LastWord(ByVal s As String) As String
    Dim p As Long
    s = Trim$(s)
    p = InStrRev(s, " ")
    If p > 0 Then LastWord = Mid$(s, p + 1) Else LastWord = s
End Function

' Pads digit runs to 12 chars so a text sort becomes a natural sort.
Private Function NaturalKey(ByVal s As String) As String
    Dim i As Long, ch As String, num As String, out As String
    For i = 1 To Len(s) + 1
        If i <= Len(s) Then ch = Mid$(s, i, 1) Else ch = ""
        If IsDigitChar(ch) Then
            num = num & ch
        Else
            If Len(num) > 0 Then out = out & Right$(String$(12, "0") & num, 12): num = ""
            out = out & LCase$(ch)
        End If
    Next i
    NaturalKey = out
End Function

Public Sub XC_SortRandom()
    On Error GoTo eh
    Dim rng As Range, ws As Worksheet, tmpCol As Long, keyCol As Range, r As Long, dataR As Range
    Set rng = SelRangeOrRegion()
    If rng Is Nothing Then Exit Sub
    If rng.Areas.Count > 1 Then MsgBox "Please select one rectangular range.", vbExclamation, APP_NAME: Exit Sub
    Set ws = rng.Worksheet
    SnapshotRange rng, "Sort in Random Order", True
    SafeStart "Shuffling"
    tmpCol = Max2(ws.UsedRange.Column + ws.UsedRange.Columns.Count, rng.Column + rng.Columns.Count) + 1
    Set keyCol = ws.Range(ws.Cells(rng.Row, tmpCol), ws.Cells(rng.Row + rng.Rows.Count - 1, tmpCol))
    Randomize
    For r = 1 To rng.Rows.Count: keyCol.Cells(r, 1).Value = Rnd(): Next r
    Set dataR = ws.Range(rng.Cells(1, 1), keyCol.Cells(rng.Rows.Count, 1))
    dataR.Sort Key1:=keyCol.Cells(1, 1), Order1:=xlAscending, Header:=xlNo, Orientation:=xlTopToBottom
    keyCol.Clear
    rng.Select
    SafeEnd
    Exit Sub
eh:
    ReportError "Sort in Random Order"
End Sub

'--- Flip ----------------------------------------------------------------------
Public Sub XC_FlipCells()
    On Error GoTo eh
    Dim rng As Range, mode As Long, arr As Variant, out As Variant, r As Long, c As Long, nr As Long, nc As Long
    Set rng = SelRange(True)
    If rng Is Nothing Then Exit Sub
    If rng.Areas.Count > 1 Then MsgBox "Please select one rectangular range.", vbExclamation, APP_NAME: Exit Sub
    mode = AskChoice("Flip the selected cells:", Array("Vertically (first row becomes last)", "Horizontally (first column becomes last)"))
    If mode = 0 Then Exit Sub
    SnapshotRange rng, "Flip Cells"
    SafeStart
    arr = RangeToArray(rng, True)
    nr = UBound(arr, 1): nc = UBound(arr, 2)
    ReDim out(1 To nr, 1 To nc)
    For r = 1 To nr
        For c = 1 To nc
            If mode = 1 Then out(nr - r + 1, c) = arr(r, c) Else out(r, nc - c + 1) = arr(r, c)
        Next c
    Next r
    rng.Formula = out
    SafeEnd
    Exit Sub
eh:
    ReportError "Flip Selected Cells"
End Sub

'--- Scroll ------------------------------------------------------------------
Public Sub XC_ScrollTopLeft()
    On Error Resume Next
    If TypeName(Selection) <> "Range" Then Exit Sub
    ActiveWindow.ScrollRow = Selection.Row
    ActiveWindow.ScrollColumn = Selection.Column
End Sub

Public Sub XC_ScrollCenter()
    On Error Resume Next
    Dim vr As Range, rowsVis As Long, colsVis As Long
    If TypeName(Selection) <> "Range" Then Exit Sub
    Set vr = ActiveWindow.VisibleRange
    rowsVis = vr.Rows.Count: colsVis = vr.Columns.Count
    ActiveWindow.ScrollRow = Max2(1, Selection.Row + Selection.Rows.Count \ 2 - rowsVis \ 2)
    ActiveWindow.ScrollColumn = Max2(1, Selection.Column + Selection.Columns.Count \ 2 - colsVis \ 2)
End Sub

'--- Errors ---------------------------------------------------------------------
Public Sub XC_ReplaceErrors()
    On Error GoTo eh
    Dim rng As Range, c As Range, msg As String, mode As Long, n As Long, f As String, lit As String
    Set rng = SelRange()
    If rng Is Nothing Then Exit Sub
    mode = AskChoice("Formula errors in the selection:", Array( _
        "Wrap formulas in IFERROR(formula, message) - keeps the formula", _
        "Replace the error VALUE with the message (formula is lost in those cells)", _
        "Clear cells that show an error"))
    If mode = 0 Then Exit Sub
    If mode <> 3 Then
        msg = AskText("Replacement value or message (numbers are used as numbers, text as text):", "", "Replace Formula Errors")
        If StrPtr(msg) = 0 Then Exit Sub
    End If
    If IsNumeric(msg) And Len(msg) > 0 Then lit = msg Else lit = """" & Replace(msg, """", """""") & """"
    SnapshotRange rng, "Replace Formula Errors"
    SafeStart "Replacing errors"
    For Each c In rng.Cells
        If mode = 1 Then
            If c.HasFormula Then
                f = c.Formula
                If UCase$(Left$(f, 9)) <> "=IFERROR(" Then
                    c.Formula = "=IFERROR(" & Mid$(f, 2) & "," & lit & ")"
                    n = n + 1
                End If
            End If
        ElseIf IsError(c.Value) Then
            If mode = 2 Then
                If IsNumeric(msg) And Len(msg) > 0 Then c.Value = CDbl(msg) Else c.Value = msg
            Else
                c.ClearContents
            End If
            n = n + 1
        End If
    Next c
    SafeEnd
    Done "Replace Formula Errors: " & Plural(n, "cell") & " changed."
    Exit Sub
eh:
    ReportError "Replace Formula Errors"
End Sub

'--- Paste tools ----------------------------------------------------------------
Public Sub XC_CopySource()
    On Error GoTo eh
    Dim rng As Range
    Set rng = SelRange()
    If rng Is Nothing Then Exit Sub
    Set gCopySource = rng
    rng.Copy
    Application.StatusBar = APP_NAME & ": " & rng.Address(False, False) & " copied. Now select the target and run an XcelCraft paste tool."
    Exit Sub
eh:
    ReportError "Copy for XcelCraft Paste"
End Sub

' Returns the source range: the one remembered by XC_CopySource, else asks.
Public Function GetCopySource() As Range
    On Error Resume Next
    If Not gCopySource Is Nothing Then
        If Len(gCopySource.Address) > 0 And Application.CutCopyMode <> False Then
            Set GetCopySource = gCopySource
            Exit Function
        End If
    End If
    On Error GoTo 0
    Set GetCopySource = AskRange("Select the SOURCE range to copy from (tip: use 'Copy for XcelCraft Paste' first to skip this prompt):")
End Function

Public Sub XC_PasteSpecialCombined()
    On Error GoTo eh
    Dim opts As String, tgt As Range
    If TypeName(Selection) <> "Range" Then Exit Sub
    If Application.CutCopyMode = False Then MsgBox "Copy a range first (Ctrl+C).", vbInformation, APP_NAME: Exit Sub
    opts = AskText("Paste special, combining several options. Enter the numbers separated by commas:" & vbCrLf & vbCrLf & _
                   "1. Values" & vbCrLf & "2. Formulas" & vbCrLf & "3. Number formats" & vbCrLf & "4. All formatting" & vbCrLf & _
                   "5. Column widths" & vbCrLf & "6. Comments/notes" & vbCrLf & "7. Data validation" & vbCrLf & "8. Transpose (with 1 or 2)", _
                   "1,3,5", "Paste Special Combined")
    If Len(opts) = 0 Then Exit Sub
    opts = "," & Replace(opts, " ", "") & ","
    Set tgt = Selection
    SafeStart "Pasting"
    If InStr(opts, ",5,") > 0 Then tgt.PasteSpecial xlPasteColumnWidths
    If InStr(opts, ",4,") > 0 Then tgt.PasteSpecial xlPasteFormats
    If InStr(opts, ",2,") > 0 Then tgt.PasteSpecial xlPasteFormulas, Transpose:=(InStr(opts, ",8,") > 0)
    If InStr(opts, ",1,") > 0 Then tgt.PasteSpecial xlPasteValues, Transpose:=(InStr(opts, ",8,") > 0)
    If InStr(opts, ",3,") > 0 Then tgt.PasteSpecial xlPasteFormats ' number formats come with formats; refine below
    If InStr(opts, ",6,") > 0 Then tgt.PasteSpecial xlPasteComments
    If InStr(opts, ",7,") > 0 Then tgt.PasteSpecial xlPasteValidation
    SafeEnd
    Exit Sub
eh:
    ReportError "Paste Special Combined"
End Sub

Public Sub XC_PasteValuesAndFormatting()
    On Error GoTo eh
    If TypeName(Selection) <> "Range" Then Exit Sub
    If Application.CutCopyMode = False Then MsgBox "Copy a range first (Ctrl+C).", vbInformation, APP_NAME: Exit Sub
    Selection.PasteSpecial xlPasteValuesAndNumberFormats
    Selection.PasteSpecial xlPasteFormats
    Exit Sub
eh:
    ReportError "Paste Values and Formatting"
End Sub

Public Sub XC_PasteValuesNoFormatting()
    On Error GoTo eh
    If TypeName(Selection) <> "Range" Then Exit Sub
    If Application.CutCopyMode = False Then MsgBox "Copy a range first (Ctrl+C).", vbInformation, APP_NAME: Exit Sub
    Selection.PasteSpecial xlPasteValues
    Exit Sub
eh:
    ReportError "Paste Values Without Formatting"
End Sub

Public Sub XC_CopyVisibleToVisible()
    On Error GoTo eh
    Dim src As Range, tgt As Range, sv As Range, tv As Range, sc As Range, tc As Range, i As Long, n As Long, srcCells As Collection, tgtCells As Collection
    Set src = SelRange()
    If src Is Nothing Then Exit Sub
    Set tgt = AskRange("Select the TARGET range (its hidden rows/columns are skipped too). Only the top-left cell matters if it is a single cell:")
    If tgt Is Nothing Then Exit Sub
    On Error Resume Next
    Set sv = src.SpecialCells(xlCellTypeVisible)
    On Error GoTo eh
    If sv Is Nothing Then Exit Sub
    If tgt.Cells.CountLarge = 1 Then Set tgt = tgt.Resize(src.Rows.Count * 4, src.Columns.Count * 4)
    On Error Resume Next
    Set tv = tgt.SpecialCells(xlCellTypeVisible)
    On Error GoTo eh
    If tv Is Nothing Then Exit Sub
    SafeStart "Copying visible cells"
    ' walk both visible sets in reading order
    Set srcCells = New Collection: Set tgtCells = New Collection
    For Each sc In sv.Cells: srcCells.Add sc: Next sc
    For Each tc In tv.Cells: tgtCells.Add tc: Next tc
    For i = 1 To Min2(srcCells.Count, tgtCells.Count)
        srcCells(i).Copy tgtCells(i)
        n = n + 1
    Next i
    SafeEnd
    Done "Copy Visible to Visible: " & Plural(n, "cell") & " copied."
    Exit Sub
eh:
    ReportError "Copy Visible Cells to Visible Cells"
End Sub

' Bakes conditional-format appearance into real formatting (Excel 2010+ DisplayFormat).
Public Sub XC_FreezeConditionalFormatting()
    On Error GoTo eh
    Dim rng As Range, c As Range, n As Long, ic As Long, fc As Long, b As Boolean, it As Boolean, nf As String, e As Variant
    Dim bs(1 To 4) As Long, bw(1 To 4) As Long, bc(1 To 4) As Long, i As Long, edges As Variant, hasCF As Boolean, pat As Long
    Set rng = SelRange()
    If rng Is Nothing Then Exit Sub
    If rng.FormatConditions.Count = 0 Then
        hasCF = False
        For Each c In rng.Cells
            If c.FormatConditions.Count > 0 Then hasCF = True: Exit For
        Next c
        If Not hasCF Then MsgBox "The selection has no conditional formatting.", vbInformation, APP_NAME: Exit Sub
    End If
    edges = Array(xlEdgeLeft, xlEdgeTop, xlEdgeBottom, xlEdgeRight)
    SafeStart "Freezing conditional formatting"
    For Each c In rng.Cells
        If c.FormatConditions.Count > 0 Then
            With c.DisplayFormat
                ic = .Interior.Color: pat = .Interior.Pattern
                fc = .Font.Color: b = .Font.Bold: it = .Font.Italic: nf = .NumberFormat
                For i = 1 To 4
                    bs(i) = .Borders(edges(i - 1)).LineStyle: bw(i) = .Borders(edges(i - 1)).Weight: bc(i) = .Borders(edges(i - 1)).Color
                Next i
            End With
            c.FormatConditions.Delete
            If pat = xlNone Then c.Interior.ColorIndex = xlColorIndexNone Else c.Interior.Color = ic
            c.Font.Color = fc: c.Font.Bold = b: c.Font.Italic = it
            c.NumberFormat = nf
            For i = 1 To 4
                If bs(i) = xlNone Then
                    c.Borders(edges(i - 1)).LineStyle = xlNone
                Else
                    c.Borders(edges(i - 1)).LineStyle = bs(i): c.Borders(edges(i - 1)).Weight = bw(i): c.Borders(edges(i - 1)).Color = bc(i)
                End If
            Next i
            n = n + 1
        End If
    Next c
    SafeEnd
    Done "Freeze Conditional Formatting: " & Plural(n, "cell") & " converted to static formatting."
    Exit Sub
eh:
    ReportError "Freeze Conditional Formatting"
End Sub

' Copies formulas as text so references are NOT adjusted.
Public Sub XC_CopyFormulasExact()
    On Error GoTo eh
    Dim src As Range, tgt As Range
    Set src = GetCopySource()
    If src Is Nothing Then Exit Sub
    If TypeName(Selection) <> "Range" Then Exit Sub
    Set tgt = Selection.Cells(1).Resize(src.Rows.Count, src.Columns.Count)
    SnapshotRange tgt, "Copy Formulas Exactly"
    SafeStart "Copying formulas"
    tgt.Formula = RangeToArray(src, True)
    src.Copy
    tgt.PasteSpecial xlPasteFormats
    Application.CutCopyMode = False
    tgt.Select
    SafeEnd
    Exit Sub
eh:
    ReportError "Copy Formulas Without Changing References"
End Sub

' Moves VALUES to the target and clears the source without re-pointing dependents.
Public Sub XC_CutPasteAsValues()
    On Error GoTo eh
    Dim src As Range, tgt As Range
    Set src = SelRange()
    If src Is Nothing Then Exit Sub
    Set tgt = AskRange("Select the top-left cell of the target:")
    If tgt Is Nothing Then Exit Sub
    Set tgt = tgt.Cells(1).Resize(src.Rows.Count, src.Columns.Count)
    SafeStart "Moving as values"
    tgt.Value = src.Value
    src.Copy
    tgt.PasteSpecial xlPasteFormats
    Application.CutCopyMode = False
    src.ClearContents
    tgt.Select
    SafeEnd
    Exit Sub
eh:
    ReportError "Cut and Paste as Values"
End Sub

' Pastes every area of a multi-area selection one under the other at the target.
Public Sub XC_CopyMultipleRanges()
    On Error GoTo eh
    Dim src As Range, tgt As Range, a As Range, pos As Long, mode As Long, n As Long
    Set src = SelRange()
    If src Is Nothing Then Exit Sub
    mode = AskChoice("Paste the " & src.Areas.Count & " selected area(s):", Array("Stacked vertically at the target", "Side by side at the target"))
    If mode = 0 Then Exit Sub
    Set tgt = AskRange("Select the top-left cell of the target:")
    If tgt Is Nothing Then Exit Sub
    Set tgt = tgt.Cells(1)
    SafeStart "Pasting"
    pos = 0
    For Each a In src.Areas
        a.Copy
        If mode = 1 Then
            tgt.Offset(pos, 0).PasteSpecial xlPasteAll
            pos = pos + a.Rows.Count
        Else
            tgt.Offset(0, pos).PasteSpecial xlPasteAll
            pos = pos + a.Columns.Count
        End If
        n = n + 1
    Next a
    Application.CutCopyMode = False
    SafeEnd
    Done "Copy and Paste Multiple Ranges: " & Plural(n, "area") & " pasted."
    Exit Sub
eh:
    ReportError "Copy and Paste Multiple Ranges"
End Sub

' Transposes while keeping formula text identical.
Public Sub XC_TransposeExact()
    On Error GoTo eh
    Dim src As Range, tgt As Range, arr As Variant, out As Variant, r As Long, c As Long
    Set src = GetCopySource()
    If src Is Nothing Then Exit Sub
    If TypeName(Selection) <> "Range" Then Exit Sub
    Set tgt = Selection.Cells(1).Resize(src.Columns.Count, src.Rows.Count)
    SnapshotRange tgt, "Transpose Exact"
    SafeStart "Transposing"
    arr = RangeToArray(src, True)
    ReDim out(1 To UBound(arr, 2), 1 To UBound(arr, 1))
    For r = 1 To UBound(arr, 1)
        For c = 1 To UBound(arr, 2)
            out(c, r) = arr(r, c)
        Next c
    Next r
    tgt.Formula = out
    tgt.Select
    Application.CutCopyMode = False
    SafeEnd
    Exit Sub
eh:
    ReportError "Copy and Transpose Without Changing References"
End Sub

'--- Duplicates -------------------------------------------------------------------
Public Sub XC_ClearDuplicates()
    On Error GoTo eh
    Dim rng As Range, c As Range, seen As Collection, k As String, n As Long, matchCase As Boolean
    Set rng = SelRange()
    If rng Is Nothing Then Exit Sub
    matchCase = AskYesNo("Treat 'Apple' and 'apple' as different values (match case)?", False)
    SnapshotRange rng, "Clear Duplicate Values"
    SafeStart "Clearing duplicates"
    Set seen = New Collection
    For Each c In rng.Cells
        If Not IsEmpty(c.Value) Then
            k = CStr(c.Value)
            If Not matchCase Then k = LCase$(k)
            If InCollection(seen, "k" & k) Then
                c.ClearContents: n = n + 1
            Else
                seen.Add 1, "k" & k
            End If
        End If
    Next c
    SafeEnd
    Done "Clear Duplicate Values: " & Plural(n, "duplicate") & " cleared (first occurrence kept)."
    Exit Sub
eh:
    ReportError "Clear Duplicate Values"
End Sub

Public Sub XC_CountDuplicates()
    On Error GoTo eh
    Dim rng As Range, c As Range, k As String, n As Long, mode As Long, dupSets As Long, cnt As Long
    Dim firstCells As Collection, v As Variant
    Set rng = SelRange()
    If rng Is Nothing Then Exit Sub
    mode = AskChoice("Count duplicate values in the selection:", Array( _
        "Show a summary only", "Write the count of each value in the column to the RIGHT of the selection", "Summary + color cells that occur more than once"))
    If mode = 0 Then Exit Sub
    SafeStart "Counting duplicates"
    Set firstCells = New Collection
    For Each c In rng.Cells
        If Not IsEmpty(c.Value) Then
            k = "k" & LCase$(CStr(c.Value))
            If Not InCollection(firstCells, k) Then firstCells.Add c, k
            cnt = Application.WorksheetFunction.CountIf(rng, c.Value)
            If cnt > 1 Then
                n = n + 1
                If mode = 3 Then c.Interior.Color = RGB(255, 199, 206)
            End If
            If mode = 2 Then c.Offset(0, rng.Columns.Count).Value = cnt
        End If
    Next c
    For Each v In firstCells
        If Application.WorksheetFunction.CountIf(rng, v.Value) > 1 Then dupSets = dupSets + 1
    Next v
    SafeEnd
    Done "Count Duplicate Values:" & vbCrLf & firstCells.Count & " distinct values" & vbCrLf & dupSets & " values occur more than once" & vbCrLf & n & " cells are part of a duplicate set."
    Exit Sub
eh:
    ReportError "Count Duplicate Values"
End Sub

Public Sub XC_HighlightDuplicateSets()
    On Error GoTo eh
    Dim rng As Range, c As Range, k As String, keys As Collection, colorOf As Collection, palette As Variant, n As Long, sets As Long, idx As Long
    Set rng = SelRange()
    If rng Is Nothing Then Exit Sub
    SafeStart "Highlighting duplicates"
    palette = Array(RGB(255, 199, 206), RGB(198, 239, 206), RGB(255, 235, 156), RGB(189, 215, 238), RGB(226, 207, 245), RGB(255, 204, 153), _
                    RGB(204, 255, 255), RGB(255, 153, 204), RGB(204, 204, 255), RGB(204, 255, 204), RGB(255, 255, 153), RGB(220, 220, 220))
    Set keys = New Collection
    ' first pass: count
    For Each c In rng.Cells
        If Not IsEmpty(c.Value) Then
            k = "k" & LCase$(CStr(c.Value))
            On Error Resume Next
            keys.Add 0, k
            On Error GoTo eh
        End If
    Next c
    ' count occurrences via COUNTIF-like second pass
    Set colorOf = New Collection
    For Each c In rng.Cells
        If Not IsEmpty(c.Value) Then
            k = "k" & LCase$(CStr(c.Value))
            If Application.WorksheetFunction.CountIf(rng, c.Value) > 1 Then
                If Not InCollection(colorOf, k) Then
                    colorOf.Add palette(sets Mod (UBound(palette) + 1)), k
                    sets = sets + 1
                End If
                c.Interior.Color = colorOf(k)
                n = n + 1
            End If
        End If
    Next c
    SafeEnd
    Done "Highlight Duplicates: " & Plural(sets, "set") & " of duplicates found, " & Plural(n, "cell") & " colored."
    Exit Sub
eh:
    ReportError "Highlight Each Set of Duplicates"
End Sub

'--- Named ranges -------------------------------------------------------------------
Public Sub XC_ListNames()
    On Error GoTo eh
    Dim ws As Worksheet, nm As Name, r As Long, lo As ListObject, sh As Worksheet, v As String
    SafeStart "Listing names"
    Set ws = NewReportSheet("Names")
    ws.Range("A1:E1").Value = Array("Name", "Refers to", "Scope", "Visible", "Value / rows")
    ws.Range("A1:E1").Font.Bold = True
    r = 2
    For Each nm In ActiveWorkbook.Names
        ws.Cells(r, 1).Value = nm.Name
        ws.Cells(r, 2).Value = "'" & nm.RefersTo
        On Error Resume Next
        ws.Cells(r, 3).Value = "Workbook"
        If InStr(nm.Name, "!") > 0 Then ws.Cells(r, 3).Value = Left$(nm.Name, InStr(nm.Name, "!") - 1)
        ws.Cells(r, 4).Value = nm.Visible
        v = ""
        v = CStr(nm.RefersToRange.Cells(1).Value)
        ws.Cells(r, 5).Value = v
        On Error GoTo eh
        r = r + 1
    Next nm
    For Each sh In ActiveWorkbook.Worksheets
        For Each lo In sh.ListObjects
            ws.Cells(r, 1).Value = lo.Name
            ws.Cells(r, 2).Value = "'" & lo.Range.Address(External:=True)
            ws.Cells(r, 3).Value = "Table on " & sh.Name
            ws.Cells(r, 4).Value = True
            ws.Cells(r, 5).Value = lo.ListRows.Count & " rows"
            r = r + 1
        Next lo
    Next sh
    ws.Columns("A:E").AutoFit
    SafeEnd
    Done "List Names: " & Plural(r - 2, "entry", "entries") & " listed."
    Exit Sub
eh:
    ReportError "List All Named Ranges and Tables"
End Sub

' Replace range names in formulas with their cell references (also 'Unapply Names').
Public Sub XC_ReplaceNamesWithRefs()
    On Error GoTo eh
    Dim rng As Range, c As Range, nm As Name, n As Long, f As String, nf As String, ref As String, scope As Long
    scope = AskChoice("Replace named ranges with cell references in:", Array("Selected cells", "Active sheet", "Whole workbook"))
    If scope = 0 Then Exit Sub
    If scope = 1 Then Set rng = SelRange(): If rng Is Nothing Then Exit Sub
    SafeStart "Replacing names"
    If scope = 1 Then
        n = UnapplyNamesIn(rng)
    ElseIf scope = 2 Then
        n = UnapplyNamesIn(ActiveSheet.UsedRange)
    Else
        Dim ws As Worksheet
        For Each ws In ActiveWorkbook.Worksheets: n = n + UnapplyNamesIn(ws.UsedRange): Next ws
    End If
    SafeEnd
    Done "Replace Named Ranges: " & Plural(n, "formula") & " updated."
    Exit Sub
eh:
    ReportError "Replace Named Ranges in Formulas"
End Sub

Public Function UnapplyNamesIn(ByVal rng As Range) As Long
    Dim fr As Range, c As Range, nm As Name, f As String, nf As String, ref As String, n As Long, shortName As String
    On Error Resume Next
    Set fr = rng.SpecialCells(xlCellTypeFormulas)
    On Error GoTo 0
    If fr Is Nothing Then Exit Function
    For Each c In fr.Cells
        f = c.Formula: nf = f
        For Each nm In ActiveWorkbook.Names
            shortName = nm.Name
            If InStr(shortName, "!") > 0 Then shortName = Mid$(shortName, InStr(shortName, "!") + 1)
            If InStr(1, nf, shortName, vbTextCompare) > 0 Then
                On Error Resume Next
                ref = ""
                ref = nm.RefersToRange.Address(External:=False)
                If Len(ref) > 0 Then
                    If nm.RefersToRange.Worksheet.Name <> c.Worksheet.Name Then ref = "'" & nm.RefersToRange.Worksheet.Name & "'!" & ref
                    nf = ReplaceWholeWord(nf, shortName, ref)
                End If
                On Error GoTo 0
            End If
        Next nm
        If nf <> f Then
            On Error Resume Next
            c.Formula = nf
            If Err.Number = 0 Then n = n + 1
            Err.Clear
            On Error GoTo 0
        End If
    Next c
    UnapplyNamesIn = n
End Function

' Replace whole-word occurrences of a name in a formula (outside quotes).
Public Function ReplaceWholeWord(ByVal f As String, ByVal word As String, ByVal repl As String) As String
    Dim i As Long, inQ As Boolean, out As String, L As Long, before As String, after As String
    L = Len(word)
    i = 1
    Do While i <= Len(f)
        If Mid$(f, i, 1) = """" Then inQ = Not inQ
        If Not inQ And StrComp(Mid$(f, i, L), word, vbTextCompare) = 0 Then
            before = IIf(i > 1, Mid$(f, i - 1, 1), " ")
            after = IIf(i + L <= Len(f), Mid$(f, i + L, 1), " ")
            If Not (IsLetter(before) Or IsDigitChar(before) Or before = "_" Or before = "." Or before = "!" Or before = "$") And _
               Not (IsLetter(after) Or IsDigitChar(after) Or after = "_" Or after = "." Or after = "(" Or after = "!") Then
                out = out & repl
                i = i + L
                GoTo nxt
            End If
        End If
        out = out & Mid$(f, i, 1)
        i = i + 1
nxt:
    Loop
    ReplaceWholeWord = out
End Function

Public Sub XC_DeleteNamesInSelection()
    On Error GoTo eh
    Dim rng As Range, nm As Name, n As Long, i As Long, rr As Range
    Set rng = SelRange()
    If rng Is Nothing Then Exit Sub
    For i = ActiveWorkbook.Names.Count To 1 Step -1
        Set nm = ActiveWorkbook.Names(i)
        Set rr = Nothing
        On Error Resume Next
        Set rr = nm.RefersToRange
        On Error GoTo eh
        If Not rr Is Nothing Then
            If rr.Worksheet.Name = rng.Worksheet.Name Then
                If Not Intersect(rr, rng) Is Nothing Then nm.Delete: n = n + 1
            End If
        End If
    Next i
    Done "Delete Names in Selection: " & Plural(n, "name") & " deleted."
    Exit Sub
eh:
    ReportError "Delete Defined Names in Selection"
End Sub

Public Sub XC_DeleteAllNames()
    On Error GoTo eh
    Dim i As Long, n As Long
    If ActiveWorkbook.Names.Count = 0 Then MsgBox "The workbook has no defined names.", vbInformation, APP_NAME: Exit Sub
    If Not AskYesNo("Delete ALL " & ActiveWorkbook.Names.Count & " defined names in this workbook? Formulas that use them will show #NAME?.", False) Then Exit Sub
    For i = ActiveWorkbook.Names.Count To 1 Step -1
        On Error Resume Next
        ActiveWorkbook.Names(i).Delete
        If Err.Number = 0 Then n = n + 1
        Err.Clear
        On Error GoTo eh
    Next i
    Done "Delete All Names: " & Plural(n, "name") & " deleted."
    Exit Sub
eh:
    ReportError "Delete All Defined Names"
End Sub

Public Sub XC_DeleteInvalidNames()
    On Error GoTo eh
    Dim i As Long, n As Long
    For i = ActiveWorkbook.Names.Count To 1 Step -1
        If InStr(ActiveWorkbook.Names(i).RefersTo, "#REF") > 0 Then
            ActiveWorkbook.Names(i).Delete: n = n + 1
        End If
    Next i
    Done "Delete Names with #REF!: " & Plural(n, "name") & " deleted."
    Exit Sub
eh:
    ReportError "Delete Named Ranges with Invalid References"
End Sub
