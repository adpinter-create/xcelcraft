Attribute VB_Name = "modFormulas"
'==============================================================================
' SPDX-License-Identifier: MIT
' XcelCraft - modFormulas
' Formulas category (utility side). Original implementation.
'==============================================================================
Option Explicit

'--- Reference style -------------------------------------------------------------
' Converts every reference in the selected formulas to a chosen anchoring.
Public Sub XC_ChangeReferenceStyle()
    On Error GoTo eh
    Dim rng As Range, mode As Long
    Set rng = SelRange()
    If rng Is Nothing Then Exit Sub
    mode = AskChoice("Change all cell references in the selected formulas to:", Array( _
        "Relative  (A1)", "Absolute  ($A$1)", "Absolute row  (A$1)", "Absolute column  ($A1)"))
    If mode = 0 Then Exit Sub
    SnapshotRange rng, "Change Reference Style"
    SafeStart "Converting references"
    Dim n As Long
    n = ConvertRefsIn(rng, Choose(mode, xlRelative, xlAbsolute, xlAbsRowRelColumn, xlRelRowAbsColumn))
    SafeEnd
    Done "Change Formula Reference Style: " & Plural(n, "formula") & " converted."
    Exit Sub
eh:
    ReportError "Change Formula Reference Style"
End Sub

Public Function ConvertRefsIn(ByVal rng As Range, ByVal refMode As XlReferenceType) As Long
    Dim fr As Range, c As Range, nf As String, n As Long
    On Error Resume Next
    Set fr = rng.SpecialCells(xlCellTypeFormulas)
    On Error GoTo 0
    If fr Is Nothing Then Exit Function
    For Each c In fr.Cells
        On Error Resume Next
        nf = Application.ConvertFormula(c.Formula, xlA1, xlA1, refMode, c)
        If Err.Number = 0 And nf <> c.Formula Then
            If c.HasArray Then c.FormulaArray = nf Else c.Formula = nf
            If Err.Number = 0 Then n = n + 1
        End If
        Err.Clear
        On Error GoTo 0
    Next c
    ConvertRefsIn = n
End Function

'--- CSE / text formulas -------------------------------------------------------------
Public Sub XC_ReapplyCSE()
    On Error GoTo eh
    Dim rng As Range, c As Range, n As Long, f As String, mode As Long
    Set rng = SelRange()
    If rng Is Nothing Then Exit Sub
    mode = AskChoice("Array formulas (Ctrl+Shift+Enter):", Array( _
        "Re-enter existing array formulas in the selection as array formulas", _
        "Convert ALL formulas in the selection to array formulas (each cell individually)"))
    If mode = 0 Then Exit Sub
    SnapshotRange rng, "Reapply CSE"
    SafeStart "Applying array formulas"
    For Each c In rng.Cells
        If c.HasFormula Then
            If c.HasArray Then
                If c.CurrentArray.Cells(1).Address = c.Address Then
                    f = c.FormulaArray
                    c.CurrentArray.FormulaArray = f
                    n = n + 1
                End If
            ElseIf mode = 2 Then
                f = c.Formula
                c.FormulaArray = f
                n = n + 1
            End If
        End If
    Next c
    SafeEnd
    Done "Reapply CSE Array Formulas: " & Plural(n, "formula") & " processed."
    Exit Sub
eh:
    ReportError "Reapply CSE Array Formulas"
End Sub

' Toggle: prefix formulas (and numbers) with an apostrophe so they show as text.
Public Sub XC_FormulasToText()
    On Error GoTo eh
    Dim rng As Range, c As Range, n As Long, toText As Boolean, s As String
    Set rng = SelRange()
    If rng Is Nothing Then Exit Sub
    ' decide direction from the first non-empty cell
    toText = True
    For Each c In rng.Cells
        If Not IsEmpty(c.Value) Then
            If Not c.HasFormula And VarType(c.Value) = vbString Then
                If Left$(c.Value, 1) = "=" Then toText = False
            End If
            Exit For
        End If
    Next c
    SnapshotRange rng, "Formulas to Text"
    SafeStart
    For Each c In rng.Cells
        If toText Then
            If c.HasFormula Then
                c.Formula = "'" & c.Formula: n = n + 1
            ElseIf IsNumeric(c.Value) And Not IsEmpty(c.Value) And VarType(c.Value) <> vbString And VarType(c.Value) <> vbBoolean Then
                c.Formula = "'" & c.Formula: n = n + 1
            End If
        Else
            If Not c.HasFormula And VarType(c.Value) = vbString Then
                s = c.Value
                If Left$(s, 1) = "=" Or (IsNumeric(s) And Len(s) > 0) Then
                    On Error Resume Next
                    c.Formula = s
                    If Err.Number = 0 Then n = n + 1
                    Err.Clear
                    On Error GoTo eh
                End If
            End If
        End If
    Next c
    SafeEnd
    Done IIf(toText, "Formulas shown as text: ", "Text restored to formulas/numbers: ") & Plural(n, "cell") & "."
    Exit Sub
eh:
    ReportError "Convert Formulas to Text / back"
End Sub

'--- List formulas -------------------------------------------------------------------
Public Sub XC_ListAllFormulas()
    On Error GoTo eh
    Dim ws As Worksheet, rpt As Worksheet, fr As Range, c As Range, r As Long, scope As Long, src As Workbook
    scope = AskChoice("List formulas from:", Array("Active sheet", "Whole workbook"))
    If scope = 0 Then Exit Sub
    Set src = ActiveWorkbook
    SafeStart "Listing formulas"
    Set rpt = NewReportSheet("Formulas")
    rpt.Range("A1:E1").Value = Array("Sheet", "Cell", "Formula", "Value", "Array?")
    rpt.Range("A1:E1").Font.Bold = True
    r = 2
    For Each ws In src.Worksheets
        If scope = 2 Or ws.Name = src.ActiveSheet.Name Then
            Set fr = Nothing
            On Error Resume Next
            Set fr = ws.UsedRange.SpecialCells(xlCellTypeFormulas)
            On Error GoTo eh
            If Not fr Is Nothing Then
                For Each c In fr.Cells
                    rpt.Cells(r, 1).Value = ws.Name
                    rpt.Cells(r, 2).Value = c.Address(False, False)
                    rpt.Cells(r, 3).Value = "'" & c.Formula
                    rpt.Cells(r, 4).Value = c.Text
                    rpt.Cells(r, 5).Value = c.HasArray
                    r = r + 1
                Next c
            End If
        End If
    Next ws
    rpt.Columns("A:E").AutoFit
    If rpt.Columns("C").ColumnWidth > 100 Then rpt.Columns("C").ColumnWidth = 100
    SafeEnd
    Done "List All Formulas: " & Plural(r - 2, "formula") & " listed."
    Exit Sub
eh:
    ReportError "List All Formulas"
End Sub

' VBA's .Formula always takes US-English syntax, so this converts for free.
Public Sub XC_InsertUSFormula()
    On Error GoTo eh
    Dim f As String
    If TypeName(Selection) <> "Range" Then Exit Sub
    f = AskText("Enter the formula in US-English syntax (comma argument separators, English function names):", "=SUM(A1:A10)", "Insert US English Formula")
    If Len(f) = 0 Then Exit Sub
    If Left$(f, 1) <> "=" Then f = "=" & f
    On Error Resume Next
    ActiveCell.Formula = f
    If Err.Number <> 0 Then MsgBox "Excel did not accept that formula: " & Err.Description, vbExclamation, APP_NAME
    On Error GoTo 0
    Exit Sub
eh:
    ReportError "Insert US English Formula"
End Sub
