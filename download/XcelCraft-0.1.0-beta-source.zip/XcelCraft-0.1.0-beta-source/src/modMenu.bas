Attribute VB_Name = "modMenu"
'==============================================================================
' SPDX-License-Identifier: MIT
' XcelCraft - modMenu
' Tool registry + menu builder. The menu appears under
'   Excel 2007+  : Add-ins tab > Menu Commands > "XcelCraft"
'   Excel Mac    : menu bar > "XcelCraft"
' Also provides "Find and Run a Tool" and "Start the Last Used Tool Again".
'==============================================================================
Option Explicit

Private Const MENU_TAG As String = "XC_MENU"

Private Type ToolRec
    Category As String
    Caption As String
    Proc As String
End Type

Private mTools() As ToolRec
Private mToolCount As Long
Private mCategories As Collection

'------------------------------------------------------------------------------
' Auto_Open / Auto_Close run when the add-in (or workbook) loads / unloads.
'------------------------------------------------------------------------------
Public Sub Auto_Open()
    BuildMenu
    InstallShortcuts
    HookAppEvents
End Sub

Public Sub Auto_Close()
    UnhookAppEvents
    RemoveShortcuts
    RemoveMenu
End Sub

'------------------------------------------------------------------------------
' Registry
'------------------------------------------------------------------------------
Private Sub Reg(ByVal cat As String, ByVal caption As String, ByVal proc As String)
    mToolCount = mToolCount + 1
    ReDim Preserve mTools(1 To mToolCount)
    mTools(mToolCount).Category = cat
    mTools(mToolCount).Caption = caption
    mTools(mToolCount).Proc = proc
    On Error Resume Next
    mCategories.Add cat, cat   ' keyed: duplicates ignored
    On Error GoTo 0
End Sub

Private Sub RegisterTools()
    mToolCount = 0
    Erase mTools
    Set mCategories = New Collection

    ' ---------------------------------------------------------------- Text
    Reg "Text", "Prefix or suffix text to each cell...", "XC_AddTextStartEnd"
    Reg "Text", "UPPERCASE", "XC_Upper"
    Reg "Text", "lowercase", "XC_Lower"
    Reg "Text", "Capitalize the first letter, leave the rest", "XC_CapFirstOnly"
    Reg "Text", "Sentence case (first letter up, rest down)", "XC_CapFirstLowerRest"
    Reg "Text", "Title Case...", "XC_TitleCase"
    Reg "Text", "Change case: upper, lower, sentence, title, toggle...", "XC_ChangeCaseOptions"
    Reg "Text", "Write numbers out in words...", "XC_SpellNumbers"
    Reg "Text", "Text to real dates (DMY / MDY / YMD)...", "XC_TextToDates"
    Reg "Text", "Trim spaces at both ends", "XC_TrimSpaces"
    Reg "Text", "Trim and collapse spaces", "XC_TrimAllSpaces"
    Reg "Text", "Trim line breaks at both ends", "XC_TrimLineBreaks"
    Reg "Text", "Scrub cells: spaces, junk characters, text numbers...", "XC_CleanUpData"
    Reg "Text", "Find and replace across sheets, notes and shapes...", "XC_AdvancedFindReplace"
    Reg "Text", "Strip or swap chosen characters...", "XC_RemoveUnwantedChars"
    Reg "Text", "Strip accents (e-acute to e)", "XC_RemoveAccents"
    Reg "Text", "Strip letters", "XC_RemoveLetters"
    Reg "Text", "Strip digits", "XC_RemoveNumbers"
    Reg "Text", "Strip line breaks at the end", "XC_RemoveTrailingLineBreaks"
    Reg "Text", "Cut the first N characters...", "XC_RemoveFirstX"
    Reg "Text", "Cut the last N characters...", "XC_RemoveLastX"
    Reg "Text", "Keep only the first N characters...", "XC_KeepFirstX"
    Reg "Text", "Subscript the digits in chemical formulas", "XC_SubscriptChemical"
    Reg "Text", "Superscript the last character", "XC_SuperscriptLast"
    Reg "Text", "Subscript the last character", "XC_SubscriptLast"
    Reg "Text", "Reverse the characters", "XC_ReverseText"
    Reg "Text", "Sort the items inside each cell...", "XC_SortInsideCell"

    ' ------------------------------------------------------- Numbers & Dates
    Reg "Numbers & Dates", "Add, multiply, round or negate the selected numbers...", "XC_ApplyCalculation"
    Reg "Numbers & Dates", "Replace formulas with their values", "XC_FormulasToValues"
    Reg "Numbers & Dates", "Text to real numbers", "XC_TextToNumbers"
    Reg "Numbers & Dates", "Store numbers as text (leading apostrophe)", "XC_NumbersToText"
    Reg "Numbers & Dates", "Replace values with their displayed text", "XC_ValuesToFormattedText"
    Reg "Numbers & Dates", "Flip, negate or absolute the selected numbers...", "XC_ChangeSigns"
    Reg "Numbers & Dates", "Move trailing minus signs to the front (50- to -50)", "XC_FixTrailingMinus"
    Reg "Numbers & Dates", "Show N significant decimals...", "XC_SignificantDecimals"
    Reg "Numbers & Dates", "Percent to plain number (5% to 5)", "XC_PercentToNumber"
    Reg "Numbers & Dates", "Write numbers out in words...", "XC_SpellNumbers"
    Reg "Numbers & Dates", "Round the stored values...", "XC_RoundPermanently"
    Reg "Numbers & Dates", "Pad with leading zeros to a fixed length...", "XC_AddLeadingZeros"
    Reg "Numbers & Dates", "Number or label cells in sequence...", "XC_AutoNumber"
    Reg "Numbers & Dates", "Fill with unique random numbers", "XC_UniqueRandom"
    Reg "Numbers & Dates", "Text to real dates (DMY / MDY / YMD)...", "XC_TextToDates"
    Reg "Numbers & Dates", "Julian day numbers to dates (yyddd, yyyyddd, cyyddd)", "XC_JulianToDate"
    Reg "Numbers & Dates", "Insert a date...", "XC_InsertDate"

    ' ------------------------------------------------------------------ Fill
    Reg "Fill & Series", "Put a value in every empty cell...", "XC_FillBlanks"
    Reg "Fill & Series", "Overwrite every non-empty cell with a value...", "XC_OverwriteFilled"
    Reg "Fill & Series", "Fill empty cells with the value above", "XC_FillBlanksFromAbove"
    Reg "Fill & Series", "Pad with leading zeros to a fixed length...", "XC_AddLeadingZeros"
    Reg "Fill & Series", "Prefix or suffix text to each cell...", "XC_AddTextStartEnd"
    Reg "Fill & Series", "Extend a linear trend down columns", "XC_FillTrendVertical"
    Reg "Fill & Series", "Extend a linear trend across rows", "XC_FillTrendHorizontal"
    Reg "Fill & Series", "Number or label cells in sequence...", "XC_AutoNumber"
    Reg "Fill & Series", "Fill with unique random numbers", "XC_UniqueRandom"
    Reg "Fill & Series", "Stamp date and time (with seconds)", "XC_InsertNowSeconds"
    Reg "Fill & Series", "Stamp time (with seconds)", "XC_InsertTimeSeconds"
    Reg "Fill & Series", "Insert a date...", "XC_InsertDate"
    Reg "Fill & Series", "Stamp the file path into a cell, header or footer...", "XC_InsertFilePath"
    Reg "Fill & Series", "List the files in a folder...", "XC_ListFilesInFolder"
    Reg "Fill & Series", "Write each sheet's name into a cell", "XC_InsertSheetNames"

    ' ---------------------------------------------------------------- Sheets
    Reg "Sheets", "New sheet with a name...", "XC_InsertNamedSheet"
    Reg "Sheets", "New sheets named from the selected cells...", "XC_InsertSheetsFromCells"
    Reg "Sheets", "Rename this sheet...", "XC_RenameActiveSheet"
    Reg "Sheets", "Rename several sheets: prefix, replace, number...", "XC_RenameMultipleSheets"
    Reg "Sheets", "Name each sheet after one of its cells", "XC_RenameSheetsFromCell"
    Reg "Sheets", "Write each sheet's name into a cell", "XC_InsertSheetNames"
    Reg "Sheets", "Back to the previous sheet", "XC_SwitchToPreviousSheet"
    Reg "Sheets", "Sort sheet tabs...", "XC_SortSheets"
    Reg "Sheets", "Build a contents sheet linking to every sheet...", "XC_CreateIndexSheet"
    Reg "Sheets", "Split a range into sheets by value or row count...", "XC_SplitRangeToSheets"
    Reg "Sheets", "Delete empty sheets", "XC_RemoveEmptySheets"
    Reg "Sheets", "Unhide every sheet", "XC_UnhideAllSheets"
    Reg "Sheets", "Hide selected sheets", "XC_HideSelectedSheets"
    Reg "Sheets", "Hide selected sheets (very hidden)", "XC_HideSelectedVeryHidden"
    Reg "Sheets", "Protect several sheets...", "XC_ProtectMultipleSheets"
    Reg "Sheets", "Unprotect several sheets...", "XC_UnprotectMultipleSheets"
    Reg "Sheets", "Print chosen sheets...", "XC_PrintMultipleSheets"
    Reg "Sheets", "Apply this sheet's page setup to other sheets...", "XC_CopyPageSetup"
    Reg "Sheets", "Use this selection as print area on selected sheets", "XC_SetPrintAreaSelectedSheets"
    Reg "Sheets", "Clear the print area on selected sheets", "XC_ClearPrintAreaSelectedSheets"
    Reg "Sheets", "Reset page breaks on selected sheets", "XC_ResetPageBreaksSelectedSheets"
    Reg "Sheets", "Freeze panes at this cell on selected sheets", "XC_FreezePanesMultiple"
    Reg "Sheets", "Unfreeze panes on selected sheets", "XC_UnfreezePanesMultiple"
    Reg "Sheets", "Stack data from several sheets onto one...", "XC_StackFromSheets"
    Reg "Sheets", "Delete unused cell styles", "XC_RemoveUnusedStyles"
    Reg "Sheets", "Trim unused trailing rows and columns on selected sheets", "XC_DeleteEndingRowsCols"
    Reg "Sheets", "Reset the used range (fix Ctrl+End)...", "XC_ResetLastCell"

    ' ---------------------------------------------------------------- Range
    Reg "Ranges", "Find and replace across sheets, notes and shapes...", "XC_AdvancedFindReplace"
    Reg "Ranges", "Sort by color, length, last word, natural order...", "XC_AdvancedSorting"
    Reg "Ranges", "Shuffle rows", "XC_SortRandom"
    Reg "Ranges", "Sort the items inside each cell...", "XC_SortInsideCell"
    Reg "Ranges", "Reverse the order of cells", "XC_FlipCells"
    Reg "Ranges", "Scroll the selection to the top-left", "XC_ScrollTopLeft"
    Reg "Ranges", "Scroll the selection to the center", "XC_ScrollCenter"
    Reg "Ranges", "Swap formula errors for a message or IFERROR...", "XC_ReplaceErrors"
    Reg "Ranges", "Mark source range for the paste tools", "XC_CopySource"
    Reg "Ranges", "Paste special, several options at once...", "XC_PasteSpecialCombined"
    Reg "Ranges", "Paste values with formatting", "XC_PasteValuesAndFormatting"
    Reg "Ranges", "Paste values only", "XC_PasteValuesNoFormatting"
    Reg "Ranges", "Copy visible cells onto visible cells...", "XC_CopyVisibleToVisible"
    Reg "Ranges", "Replace values with their displayed text", "XC_ValuesToFormattedText"
    Reg "Ranges", "Bake conditional formats into real formats", "XC_FreezeConditionalFormatting"
    Reg "Ranges", "Copy formulas verbatim (no reference shift)...", "XC_CopyFormulasExact"
    Reg "Ranges", "Move as values, leaving dependents untouched...", "XC_CutPasteAsValues"
    Reg "Ranges", "Paste several selected areas together...", "XC_CopyMultipleRanges"
    Reg "Ranges", "Transpose with formulas verbatim...", "XC_TransposeExact"
    Reg "Ranges", "Split a range into sheets by value or row count...", "XC_SplitRangeToSheets"
    Reg "Ranges", "Blank out repeat values, keep the first", "XC_ClearDuplicates"
    Reg "Ranges", "Count repeats, optionally color them...", "XC_CountDuplicates"
    Reg "Ranges", "Color each group of repeats differently", "XC_HighlightDuplicateSets"
    Reg "Ranges", "List defined names and tables", "XC_ListNames"
    Reg "Ranges", "Expand defined names into cell references", "XC_ReplaceNamesWithRefs"
    Reg "Ranges", "Delete names that live inside the selection", "XC_DeleteNamesInSelection"
    Reg "Ranges", "Delete every defined name in the workbook", "XC_DeleteAllNames"
    Reg "Ranges", "Delete names that point to #REF!", "XC_DeleteInvalidNames"

    ' -------------------------------------------------------- Columns & Rows
    Reg "Rows & Columns", "Select, hide or delete rows / columns by a test...", "XC_RowsColsByCriteria"
    Reg "Rows & Columns", "Sort by color, length, last word, natural order...", "XC_AdvancedSorting"
    Reg "Rows & Columns", "Band every nth row or column...", "XC_ColorNthRowCol"
    Reg "Rows & Columns", "Separate groups where a column's value changes...", "XC_InsertVisualBreaks"
    Reg "Rows & Columns", "Join each row into one cell...", "XC_JoinHorizontal"
    Reg "Rows & Columns", "Join each column into one cell...", "XC_JoinVertical"
    Reg "Rows & Columns", "Join each column into one cell with line breaks", "XC_JoinVerticalLineBreak"
    Reg "Rows & Columns", "Interleave blank rows or columns...", "XC_InsertBlankBetween"
    Reg "Rows & Columns", "Insert N rows or columns here...", "XC_InsertNRows"
    Reg "Rows & Columns", "Unhide rows and columns, all or chosen...", "XC_UnhideRowsCols"
    Reg "Rows & Columns", "Delete hidden rows and/or columns...", "XC_DeleteHiddenRowsCols"
    Reg "Rows & Columns", "Drop empty rows", "XC_DeleteEmptyRows"
    Reg "Rows & Columns", "Drop empty columns", "XC_DeleteEmptyColumns"
    Reg "Rows & Columns", "Auto-fit row height including merged cells", "XC_FixAutofitMerged"
    Reg "Rows & Columns", "Scrub cells: spaces, junk characters, text numbers...", "XC_CleanUpData"
    Reg "Rows & Columns", "Set cell size in cm, inches or pixels...", "XC_SetCellSize"
    Reg "Rows & Columns", "Wrap one column into a grid...", "XC_ReshapeColumnToTable"
    Reg "Rows & Columns", "Lay a long list out side by side for printing...", "XC_SplitLongDataset"
    Reg "Rows & Columns", "Stack data from several sheets onto one...", "XC_StackFromSheets"
    Reg "Rows & Columns", "Trim unused trailing rows and columns on selected sheets", "XC_DeleteEndingRowsCols"
    Reg "Rows & Columns", "Reset the used range (fix Ctrl+End)...", "XC_ResetLastCell"

    ' --------------------------------------------------------------- Formulas
    Reg "Formulas", "Replace formulas with their values", "XC_FormulasToValues"
    Reg "Formulas", "Add, multiply, round or negate the selected numbers...", "XC_ApplyCalculation"
    Reg "Formulas", "Swap formula errors for a message or IFERROR...", "XC_ReplaceErrors"
    Reg "Formulas", "Transpose with formulas verbatim...", "XC_TransposeExact"
    Reg "Formulas", "Copy formulas verbatim (no reference shift)...", "XC_CopyFormulasExact"
    Reg "Formulas", "Make references relative, absolute or mixed...", "XC_ChangeReferenceStyle"
    Reg "Formulas", "Expand defined names into cell references", "XC_ReplaceNamesWithRefs"
    Reg "Formulas", "Re-enter array formulas", "XC_ReapplyCSE"
    Reg "Formulas", "Show formulas as text (apostrophe toggle)", "XC_FormulasToText"
    Reg "Formulas", "List every formula", "XC_ListAllFormulas"
    Reg "Formulas", "Enter a formula in US-English syntax...", "XC_InsertUSFormula"

    ' ---------------------------------------------------------------- Select
    Reg "Selection", "Select cells that pass a test...", "XC_SelectCellsByCriteria"
    Reg "Selection", "Select, hide or delete rows / columns by a test...", "XC_RowsColsByCriteria"
    Reg "Selection", "Nudge, grow or shrink the selection...", "XC_MoveExtendShrink"
    Reg "Selection", "Drop cells from the selection...", "XC_DeselectCells"
    Reg "Selection", "Select everything except the current selection...", "XC_InvertSelection"
    Reg "Selection", "Merge selected areas into one block", "XC_MergeContiguousSelections"
    Reg "Selection", "Select the run of equal values below", "XC_SelectMatchingBelow"
    Reg "Selection", "Select the run of equal values around this cell", "XC_SelectMatchingInColumn"
    Reg "Selection", "Stretch selection down to the last used row", "XC_ExtendToLowestUsedRow"
    Reg "Selection", "Stretch selection right to the last used column", "XC_ExtendToRightmostUsedColumn"
    Reg "Selection", "Jump to the first cell that differs", "XC_JumpToFirstDifferent"
    Reg "Selection", "Select the cell(s) holding the smallest value", "XC_SelectLowestValue"
    Reg "Selection", "Select the cell(s) holding the largest value", "XC_SelectHighestValue"
    Reg "Selection", "Select formulas that return errors", "XC_SelectFormulaErrors"
    Reg "Selection", "Back to the previous sheet", "XC_SwitchToPreviousSheet"
    Reg "Selection", "Select all sheets", "XC_SelectAllSheets"
    Reg "Selection", "Select all shapes and objects", "XC_SelectAllObjects"
    Reg "Selection", "Preview the selection", "XC_PrintPreviewSelection"
    Reg "Selection", "Print the selection", "XC_PrintSelection"
    Reg "Selection", "Repeat this selection on every sheet", "XC_ApplySelectionToAllSheets"

    ' ------------------------------------------------------- Format & Layout
    Reg "Layout & Printing", "Apply this sheet's page setup to other sheets...", "XC_CopyPageSetup"
    Reg "Layout & Printing", "Stamp the file path into a cell, header or footer...", "XC_InsertFilePath"
    Reg "Layout & Printing", "Wipe headers and footers on selected sheets", "XC_ClearHeadersFooters"
    Reg "Layout & Printing", "Separate groups where a column's value changes...", "XC_InsertVisualBreaks"
    Reg "Layout & Printing", "Wrap one column into a grid...", "XC_ReshapeColumnToTable"
    Reg "Layout & Printing", "Lay a long list out side by side for printing...", "XC_SplitLongDataset"
    Reg "Layout & Printing", "Wrap text on", "XC_WrapText"
    Reg "Layout & Printing", "Wrap text off", "XC_UnwrapText"
    Reg "Layout & Printing", "Set cell size in cm, inches or pixels...", "XC_SetCellSize"
    Reg "Layout & Printing", "Box the data on every printed page", "XC_BorderAroundPrintedPages"
    Reg "Layout & Printing", "Remove inner borders", "XC_RemoveInsideBorders"
    Reg "Layout & Printing", "Show N significant decimals...", "XC_SignificantDecimals"
    Reg "Layout & Printing", "Subscript the digits in chemical formulas", "XC_SubscriptChemical"
    Reg "Layout & Printing", "Unmerge cells", "XC_UnmergeCells"
    Reg "Layout & Printing", "Center across the selection (no merge)", "XC_CenterAcrossSelection"
    Reg "Layout & Printing", "Scrub cells: spaces, junk characters, text numbers...", "XC_CleanUpData"
    Reg "Layout & Printing", "Delete unused cell styles", "XC_RemoveUnusedStyles"
    Reg "Layout & Printing", "Remove data validation", "XC_RemoveDataValidation"
    Reg "Layout & Printing", "Remove conditional formatting", "XC_RemoveConditionalFormatting"
    Reg "Layout & Printing", "Bake conditional formats into real formats", "XC_FreezeConditionalFormatting"
    Reg "Layout & Printing", "Count repeats, optionally color them...", "XC_CountDuplicates"
    Reg "Layout & Printing", "Color each group of repeats differently", "XC_HighlightDuplicateSets"
    Reg "Layout & Printing", "Copy only chosen format attributes to a range...", "XC_CopyCertainFormatting"
    Reg "Layout & Printing", "Strip formatting back to Normal", "XC_ResetToNormalStyle"

    ' ---------------------------------------------------- Objects & Comments
    Reg "Shapes & Notes", "Notes manager: list, resize, re-author, replace, delete...", "XC_ManageComments"
    Reg "Shapes & Notes", "Put the cell's value or formula into its note...", "XC_AddValueToComment"
    Reg "Shapes & Notes", "Select all shapes and objects", "XC_SelectAllObjects"
    Reg "Shapes & Notes", "Delete all shapes, pictures and charts on selected sheets", "XC_DeleteAllObjects"
    Reg "Shapes & Notes", "Delete form buttons on selected sheets", "XC_DeleteFormButtons"
    Reg "Shapes & Notes", "Scale pictures and objects by percent...", "XC_ResizePictures"
    Reg "Shapes & Notes", "Remove outline from selected shapes", "XC_RemoveShapeBorders"

    ' --------------------------------------------------------------- Web Data
    Reg "Links & Web", "Scrub cells: spaces, junk characters, text numbers...", "XC_CleanUpData"
    Reg "Links & Web", "Strip HTML tags...", "XC_RemoveHtmlTags"
    Reg "Links & Web", "Decode %20-style and &amp;-style text", "XC_DecodeUrlHtml"
    Reg "Links & Web", "Pull link targets out of cells and shapes...", "XC_ExtractHyperlinkAddresses"
    Reg "Links & Web", "Turn cell text into hyperlinks...", "XC_CreateHyperlinks"
    Reg "Links & Web", "Rewrite hyperlinks as =HYPERLINK() formulas", "XC_HyperlinksToFormulas"
    Reg "Links & Web", "Remove hyperlinks", "XC_RemoveHyperlinks"
    Reg "Links & Web", "Copy as an HTML table...", "XC_CopyAsHtmlTable"

    ' ------------------------------------------------------------ Info & List
    Reg "Inspect & List", "Selection statistics: counts, sum, min, max, distinct...", "XC_AnalyzeCells"
    Reg "Inspect & List", "Workbook and selection facts...", "XC_WorkbookDetails"
    Reg "Inspect & List", "Copy the full file path", "XC_CopyPathToClipboard"
    Reg "Inspect & List", "Which printed page is this cell on?", "XC_PrintedPageNumber"
    Reg "Inspect & List", "Count repeats, optionally color them...", "XC_CountDuplicates"
    Reg "Inspect & List", "Color each group of repeats differently", "XC_HighlightDuplicateSets"
    Reg "Inspect & List", "Count distinct values...", "XC_CountDistinct"
    Reg "Inspect & List", "Character, word and line counts", "XC_CountCharacters"
    Reg "Inspect & List", "List document properties", "XC_ListDocumentProperties"
    Reg "Inspect & List", "List defined names and tables", "XC_ListNames"
    Reg "Inspect & List", "List sheet names...", "XC_ListSheetNames"
    Reg "Inspect & List", "List every formula", "XC_ListAllFormulas"
    Reg "Inspect & List", "Color map of cell types in a new workbook", "XC_VisualMapOfCellTypes"
    Reg "Inspect & List", "List the files in a folder...", "XC_ListFilesInFolder"
    Reg "Inspect & List", "What is selected? (object type)", "XC_DisplaySelectionType"
    Reg "Inspect & List", "Sheet counts by type", "XC_CountSheets"
    Reg "Inspect & List", "Find broken references (#REF!)", "XC_FindRefErrors"
    Reg "Inspect & List", "Find columns too narrow (####)", "XC_FindHashColumns"
    Reg "Inspect & List", "Window and screen sizes", "XC_ScreenResolution"
    Reg "Inspect & List", "Excel's separators and date order", "XC_RegionalSettings"
    Reg "Inspect & List", "List installed add-ins", "XC_ListAddins"
    Reg "Inspect & List", "List installed fonts with samples", "XC_ListFonts"

    ' ----------------------------------------------------------- File & System
    Reg "Files", "Save and keep a timestamped copy...", "XC_SaveWithBackup"
    Reg "Files", "Backup folder...", "XC_SetBackupFolder"
    Reg "Files", "Save as, named after the active cell...", "XC_SaveAsFirstCellName"
    Reg "Files", "Rename this file...", "XC_RenameCurrentFile"
    Reg "Files", "Revert to the saved file", "XC_ReopenWithoutSaving"
    Reg "Files", "Save selection or sheet as a new file...", "XC_ExportSelectionOrSheet"
    Reg "Files", "Save each sheet as its own file...", "XC_ExportSheetsSeparately"
    Reg "Files", "Links to other workbooks: list, break, convert...", "XC_FindRemoveExternalRefs"
    Reg "Files", "Set Excel's default folder...", "XC_ChangeDefaultFileLocation"
    Reg "Files", "Open/save dialogs start in this file's folder", "XC_TempDefaultToCurrentFolder"
    Reg "Files", "Title bar: full path", "XC_ShowPathInTitleBar"
    Reg "Files", "Title bar: file name", "XC_ShowNameInTitleBar"
    Reg "Files", "Close this file and delete it from disk", "XC_CloseAndDelete"
    Reg "Files", "Close workbooks that have no unsaved changes", "XC_CloseUnchanged"
    Reg "Files", "Close chosen workbooks...", "XC_CloseMultiple"
    Reg "Files", "Close every workbook, discard changes", "XC_CloseAllWithoutSaving"
    Reg "Files", "Pin this file to the recent list", "XC_AddToRecentFiles"
    Reg "Files", "Prune the recent files list...", "XC_ClearRecentFiles"
    Reg "Files", "Save a copy without macros", "XC_RemoveAllMacros"
    Reg "Files", "Reveal this file in the file browser", "XC_OpenFileLocation"
    Reg "Files", "Resize Excel to a screen size...", "XC_ResizeExcelWindow"
    Reg "Files", "Save, bypassing BeforeSave macros", "XC_ForceSave"
    Reg "Files", "List installed add-ins", "XC_ListAddins"
    Reg "Files", "Reload add-ins", "XC_ReloadAddins"
    Reg "Files", "List the files in a folder...", "XC_ListFilesInFolder"
    Reg "Files", "Build folders on disk from cell values...", "XC_CreateFolderStructure"

    ' ------------------------------------------------------------------ Import
    Reg "Import", "Pull sheets in from another workbook...", "XC_ImportExcelFile"
    Reg "Import", "Import delimited text with options...", "XC_ImportDelimitedCustom"
    Reg "Import", "Import a dBASE file (not supported by modern Excel)...", "XC_ImportDbf"
    Reg "Import", "Import space-separated text...", "XC_ImportSpaceDelimited"
    Reg "Import", "Import tab-separated text...", "XC_ImportTabDelimited"
    Reg "Import", "Import a CSV file...", "XC_ImportCsv"
    Reg "Import", "Import pipe-separated text...", "XC_ImportPipeDelimited"
    Reg "Import", "Import exclamation-separated text...", "XC_ImportExclamationDelimited"
    Reg "Import", "Import text with Excel's wizard...", "XC_ImportTextWizard"
    Reg "Import", "Stack several files into one sheet...", "XC_MergeImportMultiple"
    Reg "Import", "List the files in a folder...", "XC_ListFilesInFolder"

    ' ------------------------------------------------------------------ Export
    Reg "Export", "Save selection or sheet as a new file...", "XC_ExportSelectionOrSheet"
    Reg "Export", "Copy as an HTML table...", "XC_CopyAsHtmlTable"
    Reg "Export", "Save range or chart as PNG / JPG / GIF...", "XC_ExportAsImage"
    Reg "Export", "Save each sheet as its own file...", "XC_ExportSheetsSeparately"
    Reg "Export", "Copy as plain tab-separated text", "XC_CopyValuesToClipboard"
    Reg "Export", "Copy the sum to the clipboard", "XC_CopySumToClipboard"
    Reg "Export", "Copy the average to the clipboard", "XC_CopyAverageToClipboard"
    Reg "Export", "Copy as bitmap (screen look)", "XC_CopyAsBitmap"
    Reg "Export", "Copy as picture (screen look)", "XC_CopyAsPictureScreen"
    Reg "Export", "Copy as picture (printed look)", "XC_CopyAsPicturePrinted"

    ' ------------------------------------------------------------------- Start
    Reg "Launch", "Character map (Windows)", "XC_OpenCharMap"
    Reg "Launch", "Calculator", "XC_OpenCalculator"
    Reg "Launch", "File browser", "XC_OpenExplorer"
    Reg "Launch", "Reveal this file in the file browser", "XC_OpenFileLocation"
    Reg "Launch", "Plain-text editor", "XC_OpenNotepad"

    ' ================================================== Modeling tool family
    Reg "Modeling: Financial", "Insert a growth-rate (CAGR) formula", "XC_QuickCagr"
    Reg "Modeling: Financial", "Add min / max / mean / median rows", "XC_SummaryStatistics"
    Reg "Modeling: Financial", "Summary rows: which statistics...", "XC_SummaryStatisticsSettings"
    Reg "Modeling: Financial", "Duplicate a block N times...", "XC_DuplicateBlock"
    Reg "Modeling: Financial", "Sum duplicated blocks back into the original...", "XC_SumCopies"
    Reg "Modeling: Financial", "Insert a symbol...", "XC_InsertSymbol"

    Reg "Modeling: Auditing", "Precedents: list and jump...", "XC_PrecedentsList"
    Reg "Modeling: Auditing", "Dependents: list and jump...", "XC_DependentsList"
    Reg "Modeling: Auditing", "Step into a precedent", "XC_TraceIn"
    Reg "Modeling: Auditing", "Step back out", "XC_TraceOut"
    Reg "Modeling: Auditing", "Arrows to precedents (toggle)", "XC_ShowAllPrecedents"
    Reg "Modeling: Auditing", "Arrows to dependents (toggle)", "XC_ShowAllDependents"
    Reg "Modeling: Auditing", "Remove audit arrows", "XC_ClearArrows"
    Reg "Modeling: Auditing", "Find formulas that break their row/column pattern...", "XC_FormulaConsistency"
    Reg "Modeling: Auditing", "Model audit report...", "XC_ModelAudit"

    Reg "Modeling: Charts", "Cycle color of the selected chart element", "XC_ChartColorCycle"
    Reg "Modeling: Charts", "Recolor chart series from the palette", "XC_RecolorSeries"
    Reg "Modeling: Charts", "Chart color palette...", "XC_ChartColorSettings"
    Reg "Modeling: Charts", "Waterfall chart...", "XC_WaterfallChart"
    Reg "Modeling: Charts", "Floating-bar range chart", "XC_RangeBarChart"
    Reg "Modeling: Charts", "Column + line chart on two axes...", "XC_ComboChart"

    Reg "Modeling: Files", "Save", "XC_QuickSave"
    Reg "Modeling: Files", "Save as...", "XC_QuickSaveAs"
    Reg "Modeling: Files", "Save all workbooks", "XC_QuickSaveAll"
    Reg "Modeling: Files", "Save as the next version number...", "XC_SaveNextVersion"
    Reg "Modeling: Files", "Delete notes and comments...", "XC_DeleteCommentsNotes"
    Reg "Modeling: Files", "Slim the file: used ranges, styles, names...", "XC_OptimizeFile"
    Reg "Modeling: Files", "Unload the add-in", "XC_UnloadAddin"

    Reg "Modeling: Formulas", "Fill right as far as the neighbours go", "XC_SmartFillRight"
    Reg "Modeling: Formulas", "Fill down as far as the neighbours go", "XC_SmartFillDown"
    Reg "Modeling: Formulas", "Guard formulas with IFERROR, ask for fallback (toggle)...", "XC_ErrorGuard"
    Reg "Modeling: Formulas", "Guard formulas with IFERROR, saved fallback (toggle)", "XC_ErrorGuardQuick"
    Reg "Modeling: Formulas", "Tidy formulas: drop stray spaces and this-sheet prefixes", "XC_CleanCells"
    Reg "Modeling: Formulas", "Cycle reference anchoring (A1 > $A$1 > A$1 > $A1)", "XC_AnchorFormula"
    Reg "Modeling: Formulas", "Expand defined names into cell references", "XC_ReplaceNamesWithRefs"
    Reg "Modeling: Formulas", "Show formulas as text (apostrophe toggle)", "XC_CommentCells"
    Reg "Modeling: Formulas", "Negate numbers; wrap formulas in -( )", "XC_FlipSign"
    Reg "Modeling: Formulas", "Wrap the formula in parentheses", "XC_WrapParentheses"
    Reg "Modeling: Formulas", "Replace formulas with values and recolor", "XC_HardcodeSelection"
    Reg "Modeling: Formulas", "Replace formulas using a given function with values...", "XC_HardcodeFunction"
    Reg "Modeling: Formulas", "Detach sheet: freeze off-sheet references to values", "XC_DetachSheet"
    Reg "Modeling: Formulas", "Resolve lookups to direct references", "XC_ResolveLookups"
    Reg "Modeling: Formulas", "Resolve lookups: functions to handle...", "XC_ResolveLookupsSettings"
    Reg "Modeling: Formulas", "Replace a function with what it returns...", "XC_EvaluateFunction"
    Reg "Modeling: Formulas", "Turn a TRANSPOSE array into direct links", "XC_EvaluateTranspose"
    Reg "Modeling: Formulas", "Quick validation rules (toggle, number, date, %)...", "XC_DataValidationPreset"
    Reg "Modeling: Formulas", "Jump to the smallest value", "XC_GoToMin"
    Reg "Modeling: Formulas", "Jump to the largest value", "XC_GoToMax"

    Reg "Modeling: Paste", "Mark source range for the paste tools", "XC_CopySource"
    Reg "Modeling: Paste", "Paste formulas verbatim", "XC_PasteVerbatim"
    Reg "Modeling: Paste", "Paste number formats only", "XC_PasteNumberFormats"
    Reg "Modeling: Paste", "Paste transposed (links / verbatim / values)...", "XC_PasteTranspose"
    Reg "Modeling: Paste", "Paste keeping links within the block", "XC_PasteKeepInternalLinks"
    Reg "Modeling: Paste", "Paste as links to the source", "XC_PasteLinks"
    Reg "Modeling: Paste", "Insert cells and paste...", "XC_PasteInsert"
    Reg "Modeling: Paste", "Capture row heights / column widths / outline", "XC_CopyRowColInfo"
    Reg "Modeling: Paste", "Apply captured row / column sizing", "XC_PasteRowColInfo"

    Reg "Modeling: Rows, Columns & View", "Group rows", "XC_GroupRows"
    Reg "Modeling: Rows, Columns & View", "Ungroup rows", "XC_UngroupRows"
    Reg "Modeling: Rows, Columns & View", "Expand all row groups", "XC_ExpandAllRows"
    Reg "Modeling: Rows, Columns & View", "Collapse all row groups", "XC_CollapseAllRows"
    Reg "Modeling: Rows, Columns & View", "Group columns", "XC_GroupColumns"
    Reg "Modeling: Rows, Columns & View", "Ungroup columns", "XC_UngroupColumns"
    Reg "Modeling: Rows, Columns & View", "Expand all column groups", "XC_ExpandAllColumns"
    Reg "Modeling: Rows, Columns & View", "Collapse all column groups", "XC_CollapseAllColumns"
    Reg "Modeling: Rows, Columns & View", "Gridlines on/off", "XC_ToggleGridlines"
    Reg "Modeling: Rows, Columns & View", "Hide page-break lines", "XC_HidePageBreaks"
    Reg "Modeling: Rows, Columns & View", "Zoom in", "XC_ZoomIn"
    Reg "Modeling: Rows, Columns & View", "Zoom out", "XC_ZoomOut"

    Reg "Format: Numbers", "Cycle number formats", "XC_NumGeneralCycle"
    Reg "Format: Numbers", "Cycle multiple (x) formats", "XC_NumMultipleCycle"
    Reg "Format: Numbers", "Cycle currency formats", "XC_NumCurrencyCycle"
    Reg "Format: Numbers", "Cycle foreign currency formats", "XC_NumForeignCycle"
    Reg "Format: Numbers", "Cycle date formats", "XC_NumDateCycle"
    Reg "Format: Numbers", "Cycle yes/no formats", "XC_NumBinaryCycle"
    Reg "Format: Numbers", "Cycle percent formats", "XC_NumPercentCycle"
    Reg "Format: Numbers", "Cycle ratio formats", "XC_NumRatioCycle"
    Reg "Format: Numbers", "One more decimal", "XC_IncreaseDecimals"
    Reg "Format: Numbers", "One fewer decimal", "XC_DecreaseDecimals"
    Reg "Format: Numbers", "Divide inputs by 10", "XC_ShiftDecimalLeft"
    Reg "Format: Numbers", "Multiply inputs by 10", "XC_ShiftDecimalRight"

    Reg "Format: Colors", "Toggle input blue / default font color", "XC_InputColorToggle"
    Reg "Format: Colors", "Cycle font color", "XC_FontColorCycle"
    Reg "Format: Colors", "Cycle fill color", "XC_FillColorCycle"
    Reg "Format: Colors", "Cycle the color of existing borders", "XC_BorderColorCycle"
    Reg "Format: Colors", "Color selection by cell type (inputs, formulas, links)", "XC_TypeColorSelection"
    Reg "Format: Colors", "Color the whole sheet by cell type", "XC_TypeColorSheet"
    Reg "Format: Colors", "Color the whole workbook by cell type", "XC_TypeColorWorkbook"
    Reg "Format: Colors", "Cycle through the cell-type colors", "XC_TypeColorCycle"
    Reg "Format: Colors", "Shade every other row (toggle)", "XC_AlternateRowShading"
    Reg "Format: Colors", "Shade every other column (toggle)", "XC_AlternateColumnShading"

    Reg "Format: Borders", "Cycle bottom border style", "XC_BottomBorderCycle"
    Reg "Format: Borders", "Cycle top border style", "XC_TopBorderCycle"
    Reg "Format: Borders", "Cycle left border style", "XC_LeftBorderCycle"
    Reg "Format: Borders", "Cycle right border style", "XC_RightBorderCycle"
    Reg "Format: Borders", "Cycle outline border style", "XC_OutsideBorderCycle"
    Reg "Format: Borders", "Remove borders", "XC_NoBorder"
    Reg "Format: Borders", "Line above totals (toggle)", "XC_TotalLine"

    Reg "Format: Fonts & Alignment", "Cycle underline style", "XC_UnderlineCycle"
    Reg "Format: Fonts & Alignment", "Cycle font size", "XC_FontSizeCycle"
    Reg "Format: Fonts & Alignment", "Larger font", "XC_IncreaseFont"
    Reg "Format: Fonts & Alignment", "Smaller font", "XC_DecreaseFont"
    Reg "Format: Fonts & Alignment", "Cycle horizontal alignment", "XC_HorizontalAlignCycle"
    Reg "Format: Fonts & Alignment", "Cycle indent", "XC_LeftIndentCycle"
    Reg "Format: Fonts & Alignment", "Wrap text (toggle)", "XC_WrapTextToggle"
    Reg "Format: Fonts & Alignment", "Cycle text case", "XC_CaseCycle"
    Reg "Format: Fonts & Alignment", "Dot leaders after text (toggle)", "XC_DotLeaders"
    Reg "Format: Fonts & Alignment", "Cycle list bullets and numbering", "XC_ListCycle"
    Reg "Format: Fonts & Alignment", "Cycle footnote marker (1)-(9)", "XC_FootnoteCycle"
    Reg "Format: Fonts & Alignment", "Cycle row height", "XC_RowHeightCycle"
    Reg "Format: Fonts & Alignment", "Cycle column width", "XC_ColumnWidthCycle"
    Reg "Format: Fonts & Alignment", "Capture this cell's style", "XC_CapturePaintbrush"
    Reg "Format: Fonts & Alignment", "Apply the captured style", "XC_ApplyPaintbrush"
    Reg "Format: Fonts & Alignment", "Edit a cycle's steps...", "XC_CustomizeCycle"
    Reg "Format: Fonts & Alignment", "Formatting options...", "XC_FormatOptions"

    ' ---------------------------------------------------------------- System
    Reg "XcelCraft", "Keyboard shortcuts...", "XC_ShortcutManager"
    Reg "XcelCraft", "List keyboard shortcuts", "XC_ListShortcuts"
    Reg "XcelCraft", "Keyboard shortcuts on/off", "XC_ToggleShortcuts"
    Reg "XcelCraft", "Search for a tool...", "XC_FindAndRunTool"
    Reg "XcelCraft", "Run the last tool again", "XC_RunLastTool"
    Reg "XcelCraft", "Undo the last tool", "XC_UndoLastTool"
    Reg "XcelCraft", "Quiet mode on/off (fewer result pop-ups)", "XC_ToggleQuietMode"
    Reg "XcelCraft", "Rebuild the menu", "BuildMenu"
    Reg "XcelCraft", "About...", "XC_About"
End Sub

'------------------------------------------------------------------------------
' Menu build / remove
'------------------------------------------------------------------------------
Public Sub BuildMenu()
    On Error GoTo eh
    Dim bar As CommandBar, root As CommandBarPopup, sub1 As CommandBarPopup, btn As CommandBarButton
    Dim i As Long, cat As Variant
    RemoveMenu
    RegisterTools
    Set bar = Application.CommandBars("Worksheet Menu Bar")
    Set root = bar.Controls.Add(Type:=msoControlPopup, Temporary:=True)
    root.Caption = APP_NAME
    root.Tag = MENU_TAG
    For Each cat In mCategories
        Set sub1 = root.Controls.Add(Type:=msoControlPopup, Temporary:=True)
        sub1.Caption = cat
        sub1.Tag = MENU_TAG
        For i = 1 To mToolCount
            If mTools(i).Category = cat Then
                Set btn = sub1.Controls.Add(Type:=msoControlButton, Temporary:=True)
                btn.Caption = mTools(i).Caption
                If Len(ShortcutFor(mTools(i).Proc)) > 0 Then btn.ShortcutText = ShortcutFor(mTools(i).Proc)
                btn.OnAction = "'" & ThisWorkbook.Name & "'!" & "RunTool"
                btn.Parameter = mTools(i).Proc
                btn.Tag = MENU_TAG
                btn.Style = msoButtonCaption
            End If
        Next i
    Next cat
    Exit Sub
eh:
    MsgBox "Could not build the " & APP_NAME & " menu: " & Err.Description, vbExclamation, APP_NAME
End Sub

Public Sub RemoveMenu()
    On Error Resume Next
    Dim ctl As CommandBarControl
    For Each ctl In Application.CommandBars("Worksheet Menu Bar").Controls
        If ctl.Tag = MENU_TAG Then ctl.Delete
    Next ctl
    On Error GoTo 0
End Sub

' Every menu button routes through here so we can record the last used tool.
Public Sub RunTool()
    Dim proc As String
    On Error Resume Next
    proc = Application.CommandBars.ActionControl.Parameter
    On Error GoTo 0
    If Len(proc) = 0 Then Exit Sub
    RunToolByName proc
End Sub

Public Sub RunToolByName(ByVal proc As String)
    SaveSetting REG_APP, "State", "LastTool", proc
    Application.Run "'" & ThisWorkbook.Name & "'!" & proc
End Sub

'------------------------------------------------------------------------------
' Find and Run a Tool / Last used tool
'------------------------------------------------------------------------------
Public Sub XC_FindAndRunTool()
    Dim term As String, i As Long, hits() As Long, n As Long, s As String, pick As Variant
    If mToolCount = 0 Then RegisterTools
    term = AskText("Type part of a tool name to search for:", "", "Find and Run a Tool")
    If Len(term) = 0 Then Exit Sub
    For i = 1 To mToolCount
        If InStr(1, mTools(i).Caption, term, vbTextCompare) > 0 Then
            If Not AlreadyListed(hits, n, mTools(i).Proc) Then
                n = n + 1
                ReDim Preserve hits(1 To n)
                hits(n) = i
            End If
        End If
    Next i
    If n = 0 Then
        MsgBox "No tool matches '" & term & "'.", vbInformation, APP_NAME
        Exit Sub
    End If
    If n > 25 Then
        MsgBox n & " tools match. Please use a more specific search term.", vbInformation, APP_NAME
        Exit Sub
    End If
    s = "Matching tools (enter the number to run):" & vbCrLf & vbCrLf
    For i = 1 To n
        s = s & i & ". [" & mTools(hits(i)).Category & "] " & mTools(hits(i)).Caption & vbCrLf
    Next i
    pick = Application.InputBox(s, "Find and Run a Tool", 1, Type:=1)
    If VarType(pick) = vbBoolean Then Exit Sub
    If pick >= 1 And pick <= n Then RunToolByName mTools(hits(CLng(pick))).Proc
End Sub

Private Function AlreadyListed(ByRef hits() As Long, ByVal n As Long, ByVal proc As String) As Boolean
    Dim i As Long
    For i = 1 To n
        If mTools(hits(i)).Proc = proc Then AlreadyListed = True: Exit Function
    Next i
End Function

Public Sub XC_RunLastTool()
    Dim proc As String
    proc = GetSetting(REG_APP, "State", "LastTool", "")
    If Len(proc) = 0 Or proc = "XC_RunLastTool" Or proc = "XC_FindAndRunTool" Then
        MsgBox "No previously used tool was recorded yet.", vbInformation, APP_NAME
        Exit Sub
    End If
    Application.Run "'" & ThisWorkbook.Name & "'!" & proc
End Sub

Public Sub XC_ToggleQuietMode()
    Dim cur As String
    cur = GetSetting(REG_APP, "Options", "QuietMode", "0")
    If cur = "1" Then
        SaveSetting REG_APP, "Options", "QuietMode", "0"
        MsgBox "Quiet mode is now OFF. Tools will report what they did.", vbInformation, APP_NAME
    Else
        SaveSetting REG_APP, "Options", "QuietMode", "1"
        MsgBox "Quiet mode is now ON. Result popups are suppressed.", vbInformation, APP_NAME
    End If
End Sub

Public Sub XC_About()
    If mToolCount = 0 Then RegisterTools
    MsgBox APP_NAME & " " & APP_VERSION & vbCrLf & _
           "Open-source utility and modeling toolset for Excel, written in VBA." & vbCrLf & _
           "Independent implementation; contains no third-party code." & vbCrLf & vbCrLf & _
           "Menu entries: " & mToolCount & "   Shortcuts: " & modShortcuts.ShortcutCount(), vbInformation, APP_NAME
End Sub

Public Function ToolCount() As Long
    If mToolCount = 0 Then RegisterTools
    ToolCount = mToolCount
End Function
