Attribute VB_Name = "modModeling"
'==============================================================================
' SPDX-License-Identifier: MIT
' XcelCraft - modModeling
' Modeling tools: smart fill, formula modifiers, hardcode, paste variants,
' function evaluation, data-validation presets, go to min/max, grouping, view.
' Original implementation.
'==============================================================================
Option Explicit

' Row/column info captured by Copy Row/Column Info
Private mRowH() As Double, mRowHidden() As Boolean, mRowLevel() As Long, mRowCount As Long
Private mColW() As Double, mColHidden() As Boolean, mColLevel() As Long, mColCount As Long

'==============================================================================
' Smart Fill
'==============================================================================
' Fills the selection right as far as the neighbouring rows (above/below) have
' data, skipping single blank spacer columns.
Public Sub XC_SmartFillRight()
    On Error GoTo eh
    Dim sel As Range, ws As Worksheet, lastCol As Long, probe As Long
    If TypeName(Selection) <> "Range" Then Exit Sub
    Set sel = Selection.Areas(1)
    Set ws = sel.Worksheet
    lastCol = 0
    If sel.Row > 1 Then lastCol = Max2(lastCol, ExtentRight(ws, sel.Row - 1, sel.Column + sel.Columns.Count - 1))
    If sel.Row + sel.Rows.Count - 1 < ws.Rows.Count Then lastCol = Max2(lastCol, ExtentRight(ws, sel.Row + sel.Rows.Count, sel.Column + sel.Columns.Count - 1))
    If lastCol <= sel.Column + sel.Columns.Count - 1 Then
        ' no guide rows: fall back to the current region's right edge
        lastCol = sel.CurrentRegion.Column + sel.CurrentRegion.Columns.Count - 1
    End If
    If lastCol <= sel.Column + sel.Columns.Count - 1 Then
        MsgBox "Could not determine how far to fill: no data found in the rows above or below the selection.", vbInformation, APP_NAME
        Exit Sub
    End If
    SnapshotRange sel.Resize(, lastCol - sel.Column + 1), "Smart Fill Right"
    SafeStart
    sel.Resize(, lastCol - sel.Column + 1).FillRight
    sel.Resize(, lastCol - sel.Column + 1).Select
    SafeEnd
    Exit Sub
eh:
    ReportError "Smart Fill Right"
End Sub

Public Sub XC_SmartFillDown()
    On Error GoTo eh
    Dim sel As Range, ws As Worksheet, lastRow As Long
    If TypeName(Selection) <> "Range" Then Exit Sub
    Set sel = Selection.Areas(1)
    Set ws = sel.Worksheet
    lastRow = 0
    If sel.Column > 1 Then lastRow = Max2(lastRow, ExtentDown(ws, sel.Column - 1, sel.Row + sel.Rows.Count - 1))
    If sel.Column + sel.Columns.Count - 1 < ws.Columns.Count Then lastRow = Max2(lastRow, ExtentDown(ws, sel.Column + sel.Columns.Count, sel.Row + sel.Rows.Count - 1))
    If lastRow <= sel.Row + sel.Rows.Count - 1 Then lastRow = sel.CurrentRegion.Row + sel.CurrentRegion.Rows.Count - 1
    If lastRow <= sel.Row + sel.Rows.Count - 1 Then
        MsgBox "Could not determine how far to fill: no data found in the columns left or right of the selection.", vbInformation, APP_NAME
        Exit Sub
    End If
    SnapshotRange sel.Resize(lastRow - sel.Row + 1), "Smart Fill Down"
    SafeStart
    sel.Resize(lastRow - sel.Row + 1).FillDown
    sel.Resize(lastRow - sel.Row + 1).Select
    SafeEnd
    Exit Sub
eh:
    ReportError "Smart Fill Down"
End Sub

' Last non-empty column in a row, scanning right from startCol, tolerating one blank spacer column.
Private Function ExtentRight(ByVal ws As Worksheet, ByVal r As Long, ByVal startCol As Long) As Long
    Dim c As Long, blanks As Long, last As Long
    last = 0: blanks = 0
    For c = startCol + 1 To Min2(ws.Columns.Count, startCol + 5000)
        If IsEmpty(ws.Cells(r, c).Value) Then
            blanks = blanks + 1
            If blanks > 1 Then Exit For
        Else
            blanks = 0: last = c
        End If
    Next c
    ExtentRight = last
End Function

Private Function ExtentDown(ByVal ws As Worksheet, ByVal col As Long, ByVal startRow As Long) As Long
    Dim r As Long, blanks As Long, last As Long
    last = 0: blanks = 0
    For r = startRow + 1 To Min2(ws.Rows.Count, startRow + 100000)
        If IsEmpty(ws.Cells(r, col).Value) Then
            blanks = blanks + 1
            If blanks > 1 Then Exit For
        Else
            blanks = 0: last = r
        End If
    Next r
    ExtentDown = last
End Function

'==============================================================================
' Modify formulas
'==============================================================================
' Toggle IFERROR wrapping. Prompts for the fallback value (remembered as default).
Public Sub XC_ErrorGuard()
    Dim v As String
    If SelRange(False, True) Is Nothing Then Exit Sub
    v = AskText("Value or message to show when a formula errors (e.g. 0, NM, n/a):", GetSetting(REG_APP, "Modeling", "ErrorGuardValue", "0"), "Error Guard")
    If StrPtr(v) = 0 Then Exit Sub
    SaveSetting REG_APP, "Modeling", "ErrorGuardValue", v
    ErrorGuardCore v
End Sub

' Same without the prompt (uses the saved default).
Public Sub XC_ErrorGuardQuick()
    ErrorGuardCore GetSetting(REG_APP, "Modeling", "ErrorGuardValue", "0")
End Sub

Private Sub ErrorGuardCore(ByVal v As String)
    On Error GoTo eh
    Dim rng As Range, c As Range, f As String, lit As String, n As Long, inner As String, unwrap As Boolean
    Set rng = SelRange(False, True)
    If rng Is Nothing Then Exit Sub
    If IsNumeric(v) And Len(v) > 0 Then lit = v Else lit = """" & Replace(v, """", """""") & """"
    ' direction: if the first formula cell is wrapped, unwrap everything
    unwrap = False
    For Each c In rng.Cells
        If c.HasFormula Then unwrap = IsIfErrorWrapped(c.Formula): Exit For
    Next c
    SnapshotRange rng, "Error Guard"
    SafeStart
    For Each c In rng.Cells
        If c.HasFormula And Not c.HasArray Then
            f = c.Formula
            If unwrap Then
                If IsIfErrorWrapped(f) Then
                    inner = IfErrorInner(f)
                    c.Formula = "=" & inner: n = n + 1
                End If
            ElseIf Not IsIfErrorWrapped(f) Then
                c.Formula = "=IFERROR(" & Mid$(f, 2) & "," & lit & ")": n = n + 1
            End If
        End If
    Next c
    SafeEnd
    Exit Sub
eh:
    ReportError "Error Guard"
End Sub

Private Function IsIfErrorWrapped(ByVal f As String) As Boolean
    If UCase$(Left$(f, 9)) <> "=IFERROR(" Then Exit Function
    IsIfErrorWrapped = (MatchingParen(f, 9) = Len(f))
End Function

' Returns the first argument of an outermost IFERROR( ... , ... )
Private Function IfErrorInner(ByVal f As String) As String
    Dim i As Long, depth As Long, inQ As Boolean, ch As String
    For i = 10 To Len(f)
        ch = Mid$(f, i, 1)
        If ch = """" Then inQ = Not inQ
        If Not inQ Then
            If ch = "(" Then depth = depth + 1
            If ch = ")" Then depth = depth - 1
            If ch = "," And depth = 0 Then IfErrorInner = Mid$(f, 10, i - 10): Exit Function
        End If
    Next i
    IfErrorInner = Mid$(f, 10, Len(f) - 10)
End Function

' Position of the ")" matching the "(" at position openPos (0 if none).
Public Function MatchingParen(ByVal f As String, ByVal openPos As Long) As Long
    Dim i As Long, depth As Long, inQ As Boolean, ch As String
    For i = openPos To Len(f)
        ch = Mid$(f, i, 1)
        If ch = """" Then inQ = Not inQ
        If Not inQ Then
            If ch = "(" Then depth = depth + 1
            If ch = ")" Then
                depth = depth - 1
                If depth = 0 Then MatchingParen = i: Exit Function
            End If
        End If
    Next i
End Function

' Removes extra spaces and redundant same-sheet names from formulas.
Public Sub XC_CleanCells()
    On Error GoTo eh
    Dim rng As Range, c As Range, f As String, nf As String, n As Long
    Set rng = SelRange(False, True)
    If rng Is Nothing Then Exit Sub
    SnapshotRange rng, "Clean Cells"
    SafeStart
    For Each c In rng.Cells
        If c.HasFormula And Not c.HasArray Then
            f = c.Formula
            nf = CleanFormulaText(f, c.Worksheet.Name)
            If nf <> f Then
                On Error Resume Next
                c.Formula = nf
                If Err.Number = 0 Then n = n + 1
                Err.Clear
                On Error GoTo eh
            End If
        End If
    Next c
    SafeEnd
    Done "Clean Cells: " & Plural(n, "formula") & " cleaned."
    Exit Sub
eh:
    ReportError "Clean Cells"
End Sub

Public Function CleanFormulaText(ByVal f As String, ByVal sheetName As String) As String
    Dim i As Long, ch As String, inQ As Boolean, out As String, prev As String, nxt As String, ops As String
    ops = "+-*/^=<>&,()"
    ' 1. remove same-sheet qualifiers
    f = Replace(f, "'" & Replace(sheetName, "'", "''") & "'!", "")
    f = Replace(f, sheetName & "!", "")
    ' 2. collapse spaces outside quotes next to operators
    For i = 1 To Len(f)
        ch = Mid$(f, i, 1)
        If ch = """" Then inQ = Not inQ
        If ch = " " And Not inQ Then
            prev = IIf(Len(out) > 0, Right$(out, 1), "")
            nxt = IIf(i < Len(f), Mid$(f, i + 1, 1), "")
            If InStr(ops, prev) > 0 Or InStr(ops, nxt) > 0 Or prev = " " Or prev = "" Or nxt = "" Then
                ' drop the space
            Else
                out = out & ch
            End If
        Else
            out = out & ch
        End If
    Next i
    CleanFormulaText = out
End Function

' Cycle anchoring of all references in the selected formulas: A1 -> $A$1 -> A$1 -> $A1
Public Sub XC_AnchorFormula()
    On Error GoTo eh
    Dim rng As Range, i As Long, modes As Variant
    Set rng = SelRange(False, True)
    If rng Is Nothing Then Exit Sub
    modes = Array(xlAbsolute, xlAbsRowRelColumn, xlRelRowAbsColumn, xlRelative)
    i = modFormatCycles.NextCycleIndex("Anchor", 4)
    SafeStart
    modFormulas.ConvertRefsIn rng, modes(i)
    SafeEnd
    Exit Sub
eh:
    ReportError "Anchor Formula"
End Sub

' Negates numeric inputs; multiplies formulas by -1 (toggle).
Public Sub XC_FlipSign()
    On Error GoTo eh
    Dim rng As Range, c As Range, f As String, n As Long, v As Variant
    Set rng = SelRange(False, True)
    If rng Is Nothing Then Exit Sub
    SnapshotRange rng, "Flip Sign"
    SafeStart
    For Each c In rng.Cells
        If c.HasFormula Then
            f = c.Formula
            If Left$(f, 3) = "=-(" And MatchingParen(f, 3) = Len(f) Then
                c.Formula = "=" & Mid$(f, 4, Len(f) - 4)
            Else
                c.Formula = "=-(" & Mid$(f, 2) & ")"
            End If
            n = n + 1
        Else
            v = c.Value
            If IsNumeric(v) And Not IsEmpty(v) And VarType(v) <> vbString And VarType(v) <> vbBoolean Then c.Value = -v: n = n + 1
        End If
    Next c
    SafeEnd
    Exit Sub
eh:
    ReportError "Flip Sign"
End Sub

Public Sub XC_WrapParentheses()
    On Error GoTo eh
    Dim rng As Range, c As Range, n As Long
    Set rng = SelRange(False, True)
    If rng Is Nothing Then Exit Sub
    SnapshotRange rng, "Wrap Parentheses"
    SafeStart
    For Each c In rng.Cells
        If c.HasFormula And Not c.HasArray Then c.Formula = "=(" & Mid$(c.Formula, 2) & ")": n = n + 1
    Next c
    SafeEnd
    Exit Sub
eh:
    ReportError "Wrap Parentheses"
End Sub

' Comment Cells: toggle apostrophe prefix (shared with the utility tool).
Public Sub XC_CommentCells()
    modFormulas.XC_FormulasToText
End Sub

'==============================================================================
' Hardcode (formulas to values)
'==============================================================================
Public Sub XC_HardcodeSelection()
    On Error GoTo eh
    Dim rng As Range, a As Range
    Set rng = SelRange(False, True)
    If rng Is Nothing Then Exit Sub
    SnapshotRange rng, "Hardcode Selection"
    SafeStart
    For Each a In rng.Areas: a.Value = a.Value: Next a
    modFormatCycles.TypeColorCore rng
    SafeEnd
    Exit Sub
eh:
    ReportError "Hardcode Selection"
End Sub

Public Sub XC_HardcodeFunction()
    On Error GoTo eh
    Dim fn As String, scope As Long, ws As Worksheet, n As Long, rng As Range
    fn = AskText("Function name: formulas containing this function are replaced by their values (e.g. VLOOKUP, OFFSET, RAND):", "", "Hardcode Function")
    If Len(fn) = 0 Then Exit Sub
    fn = UCase$(Trim$(fn))
    scope = AskChoice("Scope:", Array("Selected cells", "Selected sheets", "Whole workbook"))
    If scope = 0 Then Exit Sub
    SafeStart "Hardcoding"
    If scope = 1 Then
        Set rng = SelRange(False, True)
        If Not rng Is Nothing Then n = HardcodeFnIn(rng, fn)
    ElseIf scope = 2 Then
        Dim sh As Object
        For Each sh In ActiveWindow.SelectedSheets
            If TypeName(sh) = "Worksheet" Then n = n + HardcodeFnIn(sh.UsedRange, fn)
        Next sh
    Else
        For Each ws In ActiveWorkbook.Worksheets: n = n + HardcodeFnIn(ws.UsedRange, fn): Next ws
    End If
    SafeEnd
    Done "Hardcode Function: " & Plural(n, "formula") & " replaced by values."
    Exit Sub
eh:
    ReportError "Hardcode Function"
End Sub

Private Function HardcodeFnIn(ByVal rng As Range, ByVal fn As String) As Long
    Dim fr As Range, c As Range, n As Long
    On Error Resume Next
    Set fr = rng.SpecialCells(xlCellTypeFormulas)
    On Error GoTo 0
    If fr Is Nothing Then Exit Function
    For Each c In fr.Cells
        If ContainsFunction(c.Formula, fn) Then c.Value = c.Value: n = n + 1
    Next c
    HardcodeFnIn = n
End Function

' True if formula calls the function (name followed by "(", outside quotes, not part of a longer name).
Public Function ContainsFunction(ByVal f As String, ByVal fn As String) As Boolean
    Dim p As Long, before As String, inQ As Boolean, i As Long
    p = 1
    Do
        p = InStr(p, UCase$(f), fn & "(")
        If p = 0 Then Exit Function
        inQ = False
        For i = 1 To p - 1
            If Mid$(f, i, 1) = """" Then inQ = Not inQ
        Next i
        before = IIf(p > 1, Mid$(f, p - 1, 1), " ")
        If Not inQ And Not (IsLetter(before) Or IsDigitChar(before) Or before = "_" Or before = ".") Then ContainsFunction = True: Exit Function
        p = p + 1
    Loop
End Function

' Replaces references to other sheets/workbooks with values so the sheet can stand alone.
Public Sub XC_DetachSheet()
    On Error GoTo eh
    Dim ws As Worksheet, fr As Range, c As Range, n As Long
    Set ws = ActiveSheet
    If Not AskYesNo("Replace every formula on '" & ws.Name & "' that references another sheet or workbook with its current value?" & vbCrLf & "(Chart formulas and names are not changed.)", False) Then Exit Sub
    SafeStart "Detaching"
    On Error Resume Next
    Set fr = ws.UsedRange.SpecialCells(xlCellTypeFormulas)
    On Error GoTo eh
    If Not fr Is Nothing Then
        For Each c In fr.Cells
            If InStr(c.Formula, "!") > 0 Then c.Value = c.Value: n = n + 1
        Next c
    End If
    SafeEnd
    Done "Detach Sheet: " & Plural(n, "formula") & " converted to values."
    Exit Sub
eh:
    ReportError "Detach Sheet"
End Sub

'==============================================================================
' Paste variants (source = range remembered by 'Copy for XcelCraft Paste')
'==============================================================================
Public Sub XC_PasteVerbatim()
    modRange.XC_CopyFormulasExact
End Sub

Public Sub XC_PasteNumberFormats()
    On Error GoTo eh
    Dim src As Range, tgt As Range, r As Long, c As Range, i As Long, j As Long
    Set src = modRange.GetCopySource()
    If src Is Nothing Then Exit Sub
    If TypeName(Selection) <> "Range" Then Exit Sub
    Set tgt = Selection.Cells(1).Resize(src.Rows.Count, src.Columns.Count)
    SnapshotRange tgt, "Paste Number Formats", True
    SafeStart
    For i = 1 To src.Rows.Count
        For j = 1 To src.Columns.Count
            tgt.Cells(i, j).NumberFormat = src.Cells(i, j).NumberFormat
        Next j
    Next i
    Application.CutCopyMode = False
    SafeEnd
    Exit Sub
eh:
    ReportError "Paste Number Formats"
End Sub

Public Sub XC_PasteLinks()
    On Error GoTo eh
    Dim src As Range, tgt As Range, i As Long, j As Long, sc As Range, tc As Range, n As Long, pre As String
    Set src = modRange.GetCopySource()
    If src Is Nothing Then Exit Sub
    If TypeName(Selection) <> "Range" Then Exit Sub
    Set tgt = Selection.Cells(1).Resize(src.Rows.Count, src.Columns.Count)
    SnapshotRange tgt, "Paste Links", True
    SafeStart
    pre = ""
    If src.Worksheet.Name <> tgt.Worksheet.Name Or src.Worksheet.Parent.Name <> tgt.Worksheet.Parent.Name Then
        pre = "'" & IIf(src.Worksheet.Parent.Name <> tgt.Worksheet.Parent.Name, "[" & src.Worksheet.Parent.Name & "]", "") & Replace(src.Worksheet.Name, "'", "''") & "'!"
    End If
    For i = 1 To src.Rows.Count
        For j = 1 To src.Columns.Count
            Set sc = src.Cells(i, j): Set tc = tgt.Cells(i, j)
            If Not IsEmpty(sc.Value) Then
                tc.Formula = "=" & pre & sc.Address(False, False)
                tc.NumberFormat = sc.NumberFormat
                n = n + 1
            End If
        Next j
    Next i
    If GetSetting(REG_APP, "Options", "TypeColorOnEntry", "0") = "1" Then modFormatCycles.TypeColorCore tgt
    Application.CutCopyMode = False
    tgt.Select
    SafeEnd
    Exit Sub
eh:
    ReportError "Paste Links"
End Sub

Public Sub XC_PasteTranspose()
    On Error GoTo eh
    Dim src As Range, tgt As Range, mode As Long, i As Long, j As Long, sc As Range, tc As Range, pre As String
    Set src = modRange.GetCopySource()
    If src Is Nothing Then Exit Sub
    If TypeName(Selection) <> "Range" Then Exit Sub
    mode = AskChoice("Paste transposed as:", Array("Links to the source cells", "Exact formulas (text unchanged)", "Values and number formats"))
    If mode = 0 Then Exit Sub
    If mode = 2 Then modRange.XC_TransposeExact: Exit Sub
    Set tgt = Selection.Cells(1).Resize(src.Columns.Count, src.Rows.Count)
    SnapshotRange tgt, "Paste Transpose", True
    SafeStart
    pre = ""
    If src.Worksheet.Name <> tgt.Worksheet.Name Then pre = "'" & Replace(src.Worksheet.Name, "'", "''") & "'!"
    For i = 1 To src.Rows.Count
        For j = 1 To src.Columns.Count
            Set sc = src.Cells(i, j): Set tc = tgt.Cells(j, i)
            If mode = 1 Then
                If Not IsEmpty(sc.Value) Then tc.Formula = "=" & pre & sc.Address(False, False)
            Else
                tc.Value = sc.Value
            End If
            tc.NumberFormat = sc.NumberFormat
        Next j
    Next i
    Application.CutCopyMode = False
    tgt.Select
    SafeEnd
    Exit Sub
eh:
    ReportError "Paste Transpose"
End Sub

' Paste Keeping Internal Links: formulas keep their text, except references INTO the copied block
' are shifted so they keep pointing at the corresponding copied cells.
Public Sub XC_PasteKeepInternalLinks()
    On Error GoTo eh
    Dim src As Range, tgt As Range, i As Long, j As Long, f As String, dR As Long, dC As Long
    Set src = modRange.GetCopySource()
    If src Is Nothing Then Exit Sub
    If TypeName(Selection) <> "Range" Then Exit Sub
    Set tgt = Selection.Cells(1).Resize(src.Rows.Count, src.Columns.Count)
    dR = tgt.Row - src.Row: dC = tgt.Column - src.Column
    SnapshotRange tgt, "Paste Keeping Internal Links"
    SafeStart
    For i = 1 To src.Rows.Count
        For j = 1 To src.Columns.Count
            f = src.Cells(i, j).Formula
            If Left$(f, 1) = "=" And src.Worksheet.Name = tgt.Worksheet.Name Then
                f = ShiftRefsInsideBlock(f, src, dR, dC)
            End If
            If IsFormulaText(f) Or Len(f) = 0 Then tgt.Cells(i, j).Formula = f Else WriteText tgt.Cells(i, j), f
            tgt.Cells(i, j).NumberFormat = src.Cells(i, j).NumberFormat
        Next j
    Next i
    src.Copy: tgt.PasteSpecial xlPasteFormats
    Application.CutCopyMode = False
    tgt.Select
    SafeEnd
    Exit Sub
eh:
    ReportError "Paste Keeping Internal Links"
End Sub

' Shifts unqualified A1-style references that fall inside the block by (dR, dC).
Public Function ShiftRefsInsideBlock(ByVal f As String, ByVal block As Range, ByVal dR As Long, ByVal dC As Long) As String
    Dim i As Long, ch As String, inQ As Boolean, out As String, tok As String, before As String, after As String
    Dim colPart As String, rowPart As String, absC As Boolean, absR As Boolean, k As Long, colN As Long, rowN As Long, okTok As Boolean
    i = 1
    Do While i <= Len(f)
        ch = Mid$(f, i, 1)
        If ch = """" Then inQ = Not inQ: out = out & ch: i = i + 1: GoTo nxt
        If inQ Then out = out & ch: i = i + 1: GoTo nxt
        ' try to read a token: [$]LETTERS[$]DIGITS
        before = IIf(i > 1, Mid$(f, i - 1, 1), " ")
        If (ch = "$" Or IsLetter(ch)) And Not (IsLetter(before) Or IsDigitChar(before) Or before = "_" Or before = "." Or before = "!" Or before = "$") Then
            k = i: tok = "": absC = False: absR = False: colPart = "": rowPart = ""
            If Mid$(f, k, 1) = "$" Then absC = True: k = k + 1
            Do While k <= Len(f) And IsLetter(Mid$(f, k, 1)) And Len(colPart) < 3
                colPart = colPart & Mid$(f, k, 1): k = k + 1
            Loop
            If Len(colPart) > 0 Then
                If Mid$(f, k, 1) = "$" Then absR = True: k = k + 1
                Do While k <= Len(f) And IsDigitChar(Mid$(f, k, 1)) And Len(rowPart) < 7
                    rowPart = rowPart & Mid$(f, k, 1): k = k + 1
                Loop
            End If
            after = IIf(k <= Len(f), Mid$(f, k, 1), " ")
            okTok = Len(colPart) > 0 And Len(rowPart) > 0 And Not (IsLetter(after) Or IsDigitChar(after) Or after = "_" Or after = "(" Or after = "!")
            If okTok Then
                colN = ColumnNumber(UCase$(colPart)): rowN = CLng(rowPart)
                If colN >= block.Column And colN <= block.Column + block.Columns.Count - 1 And rowN >= block.Row And rowN <= block.Row + block.Rows.Count - 1 Then
                    If rowN + dR >= 1 And colN + dC >= 1 Then
                        out = out & IIf(absC, "$", "") & ColumnLetter(colN + dC) & IIf(absR, "$", "") & (rowN + dR)
                        i = k
                        GoTo nxt
                    End If
                End If
                out = out & Mid$(f, i, k - i)
                i = k
                GoTo nxt
            End If
        End If
        out = out & ch
        i = i + 1
nxt:
    Loop
    ShiftRefsInsideBlock = out
End Function

Public Function ColumnNumber(ByVal letters As String) As Long
    Dim i As Long, n As Long
    For i = 1 To Len(letters)
        n = n * 26 + (Asc(Mid$(letters, i, 1)) - 64)
    Next i
    ColumnNumber = n
End Function

Public Function ColumnLetter(ByVal n As Long) As String
    Dim s As String, m As Long
    Do While n > 0
        m = (n - 1) Mod 26
        s = Chr$(65 + m) & s
        n = (n - 1) \ 26
    Loop
    ColumnLetter = s
End Function

Public Sub XC_PasteInsert()
    On Error GoTo eh
    Dim src As Range, tgt As Range, mode As Long, delSrc As Boolean, wholeRows As Boolean, wholeCols As Boolean
    Set src = modRange.GetCopySource()
    If src Is Nothing Then Exit Sub
    If TypeName(Selection) <> "Range" Then Exit Sub
    Set tgt = Selection.Cells(1)
    wholeRows = (src.Columns.Count = src.Worksheet.Columns.Count)
    wholeCols = (src.Rows.Count = src.Worksheet.Rows.Count)
    If wholeRows Then
        mode = 1
    ElseIf wholeCols Then
        mode = 2
    Else
        mode = AskChoice("Insert the copied cells at " & tgt.Address(False, False) & " by:", Array("Shifting existing cells DOWN", "Shifting existing cells RIGHT"))
        If mode = 0 Then Exit Sub
    End If
    delSrc = AskYesNo("Delete the source cells after inserting (i.e. move instead of copy)?", False)
    SafeStart "Inserting"
    If wholeRows Then
        tgt.EntireRow.Resize(src.Rows.Count).Insert Shift:=xlDown
        Set tgt = tgt.Worksheet.Cells(tgt.Row - src.Rows.Count, 1)
    ElseIf wholeCols Then
        tgt.EntireColumn.Resize(, src.Columns.Count).Insert Shift:=xlToRight
        Set tgt = tgt.Worksheet.Cells(1, tgt.Column - src.Columns.Count)
    Else
        tgt.Resize(src.Rows.Count, src.Columns.Count).Insert Shift:=IIf(mode = 1, xlDown, xlToRight)
        Set tgt = tgt.Worksheet.Cells(tgt.Row - IIf(mode = 1, src.Rows.Count, 0), tgt.Column - IIf(mode = 2, src.Columns.Count, 0))
    End If
    src.Copy tgt
    If delSrc Then
        If wholeRows Then
            src.EntireRow.Delete
        ElseIf wholeCols Then
            src.EntireColumn.Delete
        Else
            src.Delete Shift:=IIf(mode = 1, xlUp, xlToLeft)
        End If
    End If
    Application.CutCopyMode = False
    SafeEnd
    Exit Sub
eh:
    ReportError "Paste Insert"
End Sub

Public Sub XC_CopyRowColInfo()
    On Error GoTo eh
    Dim rng As Range, i As Long
    Set rng = SelRange(False, True)
    If rng Is Nothing Then Exit Sub
    mRowCount = rng.Rows.Count: mColCount = rng.Columns.Count
    ReDim mRowH(1 To mRowCount): ReDim mRowHidden(1 To mRowCount): ReDim mRowLevel(1 To mRowCount)
    ReDim mColW(1 To mColCount): ReDim mColHidden(1 To mColCount): ReDim mColLevel(1 To mColCount)
    For i = 1 To mRowCount
        mRowH(i) = rng.Rows(i).RowHeight: mRowHidden(i) = rng.Rows(i).EntireRow.Hidden: mRowLevel(i) = rng.Rows(i).EntireRow.OutlineLevel
    Next i
    For i = 1 To mColCount
        mColW(i) = rng.Columns(i).ColumnWidth: mColHidden(i) = rng.Columns(i).EntireColumn.Hidden: mColLevel(i) = rng.Columns(i).EntireColumn.OutlineLevel
    Next i
    Application.StatusBar = APP_NAME & ": row/column info of " & rng.Address(False, False) & " captured."
    Exit Sub
eh:
    ReportError "Copy Row/Column Info"
End Sub

Public Sub XC_PasteRowColInfo()
    On Error GoTo eh
    Dim rng As Range, i As Long
    If mRowCount = 0 Then MsgBox "Run 'Copy Row/Column Info' first.", vbInformation, APP_NAME: Exit Sub
    Set rng = SelRange(False, True)
    If rng Is Nothing Then Exit Sub
    SafeStart
    For i = 1 To Min2(mRowCount, rng.Rows.Count)
        rng.Rows(i).RowHeight = mRowH(i): rng.Rows(i).EntireRow.Hidden = mRowHidden(i)
        On Error Resume Next
        rng.Rows(i).EntireRow.OutlineLevel = mRowLevel(i)
        On Error GoTo eh
    Next i
    For i = 1 To Min2(mColCount, rng.Columns.Count)
        rng.Columns(i).ColumnWidth = mColW(i): rng.Columns(i).EntireColumn.Hidden = mColHidden(i)
        On Error Resume Next
        rng.Columns(i).EntireColumn.OutlineLevel = mColLevel(i)
        On Error GoTo eh
    Next i
    SafeEnd
    Exit Sub
eh:
    ReportError "Paste Row/Column Info"
End Sub

'==============================================================================
' Evaluate functions / simplify
'==============================================================================
Public Sub XC_ResolveLookups()
    Dim fns As String
    fns = GetSetting(REG_APP, "Modeling", "ResolveFunctions", "INDEX,VLOOKUP,HLOOKUP,CHOOSE,OFFSET,INDIRECT,IF,MIN,MAX")
    EvaluateFunctionsCore Split(fns, ","), "Resolve Lookups"
End Sub

Public Sub XC_EvaluateFunction()
    Dim fn As String
    fn = AskText("Function to replace by what it evaluates to (a reference where possible, otherwise the value):", "VLOOKUP", "Evaluate Function")
    If Len(fn) = 0 Then Exit Sub
    EvaluateFunctionsCore Array(UCase$(Trim$(fn))), "Evaluate Function"
End Sub

Public Sub XC_ResolveLookupsSettings()
    Dim s As String
    s = AskText("Functions that 'Resolve Lookups' replaces, separated by commas:", GetSetting(REG_APP, "Modeling", "ResolveFunctions", "INDEX,VLOOKUP,HLOOKUP,CHOOSE,OFFSET,INDIRECT,IF,MIN,MAX"), "Resolve Lookups Settings")
    If Len(s) > 0 Then SaveSetting REG_APP, "Modeling", "ResolveFunctions", UCase$(Replace(s, " ", ""))
End Sub

Private Sub EvaluateFunctionsCore(ByVal fns As Variant, ByVal toolName As String)
    On Error GoTo eh
    Dim rng As Range, c As Range, n As Long, reverted As Long, f As String, nf As String, oldV As Variant, fn As Variant, changed As Boolean
    Set rng = SelRange(False, True)
    If rng Is Nothing Then Exit Sub
    SnapshotRange rng, toolName
    SafeStart toolName
    For Each c In rng.Cells
        If c.HasFormula And Not c.HasArray Then
            f = c.Formula: nf = f
            For Each fn In fns
                nf = ReplaceFunctionCalls(nf, UCase$(Trim$(CStr(fn))), c)
            Next fn
            If nf <> f Then
                oldV = c.Value
                On Error Resume Next
                c.Formula = nf
                changed = (Err.Number = 0)
                Err.Clear
                On Error GoTo eh
                If changed And SameValue(oldV, c.Value) Then
                    n = n + 1
                Else
                    c.Formula = f
                    reverted = reverted + 1
                End If
            End If
        End If
    Next c
    SafeEnd
    Done toolName & ": " & Plural(n, "formula") & " simplified" & IIf(reverted > 0, ", " & reverted & " reverted because the result would have changed.", ".")
    Exit Sub
eh:
    ReportError toolName
End Sub

Private Function SameValue(ByVal a As Variant, ByVal b As Variant) As Boolean
    If IsError(a) Or IsError(b) Then SameValue = (IsError(a) And IsError(b)): Exit Function
    If IsNumeric(a) And IsNumeric(b) And VarType(a) <> vbString And VarType(b) <> vbString Then
        SameValue = (Abs(CDbl(a) - CDbl(b)) < 0.000000001 * (1 + Abs(CDbl(a))))
    Else
        SameValue = (CStr(a) = CStr(b))
    End If
End Function

' Replaces each outermost call of fn(...) in f with the reference/value it evaluates to.
Private Function ReplaceFunctionCalls(ByVal f As String, ByVal fn As String, ByVal ctx As Range) As String
    Dim p As Long, q As Long, callS As String, res As Variant, repl As String, before As String, inQ As Boolean, i As Long, searchFrom As Long
    searchFrom = 1
    Do
        p = InStr(searchFrom, UCase$(f), fn & "(")
        If p = 0 Then Exit Do
        inQ = False
        For i = 1 To p - 1
            If Mid$(f, i, 1) = """" Then inQ = Not inQ
        Next i
        before = IIf(p > 1, Mid$(f, p - 1, 1), " ")
        If inQ Or IsLetter(before) Or IsDigitChar(before) Or before = "_" Or before = "." Then
            searchFrom = p + 1
        Else
            q = MatchingParen(f, p + Len(fn))
            If q = 0 Then Exit Do
            callS = Mid$(f, p, q - p + 1)
            repl = EvaluateToText(callS, ctx)
            If Len(repl) > 0 Then
                f = Left$(f, p - 1) & repl & Mid$(f, q + 1)
                searchFrom = p + Len(repl)
            Else
                searchFrom = q + 1
            End If
        End If
    Loop
    ReplaceFunctionCalls = f
End Function

' Evaluates an expression in the context of ctx's sheet; returns a reference
' address if the result is a Range, a literal otherwise, "" on failure.
Private Function EvaluateToText(ByVal expr As String, ByVal ctx As Range) As String
    Dim res As Variant
    On Error GoTo fail
    Set res = Nothing
    If TypeName(ctx.Worksheet.Evaluate(expr)) = "Range" Then
        Set res = ctx.Worksheet.Evaluate(expr)
        If res.Worksheet.Name = ctx.Worksheet.Name Then
            EvaluateToText = res.Address(False, False)
        Else
            EvaluateToText = "'" & Replace(res.Worksheet.Name, "'", "''") & "'!" & res.Address(False, False)
        End If
        Exit Function
    End If
    res = ctx.Worksheet.Evaluate(expr)
    If IsError(res) Then Exit Function
    If IsArray(res) Then Exit Function
    Select Case VarType(res)
        Case vbString: EvaluateToText = """" & Replace(res, """", """""") & """"
        Case vbBoolean: EvaluateToText = UCase$(CStr(res))
        Case vbEmpty: EvaluateToText = "0"
        Case Else: EvaluateToText = Trim$(Str$(res))
    End Select
    Exit Function
fail:
    EvaluateToText = ""
End Function

' Replaces an array TRANSPOSE formula block with direct links to the source cells.
Public Sub XC_EvaluateTranspose()
    On Error GoTo eh
    Dim c As Range, blk As Range, f As String, inner As String, src As Range, i As Long, j As Long, pre As String
    If TypeName(Selection) <> "Range" Then Exit Sub
    Set c = ActiveCell
    If Not c.HasArray Then MsgBox "Select a cell inside an array formula of the form =TRANSPOSE(range).", vbInformation, APP_NAME: Exit Sub
    Set blk = c.CurrentArray
    f = blk.Cells(1).FormulaArray
    If UCase$(Left$(f, 11)) <> "=TRANSPOSE(" Then MsgBox "The array formula is not =TRANSPOSE(range).", vbInformation, APP_NAME: Exit Sub
    inner = Mid$(f, 12, Len(f) - 12)
    Set src = c.Worksheet.Evaluate(inner)
    If src Is Nothing Then Exit Sub
    SnapshotRange blk, "Evaluate TRANSPOSE"
    SafeStart
    blk.ClearContents
    pre = ""
    If src.Worksheet.Name <> blk.Worksheet.Name Then pre = "'" & Replace(src.Worksheet.Name, "'", "''") & "'!"
    For i = 1 To Min2(blk.Rows.Count, src.Columns.Count)
        For j = 1 To Min2(blk.Columns.Count, src.Rows.Count)
            blk.Cells(i, j).Formula = "=" & pre & src.Cells(j, i).Address(False, False)
        Next j
    Next i
    SafeEnd
    Exit Sub
eh:
    ReportError "Evaluate TRANSPOSE"
End Sub

'==============================================================================
' Data validation presets
'==============================================================================
Public Sub XC_DataValidationPreset()
    On Error GoTo eh
    Dim rng As Range, mode As Long, a1 As String
    Set rng = SelRange(False, True)
    If rng Is Nothing Then Exit Sub
    mode = AskChoice("Apply data validation to the selection:", Array( _
        "Toggle (0 or 1)", "Number (any numeric input)", "Date (within 30 years of today)", "Text only", _
        "Greater than or equal to zero", "Less than or equal to zero", "Positive percent (0% to 100%)", "Any percent (-100% to 100%)", "Remove validation"))
    If mode = 0 Then Exit Sub
    a1 = rng.Cells(1).Address(False, False)
    SafeStart
    rng.Validation.Delete
    Select Case mode
        Case 1: rng.Validation.Add Type:=xlValidateWholeNumber, AlertStyle:=xlValidAlertStop, Operator:=xlBetween, Formula1:="0", Formula2:="1"
        Case 2: rng.Validation.Add Type:=xlValidateDecimal, AlertStyle:=xlValidAlertStop, Operator:=xlBetween, Formula1:="-1E+300", Formula2:="1E+300"
        Case 3: rng.Validation.Add Type:=xlValidateDate, AlertStyle:=xlValidAlertStop, Operator:=xlBetween, Formula1:=CStr(CLng(DateSerial(Year(Date) - 30, Month(Date), Day(Date)))), Formula2:=CStr(CLng(DateSerial(Year(Date) + 30, Month(Date), Day(Date))))
        Case 4: rng.Validation.Add Type:=xlValidateCustom, AlertStyle:=xlValidAlertStop, Formula1:="=ISTEXT(" & a1 & ")"
        Case 5: rng.Validation.Add Type:=xlValidateDecimal, AlertStyle:=xlValidAlertStop, Operator:=xlGreaterEqual, Formula1:="0"
        Case 6: rng.Validation.Add Type:=xlValidateDecimal, AlertStyle:=xlValidAlertStop, Operator:=xlLessEqual, Formula1:="0"
        Case 7: rng.Validation.Add Type:=xlValidateDecimal, AlertStyle:=xlValidAlertStop, Operator:=xlBetween, Formula1:="0", Formula2:="1"
        Case 8: rng.Validation.Add Type:=xlValidateDecimal, AlertStyle:=xlValidAlertStop, Operator:=xlBetween, Formula1:="-1", Formula2:="1"
    End Select
    If mode < 9 Then rng.Validation.ErrorMessage = "Input does not meet the validation rule for this cell."
    SafeEnd
    Exit Sub
eh:
    ReportError "Data Validation Preset"
End Sub

'==============================================================================
' Go to min / max
'==============================================================================
Public Sub XC_GoToMin(): GoToExtreme True: End Sub
Public Sub XC_GoToMax(): GoToExtreme False: End Sub

Private Sub GoToExtreme(ByVal wantMin As Boolean)
    On Error GoTo eh
    Dim rng As Range, c As Range, best As Range, v As Variant
    Set rng = SelRangeOrRegion()
    If rng Is Nothing Then Exit Sub
    For Each c In rng.Cells
        v = c.Value
        If IsNumeric(v) And Not IsEmpty(v) And VarType(v) <> vbString And VarType(v) <> vbBoolean Then
            If best Is Nothing Then
                Set best = c
            ElseIf (wantMin And v < best.Value) Or (Not wantMin And v > best.Value) Then
                Set best = c
            End If
        End If
    Next c
    If best Is Nothing Then MsgBox "No numeric values found.", vbInformation, APP_NAME Else best.Select
    Exit Sub
eh:
    ReportError IIf(wantMin, "Go to Min", "Go to Max")
End Sub

'==============================================================================
' Rows & columns grouping
'==============================================================================
Public Sub XC_GroupRows()
    On Error Resume Next
    If TypeName(Selection) <> "Range" Then Exit Sub
    Selection.Rows.Group
End Sub
Public Sub XC_UngroupRows()
    On Error Resume Next
    If TypeName(Selection) <> "Range" Then Exit Sub
    Selection.Rows.Ungroup
End Sub
Public Sub XC_GroupColumns()
    On Error Resume Next
    If TypeName(Selection) <> "Range" Then Exit Sub
    Selection.Columns.Group
End Sub
Public Sub XC_UngroupColumns()
    On Error Resume Next
    If TypeName(Selection) <> "Range" Then Exit Sub
    Selection.Columns.Ungroup
End Sub
Public Sub XC_ExpandAllRows()
    On Error Resume Next
    ActiveSheet.Outline.ShowLevels RowLevels:=8
End Sub
Public Sub XC_CollapseAllRows()
    On Error Resume Next
    ActiveSheet.Outline.ShowLevels RowLevels:=1
End Sub
Public Sub XC_ExpandAllColumns()
    On Error Resume Next
    ActiveSheet.Outline.ShowLevels ColumnLevels:=8
End Sub
Public Sub XC_CollapseAllColumns()
    On Error Resume Next
    ActiveSheet.Outline.ShowLevels ColumnLevels:=1
End Sub

'==============================================================================
' View
'==============================================================================
Public Sub XC_ToggleGridlines()
    On Error Resume Next
    ActiveWindow.DisplayGridlines = Not ActiveWindow.DisplayGridlines
End Sub
Public Sub XC_HidePageBreaks()
    On Error Resume Next
    ActiveSheet.DisplayPageBreaks = False
End Sub
Public Sub XC_ZoomIn()
    On Error Resume Next
    ActiveWindow.Zoom = Min2(400, ActiveWindow.Zoom + 10)
End Sub
Public Sub XC_ZoomOut()
    On Error Resume Next
    ActiveWindow.Zoom = Max2(10, ActiveWindow.Zoom - 10)
End Sub
