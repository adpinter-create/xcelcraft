Attribute VB_Name = "modImportExport"
'==============================================================================
' SPDX-License-Identifier: MIT
' XcelCraft - modImportExport
' Import and Export categories. Original implementation.
'==============================================================================
Option Explicit

Private Function PickFile(ByVal title As String, ByVal filter As String, Optional ByVal multi As Boolean = False) As Variant
    Dim f As Variant
    #If Mac Then
        f = Application.GetOpenFilename(, , title, , multi)
    #Else
        f = Application.GetOpenFilename(filter, , title, , multi)
    #End If
    PickFile = f
End Function

'==============================================================================
' Import
'==============================================================================
Public Sub XC_ImportExcelFile()
    On Error GoTo eh
    Dim f As Variant, src As Workbook, dst As Workbook, sh As Object, s As String, i As Long, pick As String, parts() As String, p As Variant, n As Long, names As Collection, nm As Variant
    f = PickFile("Select the Excel file to import sheets from", "Excel files (*.xls*), *.xls*")
    If VarType(f) = vbBoolean Then Exit Sub
    Set dst = ActiveWorkbook
    SafeStart "Opening"
    Set src = Workbooks.Open(CStr(f), ReadOnly:=True, UpdateLinks:=0)
    SafeEnd
    For i = 1 To src.Sheets.Count: s = s & i & ". " & src.Sheets(i).Name & vbCrLf: Next i
    pick = AskText("Sheets in " & src.Name & ". Enter the numbers to import, separated by commas, or * for all:" & vbCrLf & vbCrLf & s, "*", "Import Excel File")
    If Len(pick) = 0 Then src.Close False: Exit Sub
    parts = Split(Replace(pick, " ", ""), ",")
    Set names = New Collection
    For i = 1 To src.Sheets.Count
        For Each p In parts
            If p = "*" Or Val(p) = i Then names.Add src.Sheets(i).Name: Exit For
        Next p
    Next i
    SafeStart "Importing"
    For Each nm In names
        src.Sheets(nm).Copy After:=dst.Sheets(dst.Sheets.Count)
        n = n + 1
    Next nm
    src.Close SaveChanges:=False
    SafeEnd
    Done "Import Excel File: " & Plural(n, "sheet") & " imported."
    Exit Sub
eh:
    ReportError "Import Excel File into Workbook"
End Sub

' Core delimited-text importer. delim: one character, or "TAB", "SPACE", "WIZARD".
Private Sub ImportDelimited(ByVal delim As String, ByVal toolName As String, Optional ByVal askOptions As Boolean = False)
    On Error GoTo eh
    Dim f As Variant, ws As Worksheet, qt As QueryTable, tgt As Range, startRow As Variant, textQual As Long, dst As Workbook, where As Long, hdr As Boolean
    f = PickFile("Select the text file to import", "Text files (*.txt;*.csv;*.prn;*.dat;*.tsv), *.txt;*.csv;*.prn;*.dat;*.tsv, All files (*.*), *.*")
    If VarType(f) = vbBoolean Then Exit Sub
    Set dst = ActiveWorkbook
    If delim = "WIZARD" Then
        Workbooks.OpenText Filename:=CStr(f)
        Exit Sub
    End If
    startRow = 1: textQual = xlTextQualifierDoubleQuote
    If askOptions Then
        delim = AskText("Delimiter character (use TAB or SPACE for those):", ",", toolName)
        If Len(delim) = 0 Then Exit Sub
        startRow = AskNumber("Start importing at row:", 1, toolName, 1)
        If IsEmpty(startRow) Then Exit Sub
        Dim tq As Long
        tq = AskChoice("Text qualifier:", Array("Double quote """, "Single quote '", "None"))
        If tq = 0 Then Exit Sub
        textQual = Choose(tq, xlTextQualifierDoubleQuote, xlTextQualifierSingleQuote, xlTextQualifierNone)
    End If
    where = AskChoice("Import into:", Array("A new worksheet in this workbook", "The active cell (data goes to the right/below)"))
    If where = 0 Then Exit Sub
    SafeStart "Importing"
    If where = 1 Then
        Set ws = dst.Worksheets.Add(After:=dst.Sheets(dst.Sheets.Count))
        ws.Name = UniqueSheetName(StripName(CStr(f)))
        Set tgt = ws.Range("A1")
    Else
        Set tgt = ActiveCell
    End If
    Set qt = tgt.Worksheet.QueryTables.Add(Connection:="TEXT;" & CStr(f), Destination:=tgt)
    With qt
        .TextFileStartRow = startRow
        .TextFileParseType = xlDelimited
        .TextFileTextQualifier = textQual
        .TextFileConsecutiveDelimiter = (UCase$(delim) = "SPACE")
        .TextFileTabDelimiter = (UCase$(delim) = "TAB")
        .TextFileSpaceDelimiter = (UCase$(delim) = "SPACE")
        .TextFileCommaDelimiter = (delim = ",")
        .TextFileSemicolonDelimiter = (delim = ";")
        If Len(delim) = 1 And delim <> "," And delim <> ";" Then .TextFileOtherDelimiter = delim
        .TextFilePlatform = 65001
        .RefreshStyle = xlOverwriteCells
        .AdjustColumnWidth = True
        .Refresh BackgroundQuery:=False
        .Delete
    End With
    SafeEnd
    Done toolName & ": imported " & CStr(f)
    Exit Sub
eh:
    ReportError toolName
End Sub

Private Function StripName(ByVal p As String) As String
    Dim s As String
    s = Mid$(p, InStrRev(p, Application.PathSeparator) + 1)
    If InStrRev(s, ".") > 0 Then s = Left$(s, InStrRev(s, ".") - 1)
    StripName = s
End Function

Public Sub XC_ImportDelimitedCustom(): ImportDelimited ",", "Import Delimited Text File", True: End Sub
Public Sub XC_ImportSpaceDelimited(): ImportDelimited "SPACE", "Import Space-Delimited Text File": End Sub
Public Sub XC_ImportTabDelimited(): ImportDelimited "TAB", "Import Tab-Delimited Text File": End Sub
Public Sub XC_ImportCsv(): ImportDelimited ",", "Import Comma-Delimited (CSV) File": End Sub
Public Sub XC_ImportPipeDelimited(): ImportDelimited "|", "Import Pipe-Delimited Text File": End Sub
Public Sub XC_ImportExclamationDelimited(): ImportDelimited "!", "Import Exclamation-Delimited Text File": End Sub
Public Sub XC_ImportTextWizard(): ImportDelimited "WIZARD", "Import Text File Using Wizard": End Sub

Public Sub XC_ImportDbf()
    MsgBox "Modern Excel can no longer open dBASE (.dbf) files directly. Convert the file with another tool (e.g. LibreOffice) to CSV and use the CSV import.", vbInformation, APP_NAME
End Sub

' Merge several text/CSV/Excel files into one sheet (stacked), with a source column.
Public Sub XC_MergeImportMultiple()
    On Error GoTo eh
    Dim files As Variant, i As Long, dst As Worksheet, nextRow As Long, hdrRows As Variant, first As Boolean, p As String, src As Workbook, ur As Range, startRow As Long, n As Long, tmp As Worksheet, rowsCopied As Long
    files = PickFile("Select the files to merge (Ctrl+click for several)", "Data files (*.csv;*.txt;*.xls*), *.csv;*.txt;*.xls*", True)
    If VarType(files) = vbBoolean Then Exit Sub
    hdrRows = AskNumber("Header rows in each file (copied once, from the first file):", 1, "Merge and Import", 0, 50)
    If IsEmpty(hdrRows) Then Exit Sub
    SafeStart "Merging"
    Set dst = NewReportSheet("Merged", False)
    nextRow = 1: first = True
    For i = LBound(files) To UBound(files)
        p = CStr(files(i))
        If LCase$(Right$(p, 4)) = ".csv" Or LCase$(Right$(p, 4)) = ".txt" Then
            Workbooks.OpenText Filename:=p, DataType:=xlDelimited, Comma:=(LCase$(Right$(p, 4)) = ".csv"), Tab:=True, TextQualifier:=xlTextQualifierDoubleQuote
            Set src = ActiveWorkbook
        Else
            Set src = Workbooks.Open(p, ReadOnly:=True, UpdateLinks:=0)
        End If
        Set tmp = src.Worksheets(1)
        Set ur = tmp.UsedRange
        startRow = IIf(first Or hdrRows = 0, 1, hdrRows + 1)
        If startRow <= ur.Rows.Count Then
            rowsCopied = ur.Rows.Count - startRow + 1
            ur.Rows(startRow).Resize(rowsCopied).Copy dst.Cells(nextRow, 1)
            dst.Cells(nextRow, ur.Columns.Count + 1).Resize(rowsCopied).Value = src.Name
            If first And hdrRows > 0 Then dst.Cells(1, ur.Columns.Count + 1).Value = "Source file"
            nextRow = nextRow + rowsCopied
            first = False
        End If
        src.Close SaveChanges:=False
        n = n + 1
    Next i
    dst.Columns.AutoFit
    dst.Activate
    SafeEnd
    Done "Merge and Import: " & Plural(n, "file") & " merged on sheet '" & dst.Name & "'."
    Exit Sub
eh:
    ReportError "Merge and Import Multiple Files"
End Sub

'==============================================================================
' Export
'==============================================================================
Private Function ExportTarget(ByVal defaultName As String, ByVal fmt As Long) As String
    Dim ext As String, filt As String, f As Variant
    Select Case fmt
        Case 1: ext = ".xlsx": filt = "Excel Workbook (*.xlsx), *.xlsx"
        Case 2: ext = ".pdf": filt = "PDF (*.pdf), *.pdf"
        Case 3: ext = ".csv": filt = "CSV (*.csv), *.csv"
        Case 4: ext = ".txt": filt = "Tab-delimited text (*.txt), *.txt"
        Case 5: ext = ".htm": filt = "Web page (*.htm), *.htm"
    End Select
    f = Application.GetSaveAsFilename(InitialFileName:=defaultName & ext, FileFilter:=filt)
    If VarType(f) = vbBoolean Then Exit Function
    ExportTarget = CStr(f)
End Function

Public Sub XC_ExportSelectionOrSheet()
    On Error GoTo eh
    Dim what As Long, fmt As Long, f As String, src As Range, ws As Worksheet, wb As Workbook, nm As String
    what = AskChoice("Export:", Array("The selection", "The active sheet"))
    If what = 0 Then Exit Sub
    fmt = AskChoice("Format:", Array("Excel workbook (.xlsx)", "PDF", "CSV (comma-separated)", "Text (tab-delimited)", "Web page (.htm)"))
    If fmt = 0 Then Exit Sub
    nm = ActiveSheet.Name & IIf(what = 1, " selection", "")
    f = ExportTarget(nm, fmt)
    If Len(f) = 0 Then Exit Sub
    SafeStart "Exporting"
    If what = 1 Then
        Set src = SelRange()
        If src Is Nothing Then SafeEnd: Exit Sub
        If fmt = 2 Then
            src.ExportAsFixedFormat xlTypePDF, f
        Else
            Set wb = Workbooks.Add(xlWBATWorksheet)
            src.Copy
            wb.Worksheets(1).Range("A1").PasteSpecial xlPasteValuesAndNumberFormats
            wb.Worksheets(1).Range("A1").PasteSpecial xlPasteFormats
            wb.Worksheets(1).Range("A1").PasteSpecial xlPasteColumnWidths
            Application.CutCopyMode = False
            SaveNewWorkbook wb, f, fmt
        End If
    Else
        Set ws = ActiveSheet
        If fmt = 2 Then
            ws.ExportAsFixedFormat xlTypePDF, f
        Else
            ws.Copy
            Set wb = ActiveWorkbook
            SaveNewWorkbook wb, f, fmt
        End If
    End If
    SafeEnd
    Done "Exported to " & f
    Exit Sub
eh:
    ReportError "Export Selection or Sheet to New File"
End Sub

Private Sub SaveNewWorkbook(ByVal wb As Workbook, ByVal f As String, ByVal fmt As Long)
    Application.DisplayAlerts = False
    Select Case fmt
        Case 1: wb.SaveAs f, xlOpenXMLWorkbook
        Case 3: wb.SaveAs f, xlCSV
        Case 4: wb.SaveAs f, xlText
        Case 5: wb.SaveAs f, xlHtml
    End Select
    wb.Close SaveChanges:=False
    Application.DisplayAlerts = True
End Sub

Public Sub XC_ExportSheetsSeparately()
    On Error GoTo eh
    Dim fmt As Long, folder As String, sh As Object, n As Long, f As String, wb As Workbook, names As Collection, nm As Variant, scope As Long, ws As Worksheet
    scope = AskChoice("Export which sheets, each to its own file?", Array("Selected sheets (" & ActiveWindow.SelectedSheets.Count & ")", "All worksheets"))
    If scope = 0 Then Exit Sub
    fmt = AskChoice("Format:", Array("Excel workbook (.xlsx)", "PDF", "CSV (comma-separated)", "Text (tab-delimited)", "Web page (.htm)"))
    If fmt = 0 Then Exit Sub
    folder = modFill.PickFolder()
    If Len(folder) = 0 Then Exit Sub
    If Right$(folder, 1) <> Application.PathSeparator Then folder = folder & Application.PathSeparator
    Set names = New Collection
    If scope = 1 Then
        For Each sh In ActiveWindow.SelectedSheets: If TypeName(sh) = "Worksheet" Then names.Add sh.Name
        Next sh
    Else
        For Each ws In ActiveWorkbook.Worksheets: names.Add ws.Name: Next ws
    End If
    SafeStart "Exporting sheets"
    For Each nm In names
        Set ws = ActiveWorkbook.Worksheets(nm)
        f = folder & SafeFileName(CStr(nm)) & Choose(fmt, ".xlsx", ".pdf", ".csv", ".txt", ".htm")
        If fmt = 2 Then
            ws.ExportAsFixedFormat xlTypePDF, f
        Else
            ws.Copy
            Set wb = ActiveWorkbook
            SaveNewWorkbook wb, f, fmt
        End If
        n = n + 1
    Next nm
    SafeEnd
    Done "Export Worksheets as Separate Files: " & Plural(n, "file") & " written to " & folder
    Exit Sub
eh:
    Application.DisplayAlerts = True
    ReportError "Export Worksheets as Separate Files"
End Sub

Public Function SafeFileName(ByVal s As String) As String
    Dim bad As Variant, i As Long
    bad = Array("\", "/", ":", "*", "?", """", "<", ">", "|")
    For i = LBound(bad) To UBound(bad): s = Replace(s, bad(i), "_"): Next i
    SafeFileName = s
End Function

Public Sub XC_ExportAsImage()
    On Error GoTo eh
    Dim f As Variant, ch As ChartObject, rng As Range, ws As Worksheet, ext As String, isChart As Boolean
    If TypeName(Selection) = "Range" Then
        Set rng = Selection
    ElseIf Not ActiveChart Is Nothing Then
        isChart = True
    Else
        MsgBox "Select a range or a chart first.", vbInformation, APP_NAME: Exit Sub
    End If
    f = Application.GetSaveAsFilename(InitialFileName:="export.png", FileFilter:="PNG (*.png), *.png, JPEG (*.jpg), *.jpg, GIF (*.gif), *.gif")
    If VarType(f) = vbBoolean Then Exit Sub
    ext = UCase$(Mid$(f, InStrRev(f, ".") + 1))
    If ext = "JPEG" Then ext = "JPG"
    SafeStart "Exporting image"
    If isChart Then
        ActiveChart.Export Filename:=CStr(f), FilterName:=ext
    Else
        Set ws = rng.Worksheet
        rng.CopyPicture Appearance:=xlScreen, Format:=xlPicture
        Set ch = ws.ChartObjects.Add(rng.Left, rng.Top, rng.Width, rng.Height)
        ch.Chart.Paste
        ch.Chart.Export Filename:=CStr(f), FilterName:=ext
        ch.Delete
    End If
    SafeEnd
    Done "Image saved: " & f
    Exit Sub
eh:
    ReportError "Export Selected Chart or Range as Image"
End Sub

Public Sub XC_CopyValuesToClipboard()
    On Error GoTo eh
    Dim rng As Range, r As Long, c As Long, s As String, ln As String
    Set rng = SelRange()
    If rng Is Nothing Then Exit Sub
    If rng.Areas.Count > 1 Then Set rng = rng.Areas(1)
    For r = 1 To rng.Rows.Count
        ln = ""
        For c = 1 To rng.Columns.Count
            ln = ln & IIf(c > 1, vbTab, "") & rng.Cells(r, c).Text
        Next c
        s = s & ln & IIf(r < rng.Rows.Count, vbCrLf, "")
    Next r
    SetClipboardText s
    Application.StatusBar = APP_NAME & ": values of " & rng.Address(False, False) & " copied as text."
    Exit Sub
eh:
    ReportError "Copy Selection as Values to Clipboard"
End Sub

Public Sub XC_CopySumToClipboard()
    On Error GoTo eh
    Dim rng As Range, v As Double
    Set rng = SelRange()
    If rng Is Nothing Then Exit Sub
    v = Application.WorksheetFunction.Sum(rng)
    SetClipboardText CStr(v)
    Application.StatusBar = APP_NAME & ": sum " & v & " copied."
    Exit Sub
eh:
    ReportError "Copy Sum to Clipboard"
End Sub

Public Sub XC_CopyAverageToClipboard()
    On Error GoTo eh
    Dim rng As Range, v As Double
    Set rng = SelRange()
    If rng Is Nothing Then Exit Sub
    If Application.WorksheetFunction.Count(rng) = 0 Then MsgBox "No numbers in the selection.", vbInformation, APP_NAME: Exit Sub
    v = Application.WorksheetFunction.Average(rng)
    SetClipboardText CStr(v)
    Application.StatusBar = APP_NAME & ": average " & v & " copied."
    Exit Sub
eh:
    ReportError "Copy Average to Clipboard"
End Sub

Private Sub CopyAsPicture(ByVal appearance As Long, ByVal fmt As Long, ByVal nm As String)
    On Error GoTo eh
    Dim rng As Range
    Set rng = SelRange()
    If rng Is Nothing Then Exit Sub
    rng.Areas(1).CopyPicture Appearance:=appearance, Format:=fmt
    Application.StatusBar = APP_NAME & ": " & nm & " copied. Paste it where you need it."
    Exit Sub
eh:
    ReportError nm
End Sub

Public Sub XC_CopyAsBitmap(): CopyAsPicture xlScreen, xlBitmap, "Bitmap picture (as shown on screen)": End Sub
Public Sub XC_CopyAsPictureScreen(): CopyAsPicture xlScreen, xlPicture, "Picture (as shown on screen)": End Sub
Public Sub XC_CopyAsPicturePrinted(): CopyAsPicture xlPrinter, xlPicture, "Picture (as shown when printed)": End Sub
