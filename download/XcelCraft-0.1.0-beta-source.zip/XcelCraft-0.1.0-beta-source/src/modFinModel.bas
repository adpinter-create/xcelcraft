Attribute VB_Name = "modFinModel"
'==============================================================================
' SPDX-License-Identifier: MIT
' XcelCraft - modFinModel
' Financial-modeling helpers: Quick CAGR, summary statistics, duplicate block,
' sum copies, insert symbol. Original implementation.
'==============================================================================
Option Explicit

'--- Quick CAGR ----------------------------------------------------------------------
' Select a row (or column) of values; the CAGR formula is written in the cell right
' after (below) the selection: =(last/first)^(1/periods)-1, periods = count-1,
' optionally divided for quarterly/monthly data to annualize.
Public Sub XC_QuickCagr()
    On Error GoTo eh
    Dim rng As Range, first As Range, last As Range, n As Long, tgt As Range, perYear As Long, mode As Long, f As String, horizontal As Boolean, c As Range
    Set rng = SelRange(True)
    If rng Is Nothing Then Exit Sub
    If rng.Areas.Count > 1 Then MsgBox "Select a single row or column of values.", vbExclamation, APP_NAME: Exit Sub
    If rng.Rows.Count > 1 And rng.Columns.Count > 1 Then MsgBox "Select a single row or column of values.", vbExclamation, APP_NAME: Exit Sub
    horizontal = (rng.Rows.Count = 1)
    ' first and last numeric cells
    For Each c In rng.Cells
        If IsNumeric(c.Value) And Not IsEmpty(c.Value) And VarType(c.Value) <> vbString Then
            If first Is Nothing Then Set first = c
            Set last = c
        End If
    Next c
    If first Is Nothing Or first.Address = last.Address Then MsgBox "Need at least two numeric values.", vbExclamation, APP_NAME: Exit Sub
    If horizontal Then n = last.Column - first.Column Else n = last.Row - first.Row
    mode = AskChoice("Period of the data:", Array("Annual (CAGR per period)", "Quarterly (annualized)", "Monthly (annualized)"))
    If mode = 0 Then Exit Sub
    perYear = Choose(mode, 1, 4, 12)
    If horizontal Then Set tgt = last.Offset(0, 1) Else Set tgt = last.Offset(1, 0)
    If Not IsEmpty(tgt.Value) Then
        If Not AskYesNo("Cell " & tgt.Address(False, False) & " is not empty. Overwrite it with the CAGR formula?", False) Then Exit Sub
    End If
    f = "=(" & last.Address(False, False) & "/" & first.Address(False, False) & ")^(" & perYear & "/" & n & ")-1"
    SnapshotRange tgt, "Quick CAGR"
    tgt.Formula = f
    tgt.NumberFormat = "0.0%"
    tgt.Select
    Exit Sub
eh:
    ReportError "Quick CAGR"
End Sub

'--- Summary statistics ------------------------------------------------------------
Public Sub XC_SummaryStatistics()
    On Error GoTo eh
    Dim rng As Range, stats As String, items() As String, i As Long, r As Long, c As Long, ws As Worksheet, lbl As String, fn As String
    Dim colRng As Range, tgtRow As Long, labelCol As Long, insertRows As Boolean, excludeCurrency As Boolean, nf As String, addr As String
    Set rng = SelRangeOrRegion()
    If rng Is Nothing Then Exit Sub
    If rng.Areas.Count > 1 Then MsgBox "Please select one rectangular range.", vbExclamation, APP_NAME: Exit Sub
    Set ws = rng.Worksheet
    stats = GetSetting(REG_APP, "Modeling", "SummaryStats", "Min=MIN;Max=MAX;Mean=AVERAGE;Median=MEDIAN")
    items = Split(stats, ";")
    insertRows = AskYesNo("Insert new rows below the selection for the statistics?" & vbCrLf & "(No = write into the existing rows below)")
    labelCol = rng.Column - 1
    If labelCol < 1 Then labelCol = rng.Column
    SafeStart "Inserting statistics"
    tgtRow = rng.Row + rng.Rows.Count
    If insertRows Then ws.Rows(tgtRow).Resize(UBound(items) + 1).Insert Shift:=xlDown
    For i = 0 To UBound(items)
        lbl = Split(items(i), "=")(0): fn = Split(items(i), "=")(1)
        ws.Cells(tgtRow + i, labelCol).Value = lbl
        ws.Cells(tgtRow + i, labelCol).Font.Italic = True
        For c = 1 To rng.Columns.Count
            Set colRng = rng.Columns(c)
            If Application.WorksheetFunction.Count(colRng) > 0 And (labelCol <> rng.Column Or c > 1) Then
                addr = colRng.Address(False, False)
                ws.Cells(tgtRow + i, rng.Column + c - 1).Formula = "=" & fn & "(" & addr & ")"
                nf = colRng.Cells(colRng.Rows.Count).NumberFormat
                If nf = "General" Then nf = "#,##0.0"
                ws.Cells(tgtRow + i, rng.Column + c - 1).NumberFormat = nf
            End If
        Next c
    Next i
    ws.Range(ws.Cells(tgtRow, rng.Column), ws.Cells(tgtRow, rng.Column + rng.Columns.Count - 1)).Borders(xlEdgeTop).LineStyle = xlContinuous
    SafeEnd
    Exit Sub
eh:
    ReportError "Summary Statistics"
End Sub

Public Sub XC_SummaryStatisticsSettings()
    Dim s As String
    s = AskText("Statistics to insert, as Label=FUNCTION pairs separated by semicolons:", _
                GetSetting(REG_APP, "Modeling", "SummaryStats", "Min=MIN;Max=MAX;Mean=AVERAGE;Median=MEDIAN"), "Summary Statistics Settings")
    If Len(s) > 0 And InStr(s, "=") > 0 Then SaveSetting REG_APP, "Modeling", "SummaryStats", s
End Sub

'--- Duplicate block -----------------------------------------------------------------
Public Sub XC_DuplicateBlock()
    On Error GoTo eh
    Dim rng As Range, copies As Variant, mode As Long, gap As Variant, i As Long, tgt As Range, ws As Worksheet, nm As String, baseNm As String
    Set rng = SelRange()
    If rng Is Nothing Then Exit Sub
    If rng.Areas.Count > 1 Then MsgBox "Please select one rectangular range.", vbExclamation, APP_NAME: Exit Sub
    copies = AskNumber("Number of copies to create:", GetSetting(REG_APP, "Modeling", "DuplicateCopies", "3"), "Duplicate Block", 1, 500)
    If IsEmpty(copies) Then Exit Sub
    mode = AskChoice("Place the copies:", Array("Below the original on the same sheet", "To the right of the original on the same sheet", "Each on a new worksheet"))
    If mode = 0 Then Exit Sub
    If mode < 3 Then
        gap = AskNumber("Empty rows/columns between copies:", GetSetting(REG_APP, "Modeling", "DuplicateGap", "1"), "Duplicate Block", 0, 100)
        If IsEmpty(gap) Then Exit Sub
        SaveSetting REG_APP, "Modeling", "DuplicateGap", CStr(gap)
    Else
        baseNm = AskText("Base name for the new sheets (a number is appended):", GetSetting(REG_APP, "Modeling", "DuplicateBase", "Case"), "Duplicate Block")
        If Len(baseNm) = 0 Then Exit Sub
        SaveSetting REG_APP, "Modeling", "DuplicateBase", baseNm
    End If
    SaveSetting REG_APP, "Modeling", "DuplicateCopies", CStr(copies)
    SafeStart "Duplicating"
    For i = 1 To copies
        If mode = 1 Then
            Set tgt = rng.Offset(i * (rng.Rows.Count + gap), 0)
            rng.Copy tgt
            tgt.RowHeight = rng.RowHeight
        ElseIf mode = 2 Then
            Set tgt = rng.Offset(0, i * (rng.Columns.Count + gap))
            rng.Copy tgt
            tgt.ColumnWidth = rng.ColumnWidth
        Else
            Set ws = ActiveWorkbook.Worksheets.Add(After:=ActiveWorkbook.Sheets(ActiveWorkbook.Sheets.Count))
            ws.Name = UniqueSheetName(baseNm & " " & i)
            rng.Copy ws.Range(rng.Address)
            Dim c As Long
            For c = 1 To rng.Columns.Count
                ws.Range(rng.Address).Columns(c).ColumnWidth = rng.Columns(c).ColumnWidth
            Next c
        End If
    Next i
    Application.CutCopyMode = False
    rng.Worksheet.Activate
    SafeEnd
    Done "Duplicate Block: " & Plural(CLng(copies), "copy", "copies") & " created."
    Exit Sub
eh:
    ReportError "Duplicate Block"
End Sub

' Sums duplicated blocks into the original: for every numeric input cell in the
' original, writes =SUM(original, copy1, copy2, ...) of the corresponding cells.
Public Sub XC_SumCopies()
    On Error GoTo eh
    Dim rng As Range, copies As Variant, mode As Long, gap As Variant, i As Long, c As Range, refs As String, r As Long, cc As Long, n As Long, src As Range
    Dim sheetsMode As Boolean, shNames As String, parts() As String, p As Variant
    Set rng = SelRange()
    If rng Is Nothing Then Exit Sub
    mode = AskChoice("Where are the copies of this module?", Array("Below it on this sheet", "To its right on this sheet", "On other sheets (same address)"))
    If mode = 0 Then Exit Sub
    If mode < 3 Then
        copies = AskNumber("Number of copies:", GetSetting(REG_APP, "Modeling", "DuplicateCopies", "3"), "Sum Copies", 1, 500)
        If IsEmpty(copies) Then Exit Sub
        gap = AskNumber("Empty rows/columns between copies:", GetSetting(REG_APP, "Modeling", "DuplicateGap", "1"), "Sum Copies", 0, 100)
        If IsEmpty(gap) Then Exit Sub
    Else
        shNames = AskText("Sheet names of the copies, separated by commas:", "", "Sum Copies")
        If Len(shNames) = 0 Then Exit Sub
        parts = Split(shNames, ",")
    End If
    SnapshotRange rng, "Sum Copies"
    SafeStart "Summing copies"
    For Each c In rng.Cells
        If IsNumeric(c.Value) And Not IsEmpty(c.Value) And VarType(c.Value) <> vbString And VarType(c.Value) <> vbDate And Not c.HasFormula Then
            refs = c.Address(False, False)
            If mode = 1 Then
                For i = 1 To copies: refs = refs & "," & c.Offset(i * (rng.Rows.Count + gap), 0).Address(False, False): Next i
            ElseIf mode = 2 Then
                For i = 1 To copies: refs = refs & "," & c.Offset(0, i * (rng.Columns.Count + gap)).Address(False, False): Next i
            Else
                For Each p In parts
                    refs = refs & ",'" & Replace(Trim$(p), "'", "''") & "'!" & c.Address(False, False)
                Next p
            End If
            c.Formula = "=SUM(" & c.Value & "," & Mid$(refs, InStr(refs, ",") + 1) & ")"
            n = n + 1
        End If
    Next c
    SafeEnd
    Done "Sum Copies: " & Plural(n, "input cell") & " now sum their copies."
    Exit Sub
eh:
    ReportError "Sum Copies"
End Sub

'--- Insert symbol -------------------------------------------------------------------
Public Sub XC_InsertSymbol()
    On Error GoTo eh
    Dim names As Variant, codes As Variant, i As Long, c As Range
    names = Array("Dollar $", "Euro", "Pound", "Cent", "Yen", "Minus (true minus sign)", "Times x", "Divide", "Plus-minus", _
                  "Ellipsis ...", "Bullet", "Section", "Beta", "Delta", "Copyright", "Trademark", "Registered", "Degree", "Check mark", "Arrow right", "Arrow up", "Arrow down")
    codes = Array(36, 8364, 163, 162, 165, 8722, 215, 247, 177, 8230, 8226, 167, 946, 916, 169, 8482, 174, 176, 10003, 8594, 8593, 8595)
    If TypeName(Selection) <> "Range" Then Exit Sub
    i = AskChoice("Insert which symbol? (appended to the active cell's text)", names)
    If i = 0 Then Exit Sub
    Set c = ActiveCell
    If c.HasFormula Then
        MsgBox "The active cell contains a formula. Edit it manually and paste the symbol: " & ChrW(codes(i - 1)), vbInformation, APP_NAME
        SetClipboardText ChrW(codes(i - 1))
    Else
        WriteText c, c.Text & ChrW(codes(i - 1))
    End If
    Exit Sub
eh:
    ReportError "Insert Symbol"
End Sub
