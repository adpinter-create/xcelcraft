# Contributing

* Source of truth is `src/` (`.bas` / `.cls` text files). Never commit a `.xlam` to `src/`; releases carry a built `.xlam` as an attachment.
* Every tool is a `Public Sub XC_<Name>()` registered in `modMenu.RegisterTools` (and optionally `modShortcuts.RegisterKeys`).
* Follow the house pattern: `On Error GoTo eh` … `SafeStart` / `SafeEnd` … `ReportError "<tool name>"`. In-place tools call `SnapshotRange` first so Undo works.
* No `Scripting.Dictionary`, no Windows API declarations, no UserForms — the add-in must import and run on Windows and Mac Excel from text sources alone.
* Run `python -I tools/vbalint.py src/*.bas src/*.cls` before opening a pull request; CI runs the same check.
* To release: import `src/` into a fresh workbook in Excel, save as `.xlam`, attach it to the GitHub release, and bump `APP_VERSION` in `modCore.bas` and `CHANGELOG.md`.
