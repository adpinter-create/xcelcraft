#!/usr/bin/env python3
"""Very small structural linter for VBA .bas files.
Checks: block balance, duplicate Dim in a procedure, undeclared identifiers
(approximate, Option Explicit), and that called XC_/helper procedures exist.
"""
import re, sys, glob, os

KEYWORDS = set("""and or not xor mod is like new nothing true false empty null me
if then else elseif end sub function exit for next to step each in do loop while wend until
select case with dim as redim preserve set let get public private static const option explicit
byval byref optional paramarray on error goto resume call return type enum
integer long double single string boolean variant object date byte currency
ismissing isnumeric isempty isdate isarray isobject iserror vartype typename
len left right mid ucase lcase trim ltrim rtrim instr instrrev replace split join
str val cstr cdbl clng cint cbool cdate cvar chr chrw asc ascw string space format
abs int fix sgn sqr round rnd randomize now date time timer dateserial datevalue timevalue timeserial
year month day hour minute second weekday dateadd datediff datepart
msgbox inputbox array lbound ubound erase choose iif switch
err error debug print application activesheet activeworkbook activecell activewindow selection
workbooks worksheets sheets range cells rows columns union intersect thisworkbook
vbcrlf vblf vbcr vbtab vbnullstring vbyes vbno vbyesno vbquestion vbinformation vbexclamation vbcritical vbdefaultbutton2 vbokonly
vbstring vbboolean vbdate vbdouble vblong vbinteger vbempty vbnull vbtextcompare vbbinarycompare vbdirectory vbproper vbpropercase
xlnone xlcontinuous xldouble xldash xlthin xlmedium xlthick xledgeleft xledgetop xledgebottom xledgeright xlinsidevertical xlinsidehorizontal
xlleft xlcenter xlright xlcenteracrossselection xlgeneral xlpasteformats xlwhole xlpart xlbyrows xlexpression
xlunderlinestylesingle xlunderlinestylesingleaccounting xlunderlinestyledouble xlunderlinestyledoubleaccounting xlunderlinestylenone
xlcolorindexnone xlcelltypeformulas xlcalculationmanual xlwbatworksheet xlrows xlcolumns xllinear
msocontrolpopup msocontrolbutton msobuttoncaption
savesetting getsetting deletesetting dir getattr filelen filedatetime fileexists kill name mkdir rmdir
createobject getobject strreverse strconv strcomp strptr hex oct
with end next loop wend
excel vbmsgboxstyle vbcomparemethod xlcalculation commandbar commandbarpopup commandbarbutton commandbarcontrol
worksheet workbook range comment shape formatcondition collection
macscript rgb activechart chdir chdrive shell cbyte curdir environ mkdir filecopy setattr""".split())

BLOCK_OPEN = [
    (re.compile(r'^(public |private |friend )?(static )?(sub|function|property (get|let|set))\b', re.I), 'proc'),
    (re.compile(r'^if\b.*\bthen\s*$', re.I), 'if'),
    (re.compile(r'^for\b', re.I), 'for'),
    (re.compile(r'^do\b', re.I), 'do'),
    (re.compile(r'^while\b', re.I), 'while'),
    (re.compile(r'^select case\b', re.I), 'select'),
    (re.compile(r'^with\b', re.I), 'with'),
    (re.compile(r'^(private |public )?type\b', re.I), 'type'),
    (re.compile(r'^(private |public )?enum\b', re.I), 'enum'),
]
BLOCK_CLOSE = {
    'end sub': 'proc', 'end function': 'proc', 'end property': 'proc',
    'end if': 'if', 'next': 'for', 'loop': 'do', 'wend': 'while',
    'end select': 'select', 'end with': 'with', 'end type': 'type', 'end enum': 'enum',
}

def strip_strings_comments(line):
    out, i, inq = [], 0, False
    while i < len(line):
        ch = line[i]
        if ch == '"':
            if inq and i + 1 < len(line) and line[i+1] == '"':
                i += 2; continue
            inq = not inq; out.append('"' if not inq else '"'); i += 1; continue
        if not inq and ch == "'":
            break
        out.append(ch if not inq else ' ')
        i += 1
    return ''.join(out)

def logical_lines(text):
    """Join line continuations; return list of (lineno, text)."""
    res, buf, start = [], '', None
    for n, raw in enumerate(text.splitlines(), 1):
        s = strip_strings_comments(raw.rstrip())
        if start is None: start = n
        if s.rstrip().endswith('_'):
            buf += s.rstrip()[:-1] + ' '
            continue
        buf += s
        res.append((start, buf.strip()))
        buf, start = '', None
    return res

def check_file(path, all_procs):
    errs = []
    text = open(path, encoding='utf-8', errors='replace').read()
    lines = logical_lines(text)
    stack = []
    proc_name = None
    declared = set()
    module_decls = set()
    used_in_proc = []
    # strip hex literals
    def flush_proc():
        nonlocal used_in_proc, declared, proc_name
        if proc_name:
            for (ln, ident) in used_in_proc:
                if ident.lower() not in declared and ident.lower() not in module_decls and ident.lower() not in KEYWORDS \
                   and ident.lower() not in all_procs and not ident.lower().startswith('xl') and not ident.lower().startswith('mso') \
                   and not ident.lower().startswith('vb'):
                    errs.append((ln, f'undeclared identifier `{ident}` in {proc_name}'))
        used_in_proc, declared, proc_name = [], set(), None

    for ln, s in lines:
        if not s or s.lower().startswith('attribute ') or s.lower().startswith('option '):
            continue
        # labels
        if re.match(r'^[A-Za-z_]\w*:$', s):
            continue
        # split one-line colon statements for block checks: handle "Sub X(): ...: End Sub"
        parts = [p.strip() for p in re.split(r':(?!=)', s)] if ':' in s and not s.lower().startswith('case') else [s]
        # module-level declarations
        if proc_name is None:
            m = re.match(r'^(public |private |global )?(const )?(\w+)', s, re.I)
            if re.match(r'^(public |private |global )?(dim |const )?(\w+)\s*(\(|as|=)', s, re.I) and not re.match(r'^(public |private )?(sub|function|type|enum)\b', s, re.I):
                for d in re.findall(r'\b(\w+)\s*(?:\([^)]*\))?\s+as\b', s, re.I):
                    module_decls.add(d.lower())
                for d in re.findall(r'^(?:public |private |global )?(?:dim |const )(\w+)', s, re.I):
                    module_decls.add(d.lower())
        for p in parts:
            pl = p.lower()
            closed = False
            for key, kind in BLOCK_CLOSE.items():
                if pl == key or pl.startswith(key + ' '):
                    if not stack or stack[-1][0] != kind:
                        errs.append((ln, f'unexpected `{p}` (stack={[k for k,_ in stack]})'))
                    else:
                        stack.pop()
                        if kind == 'proc':
                            flush_proc()
                    closed = True
                    break
            if closed:
                continue
            if pl.startswith('exit ') or pl.startswith('end') and pl in ('end',):
                continue
            for rx, kind in BLOCK_OPEN:
                if rx.match(p):
                    if kind == 'if' and ' then ' in pl and not pl.endswith('then'):
                        break
                    stack.append((kind, ln))
                    if kind == 'proc':
                        m = re.search(r'(sub|function|property (?:get|let|set))\s+(\w+)\s*\((.*)\)', p, re.I)
                        if m:
                            proc_name = m.group(2)
                            declared = set()
                            for a in re.findall(r'(?:byval |byref |optional |paramarray )*\s*(\w+)\s*(?:\(\))?\s*(?:as\s+[\w.]+)?', m.group(3), re.I):
                                if a: declared.add(a.lower())
                            declared.add(proc_name.lower())
                    break
            # single-line If ... Then stmt handled above; also single-line "If x Then y Else z"
            # declarations inside proc
            if proc_name:
                for d in re.findall(r'\b(?:dim|static|const|redim(?: preserve)?)\s+(.*)', p, re.I):
                    for name in re.findall(r'(\w+)\s*(?:\([^)]*\))?\s*(?:as\b|,|=|$)', d, re.I):
                        declared.add(name.lower())
                for d in re.findall(r'\bfor each (\w+)', p, re.I):
                    pass
                # usage: crude identifier scan (skip member access .x and named args x:=)
                scan = re.sub(r'\.\w+', ' ', p)
                scan = re.sub(r'\w+\s*:=', ' ', scan)
                scan = re.sub(r'\b(dim|static|const|redim preserve|redim)\b.*', ' ', scan, flags=re.I)
                scan = re.sub(r'&H[0-9A-Fa-f]+', ' 0 ', scan)
                for ident in re.findall(r'(?<![\.\w])([A-Za-z_]\w*)', scan):
                    if ident[0].isdigit(): continue
                    used_in_proc.append((ln, ident))
    if stack:
        for kind, ln in stack:
            errs.append((ln, f'unclosed block `{kind}`'))
    return errs

def collect_procs(paths):
    procs = set(['mac'])
    for p in paths:
        txt = open(p, encoding='utf-8', errors='replace').read()
        for m in re.finditer(r'^(?:public |private |friend )?(?:static )?(?:sub|function)\s+(\w+)', txt, re.I | re.M):
            procs.add(m.group(1).lower())
        for m in re.finditer(r'^public (?:const )?(\w+)', txt, re.I | re.M):
            procs.add(m.group(1).lower())
        for m in re.finditer(r'^attribute vb_name = "(\w+)"', txt, re.I | re.M):
            procs.add(m.group(1).lower())
        for m in re.finditer(r'^\s*(\w+):\s*$', txt, re.M):
            procs.add(m.group(1).lower())
    return procs

if __name__ == '__main__':
    paths = sys.argv[1:] or glob.glob('*.bas')
    procs = collect_procs(paths)
    total = 0
    for p in paths:
        errs = check_file(p, procs)
        for ln, e in errs:
            print(f'{os.path.basename(p)}:{ln}: {e}')
        total += len(errs)
    print(f'{total} issue(s)')
