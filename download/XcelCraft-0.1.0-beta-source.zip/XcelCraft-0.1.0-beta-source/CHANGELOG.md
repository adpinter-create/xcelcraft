# Changelog

## 0.1.0-beta — unreleased
* First public cut: 349 tools in two families (Utilities, Modeling), 78 shortcuts, one-level undo, menu + shortcut manager.
* Known limits: untested on Mac; no automated test harness yet; paste tools need the source range marked first.
