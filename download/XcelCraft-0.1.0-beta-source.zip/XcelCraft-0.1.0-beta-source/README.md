# XcelCraft

An open-source productivity add-in for Microsoft Excel, written entirely in VBA. 349 tools in two families:

* **Utilities** — everyday cleanup and bulk operations: text, numbers, dates, fill, sheets, ranges, rows & columns, selection, layout, notes, links, inspection, files, import and export.
* **Modeling** — keyboard-driven tools for financial models: number/color/border format cycles, cell-type coloring, smart fill, formula guards and resolvers, verbatim/linked paste, growth-rate and summary helpers, precedent/dependent navigation, consistency checks, a model audit report and chart helpers.

Independent implementation. Contains no third-party code; written from scratch in VBA.
Runs on Windows and Mac Excel from text sources alone — no compiled components, no Windows API, no UserForms.

**Status: 0.1.0-beta.** Linted and cross-checked, not yet exercised end to end. Expect rough edges and please file issues.

## Install

1. Download the latest `.xlam` from Releases (or build it: import everything in `src/` into a blank workbook in the VBA editor, save as *Excel Add-in*).
2. Excel → `File > Options > Add-ins > Manage: Excel Add-ins > Go…` (Mac: `Tools > Excel Add-ins`) → tick the add-in.
3. The menu appears under the **Add-ins** ribbon tab → *Menu Commands* (Mac: in the menu bar). Shortcuts install automatically.

Run the `BuildMenu` macro if the menu doesn't show after enabling.

## Using it

* **Search for a tool** (`Ctrl+Alt+Shift+F`) finds any tool by a word in its name.
* **Run the last tool again** (`Ctrl+Alt+Shift+Z`) and **Undo the last tool** (`Ctrl+Alt+Shift+U`, one level — Excel can't undo VBA changes, so in-place tools snapshot first).
* **Cycles** (number formats, colors, borders, fonts…) start from their first step; press again on the same selection to move to the next. Every cycle is editable under *Format: Fonts & Alignment > Edit a cycle's steps…* (steps separated by `|`, colors as RGB long values, `-1` = no fill).
* **Keyboard shortcuts** are listed and editable under *XcelCraft > Keyboard shortcuts…*. They use Excel's `OnKey` syntax (`^` Ctrl, `+` Shift, `%` Alt); Ctrl+Shift+digit is written as the shifted character of a US layout (`^!` = Ctrl+Shift+1) — change them if your layout differs.
* **Paste tools** (verbatim, keep-internal-links, links, transposed, number formats, insert) need to know the source range, which VBA can't read from Excel's clipboard. Use *Mark source range for the paste tools* (`Ctrl+Alt+C`) first, or point at the source when asked.
* **Color on entry** (color cells by type as you type): Immediate window → `SaveSetting "XcelCraft","Options","TypeColorOnEntry","1"`.
* **Quiet mode** suppresses result pop-ups: *XcelCraft > Quiet mode on/off*.

`TOOL_TRACKER.csv` lists every menu entry with its category, procedure and default shortcut.

## Repository layout

```
src/        .bas / .cls modules — the source of truth (import these into Excel)
tools/      vbalint.py (structural linter, runs in CI) · captions.py (menu text generator)
.github/    CI: lint + registry cross-check on every push
```

Module map: `modCore` (helpers, undo, prompts) · `modMenu` (registry, menu) · `modShortcuts` · `clsAppEvents` ·
Utilities: `modText` `modNumbersDates` `modFill` `modSheets` `modRange` `modColsRows` `modFormulas` `modSelect` `modFormatLayout` `modObjects` `modWebData` `modInfo` `modFile` `modImportExport` ·
Modeling: `modFormatCycles` `modModeling` `modFinModel` `modAudit` `modCharts`.

## Contributing

See `CONTRIBUTING.md`. Short version: add a `Public Sub XC_<Name>()` following the house pattern, register it in `modMenu`, run the linter.

## License

MIT — see `LICENSE`.
